"use strict";
(() => {
var exports = {};
exports.id = 707;
exports.ids = [707];
exports.modules = {

/***/ 3888:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (async (request, resposne) => {
  try {
    var http = __webpack_require__(7211);

    const {
      id
    } = request.query;

    if (!id) {
      resposne.status(200);
      resposne.json({
        "status": "error",
        "message": "Invalid Product ID"
      });
      return resposne;
    }

    const {
      STAMPED_API_KEY_PUBLIC
    } = process.env;
    const {
      STAMPED_TOKEN
    } = process.env;
    var options = {
      "method": "POST",
      "hostname": "stamped.io",
      "port": null,
      "path": "/api/widget/badges?isIncludeBreakdown=true&isincludehtml=true",
      "headers": {
        "authorization": "Basic " + STAMPED_TOKEN,
        "content-type": "application/json",
        "cache-control": "no-cache"
      }
    };
    var req = http.request(options, function (res) {
      var chunks = [];
      res.on("data", function (chunk) {
        chunks.push(chunk);
      });
      res.on("end", function () {
        var body = Buffer.concat(chunks);
        resposne.status(200);
        console.log(body.toString());
        resposne.json(JSON.parse(body));
      });
    });
    req.write(JSON.stringify({
      productIds: [{
        productId: id
      }],
      apiKey: STAMPED_API_KEY_PUBLIC,
      storeUrl: 'sleekshop.com'
    }));
    req.end();
  } catch (error) {
    resposne.status(200);
    resposne.json({
      "status": "error",
      "message": error
    });
  }

  return resposne;
});

/***/ }),

/***/ 7211:
/***/ ((module) => {

module.exports = require("https");

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = (__webpack_exec__(3888));
module.exports = __webpack_exports__;

})();