"use strict";
(() => {
var exports = {};
exports.id = 292;
exports.ids = [292];
exports.modules = {

/***/ 7961:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (async (request, resposne) => {
  try {
    var http = __webpack_require__(7211);

    const {
      id
    } = request.query;

    if (!id) {
      resposne.status(200);
      resposne.json({
        status: 'error',
        message: 'Invalid Product ID'
      });
      return resposne;
    }

    const {
      STAMPED_TOKEN
    } = process.env;
    var options = {
      method: 'GET',
      hostname: 'stamped.io',
      port: null,
      path: '/api/v2/239827/dashboard/reviews/?productId=' + id,
      headers: {
        authorization: 'Basic ' + STAMPED_TOKEN,
        'cache-control': 'no-cache'
      }
    };
    var req = http.request(options, function (res) {
      var chunks = [];
      res.on('data', function (chunk) {
        chunks.push(chunk);
      });
      res.on('end', function () {
        var body = Buffer.concat(chunks);
        console.log(body.toString());
        resposne.status(200);
        resposne.json(JSON.parse(body));
      });
    });
    req.end();
  } catch (error) {
    resposne.status(200);
    resposne.json({
      status: 'error',
      message: error
    });
  }

  return resposne;
});

/***/ }),

/***/ 7211:
/***/ ((module) => {

module.exports = require("https");

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = (__webpack_exec__(7961));
module.exports = __webpack_exports__;

})();