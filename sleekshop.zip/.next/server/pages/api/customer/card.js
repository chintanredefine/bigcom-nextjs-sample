"use strict";
(() => {
var exports = {};
exports.id = 442;
exports.ids = [442];
exports.modules = {

/***/ 2730:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ card)
});

;// CONCATENATED MODULE: ./framework/bigcommerce/api/endpoints/customer/card.ts
function noopApi(...args) {}
// EXTERNAL MODULE: ./lib/api/commerce.ts + 17 modules
var commerce = __webpack_require__(1862);
;// CONCATENATED MODULE: ./pages/api/customer/card.ts


/* harmony default export */ const card = (noopApi(commerce/* default */.Z));

/***/ }),

/***/ 2937:
/***/ ((module) => {

module.exports = require("@vercel/fetch");

/***/ }),

/***/ 2740:
/***/ ((module) => {

module.exports = require("immutability-helper");

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [370,862], () => (__webpack_exec__(2730)));
module.exports = __webpack_exports__;

})();