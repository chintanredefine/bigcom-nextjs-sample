"use strict";
(() => {
var exports = {};
exports.id = 579;
exports.ids = [579];
exports.modules = {

/***/ 9576:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "x": () => (/* binding */ parseWishlistItem),
/* harmony export */   "_": () => (/* binding */ parseCartItem)
/* harmony export */ });
const parseWishlistItem = item => ({
  product_id: Number(item.productId),
  variant_id: Number(item.variantId)
});
const parseCartItem = item => ({
  quantity: item.quantity,
  product_id: Number(item.productId),
  variant_id: Number(item.variantId),
  option_selections: item.optionSelections
});

/***/ }),

/***/ 3017:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ api_cart)
});

// EXTERNAL MODULE: ./framework/commerce/api/index.ts + 1 modules
var api = __webpack_require__(9520);
// EXTERNAL MODULE: ./framework/commerce/api/utils/errors.ts
var errors = __webpack_require__(3076);
// EXTERNAL MODULE: ./framework/commerce/api/utils/is-allowed-operation.ts + 1 modules
var is_allowed_operation = __webpack_require__(9218);
;// CONCATENATED MODULE: ./framework/commerce/api/endpoints/cart.ts
function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) { symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); } keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }




const cartEndpoint = async ctx => {
  const {
    req,
    res,
    handlers,
    config
  } = ctx;

  if (!(0,is_allowed_operation/* default */.Z)(req, res, {
    GET: handlers['getCart'],
    POST: handlers['addItem'],
    PUT: handlers['updateItem'],
    DELETE: handlers['removeItem']
  })) {
    return;
  }

  const {
    cookies
  } = req;
  const cartId = cookies[config.cartCookie];

  try {
    // Return current cart info
    if (req.method === 'GET') {
      const body = {
        cartId
      };
      return await handlers['getCart'](_objectSpread(_objectSpread({}, ctx), {}, {
        body
      }));
    } // Create or add an item to the cart


    if (req.method === 'POST') {
      const body = _objectSpread(_objectSpread({}, req.body), {}, {
        cartId
      });

      return await handlers['addItem'](_objectSpread(_objectSpread({}, ctx), {}, {
        body
      }));
    } // Update item in cart


    if (req.method === 'PUT') {
      const body = _objectSpread(_objectSpread({}, req.body), {}, {
        cartId
      });

      return await handlers['updateItem'](_objectSpread(_objectSpread({}, ctx), {}, {
        body
      }));
    } // Remove an item from the cart


    if (req.method === 'DELETE') {
      const body = _objectSpread(_objectSpread({}, req.body), {}, {
        cartId
      });

      return await handlers['removeItem'](_objectSpread(_objectSpread({}, ctx), {}, {
        body
      }));
    }
  } catch (error) {
    console.error(error);
    const message = error instanceof errors/* CommerceAPIError */.$ ? 'An unexpected error ocurred with the Commerce API' : 'An unexpected error ocurred';
    res.status(500).json({
      data: null,
      errors: [{
        message
      }]
    });
  }
};

/* harmony default export */ const cart = (cartEndpoint);
// EXTERNAL MODULE: ./framework/bigcommerce/lib/normalize.ts + 2 modules
var normalize = __webpack_require__(7258);
// EXTERNAL MODULE: ./framework/bigcommerce/api/utils/errors.ts
var utils_errors = __webpack_require__(4264);
// EXTERNAL MODULE: external "cookie"
var external_cookie_ = __webpack_require__(8883);
;// CONCATENATED MODULE: ./framework/bigcommerce/api/utils/get-cart-cookie.ts

function getCartCookie(name, cartId, maxAge) {
  const options = cartId && maxAge ? {
    maxAge,
    expires: new Date(Date.now() + maxAge * 1000),
    secure: true,
    path: '/',
    sameSite: 'lax'
  } : {
    maxAge: -1,
    path: '/'
  }; // Removes the cookie

  return (0,external_cookie_.serialize)(name, cartId || '', options);
}
;// CONCATENATED MODULE: ./framework/bigcommerce/api/endpoints/cart/get-cart.ts




// Return current cart info
const getCart = async ({
  res,
  body: {
    cartId
  },
  config
}) => {
  let result = {};

  if (cartId) {
    try {
      result = await config.storeApiFetch(`/v3/carts/${cartId}?include=line_items.physical_items.options`);
    } catch (error) {
      if (error instanceof utils_errors/* BigcommerceApiError */.zd && error.status === 404) {
        // Remove the cookie if it exists but the cart wasn't found
        res.setHeader('Set-Cookie', getCartCookie(config.cartCookie));
      } else {
        throw error;
      }
    }
  }

  res.status(200).json({
    data: result.data ? (0,normalize/* normalizeCart */.Id)(result.data) : null
  });
};

/* harmony default export */ const get_cart = (getCart);
// EXTERNAL MODULE: ./framework/bigcommerce/api/utils/parse-item.ts
var parse_item = __webpack_require__(9576);
;// CONCATENATED MODULE: ./framework/bigcommerce/api/endpoints/cart/add-item.ts
function add_item_ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) { symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); } keys.push.apply(keys, symbols); } return keys; }

function add_item_objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { add_item_ownKeys(Object(source), true).forEach(function (key) { add_item_defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { add_item_ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function add_item_defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }





const addItem = async ({
  res,
  body: {
    cartId,
    item
  },
  config
}) => {
  if (!item) {
    return res.status(400).json({
      data: null,
      errors: [{
        message: 'Missing item'
      }]
    });
  }

  if (!item.quantity) item.quantity = 1;
  const options = {
    method: 'POST',
    body: JSON.stringify(add_item_objectSpread({
      line_items: [(0,parse_item/* parseCartItem */._)(item)]
    }, !cartId && config.storeChannelId ? {
      channel_id: config.storeChannelId
    } : {}))
  };
  const {
    data
  } = cartId ? await config.storeApiFetch(`/v3/carts/${cartId}/items?include=line_items.physical_items.options`, options) : await config.storeApiFetch('/v3/carts?include=line_items.physical_items.options', options); // Create or update the cart cookie

  res.setHeader('Set-Cookie', getCartCookie(config.cartCookie, data.id, config.cartCookieMaxAge));
  res.status(200).json({
    data: (0,normalize/* normalizeCart */.Id)(data)
  });
};

/* harmony default export */ const add_item = (addItem);
;// CONCATENATED MODULE: ./framework/bigcommerce/api/endpoints/cart/update-item.ts




const updateItem = async ({
  res,
  body: {
    cartId,
    itemId,
    item
  },
  config
}) => {
  if (!cartId || !itemId || !item) {
    return res.status(400).json({
      data: null,
      errors: [{
        message: 'Invalid request'
      }]
    });
  }

  const {
    data
  } = await config.storeApiFetch(`/v3/carts/${cartId}/items/${itemId}?include=line_items.physical_items.options`, {
    method: 'PUT',
    body: JSON.stringify({
      line_item: (0,parse_item/* parseCartItem */._)(item)
    })
  }); // Update the cart cookie

  res.setHeader('Set-Cookie', getCartCookie(config.cartCookie, cartId, config.cartCookieMaxAge));
  res.status(200).json({
    data: (0,normalize/* normalizeCart */.Id)(data)
  });
};

/* harmony default export */ const update_item = (updateItem);
;// CONCATENATED MODULE: ./framework/bigcommerce/api/endpoints/cart/remove-item.ts



const removeItem = async ({
  res,
  body: {
    cartId,
    itemId
  },
  config
}) => {
  var _result$data;

  if (!cartId || !itemId) {
    return res.status(400).json({
      data: null,
      errors: [{
        message: 'Invalid request'
      }]
    });
  }

  const result = await config.storeApiFetch(`/v3/carts/${cartId}/items/${itemId}?include=line_items.physical_items.options`, {
    method: 'DELETE'
  });
  const data = (_result$data = result === null || result === void 0 ? void 0 : result.data) !== null && _result$data !== void 0 ? _result$data : null;
  res.setHeader('Set-Cookie', data ? // Update the cart cookie
  getCartCookie(config.cartCookie, cartId, config.cartCookieMaxAge) : // Remove the cart cookie if the cart was removed (empty items)
  getCartCookie(config.cartCookie));
  res.status(200).json({
    data: data && (0,normalize/* normalizeCart */.Id)(data)
  });
};

/* harmony default export */ const remove_item = (removeItem);
;// CONCATENATED MODULE: ./framework/bigcommerce/api/endpoints/cart/index.ts






const handlers = {
  getCart: get_cart,
  addItem: add_item,
  updateItem: update_item,
  removeItem: remove_item
};
const cartApi = (0,api/* createEndpoint */.dg)({
  handler: cart,
  handlers
});
/* harmony default export */ const endpoints_cart = (cartApi);
// EXTERNAL MODULE: ./lib/api/commerce.ts + 17 modules
var commerce = __webpack_require__(1862);
;// CONCATENATED MODULE: ./pages/api/cart.ts


/* harmony default export */ const api_cart = (endpoints_cart(commerce/* default */.Z));

/***/ }),

/***/ 2937:
/***/ ((module) => {

module.exports = require("@vercel/fetch");

/***/ }),

/***/ 8883:
/***/ ((module) => {

module.exports = require("cookie");

/***/ }),

/***/ 2740:
/***/ ((module) => {

module.exports = require("immutability-helper");

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [370,862,971], () => (__webpack_exec__(3017)));
module.exports = __webpack_exports__;

})();