"use strict";
(() => {
var exports = {};
exports.id = 30;
exports.ids = [30];
exports.modules = {

/***/ 8168:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ api_logout)
});

// EXTERNAL MODULE: ./framework/commerce/api/index.ts + 1 modules
var api = __webpack_require__(9520);
// EXTERNAL MODULE: ./framework/commerce/api/utils/errors.ts
var errors = __webpack_require__(3076);
// EXTERNAL MODULE: ./framework/commerce/api/utils/is-allowed-operation.ts + 1 modules
var is_allowed_operation = __webpack_require__(9218);
;// CONCATENATED MODULE: ./framework/commerce/api/endpoints/logout.ts
function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) { symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); } keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }




const logoutEndpoint = async ctx => {
  const {
    req,
    res,
    handlers
  } = ctx;

  if (!(0,is_allowed_operation/* default */.Z)(req, res, {
    GET: handlers['logout']
  })) {
    return;
  }

  try {
    const redirectTo = req.query.redirect_to;
    const body = typeof redirectTo === 'string' ? {
      redirectTo
    } : {};
    return await handlers['logout'](_objectSpread(_objectSpread({}, ctx), {}, {
      body
    }));
  } catch (error) {
    console.error(error);
    const message = error instanceof errors/* CommerceAPIError */.$ ? 'An unexpected error ocurred with the Commerce API' : 'An unexpected error ocurred';
    res.status(500).json({
      data: null,
      errors: [{
        message
      }]
    });
  }
};

/* harmony default export */ const logout = (logoutEndpoint);
// EXTERNAL MODULE: external "cookie"
var external_cookie_ = __webpack_require__(8883);
;// CONCATENATED MODULE: ./framework/bigcommerce/api/endpoints/logout/logout.ts


const logout_logout = async ({
  res,
  body: {
    redirectTo
  },
  config
}) => {
  // Remove the cookie
  res.setHeader('Set-Cookie', (0,external_cookie_.serialize)(config.customerCookie, '', {
    maxAge: -1,
    path: '/'
  })); // Only allow redirects to a relative URL

  if (redirectTo !== null && redirectTo !== void 0 && redirectTo.startsWith('/')) {
    res.redirect(redirectTo);
  } else {
    res.status(200).json({
      data: null
    });
  }
};

/* harmony default export */ const endpoints_logout_logout = (logout_logout);
;// CONCATENATED MODULE: ./framework/bigcommerce/api/endpoints/logout/index.ts



const handlers = {
  logout: endpoints_logout_logout
};
const logoutApi = (0,api/* createEndpoint */.dg)({
  handler: logout,
  handlers
});
/* harmony default export */ const endpoints_logout = (logoutApi);
// EXTERNAL MODULE: ./lib/api/commerce.ts + 17 modules
var commerce = __webpack_require__(1862);
;// CONCATENATED MODULE: ./pages/api/logout.ts


/* harmony default export */ const api_logout = (endpoints_logout(commerce/* default */.Z));

/***/ }),

/***/ 2937:
/***/ ((module) => {

module.exports = require("@vercel/fetch");

/***/ }),

/***/ 8883:
/***/ ((module) => {

module.exports = require("cookie");

/***/ }),

/***/ 2740:
/***/ ((module) => {

module.exports = require("immutability-helper");

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [370,862,971], () => (__webpack_exec__(8168)));
module.exports = __webpack_exports__;

})();