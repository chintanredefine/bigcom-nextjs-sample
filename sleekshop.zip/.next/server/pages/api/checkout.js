"use strict";
(() => {
var exports = {};
exports.id = 756;
exports.ids = [756];
exports.modules = {

/***/ 8248:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* unused harmony export getCustomerIdQuery */
const getCustomerIdQuery =
/* GraphQL */
`
  query getCustomerId {
    customer {
      entityId
    }
  }
`;

async function getCustomerId({
  customerToken,
  config
}) {
  var _data$customer;

  const {
    data
  } = await config.fetch(getCustomerIdQuery, undefined, {
    headers: {
      cookie: `${config.customerCookie}=${customerToken}`
    }
  });
  return String(data === null || data === void 0 ? void 0 : (_data$customer = data.customer) === null || _data$customer === void 0 ? void 0 : _data$customer.entityId);
}

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (getCustomerId);

/***/ }),

/***/ 6459:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ api_checkout)
});

// EXTERNAL MODULE: ./framework/commerce/api/index.ts + 1 modules
var api = __webpack_require__(9520);
// EXTERNAL MODULE: ./framework/commerce/api/utils/errors.ts
var errors = __webpack_require__(3076);
// EXTERNAL MODULE: ./framework/commerce/api/utils/is-allowed-operation.ts + 1 modules
var is_allowed_operation = __webpack_require__(9218);
;// CONCATENATED MODULE: ./framework/commerce/api/endpoints/checkout.ts
function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) { symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); } keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }




const checkoutEndpoint = async ctx => {
  const {
    req,
    res,
    handlers,
    config
  } = ctx;

  if (!(0,is_allowed_operation/* default */.Z)(req, res, {
    GET: handlers['getCheckout'],
    POST: handlers['submitCheckout']
  })) {
    return;
  }

  const {
    cookies
  } = req;
  const cartId = cookies[config.cartCookie];

  try {
    // Create checkout
    if (req.method === 'GET') {
      const body = _objectSpread(_objectSpread({}, req.body), {}, {
        cartId
      });

      return await handlers['getCheckout'](_objectSpread(_objectSpread({}, ctx), {}, {
        body
      }));
    } // Create checkout


    if (req.method === 'POST' && handlers['submitCheckout']) {
      const body = _objectSpread(_objectSpread({}, req.body), {}, {
        cartId
      });

      return await handlers['submitCheckout'](_objectSpread(_objectSpread({}, ctx), {}, {
        body
      }));
    }
  } catch (error) {
    console.error(error);
    const message = error instanceof errors/* CommerceAPIError */.$ ? 'An unexpected error ocurred with the Commerce API' : 'An unexpected error ocurred';
    res.status(500).json({
      data: null,
      errors: [{
        message
      }]
    });
  }
};

/* harmony default export */ const checkout = (checkoutEndpoint);
// EXTERNAL MODULE: ./framework/bigcommerce/api/utils/get-customer-id.ts
var get_customer_id = __webpack_require__(8248);
;// CONCATENATED MODULE: external "jsonwebtoken"
const external_jsonwebtoken_namespaceObject = require("jsonwebtoken");
var external_jsonwebtoken_default = /*#__PURE__*/__webpack_require__.n(external_jsonwebtoken_namespaceObject);
;// CONCATENATED MODULE: external "uuidv4"
const external_uuidv4_namespaceObject = require("uuidv4");
;// CONCATENATED MODULE: ./framework/bigcommerce/api/endpoints/checkout/get-checkout.ts



const fullCheckout = true;

const getCheckout = async ({
  req,
  res,
  config
}) => {
  const {
    cookies
  } = req;
  const cartId = cookies[config.cartCookie];
  const customerToken = cookies[config.customerCookie];

  if (!cartId) {
    res.redirect('/cart');
    return;
  }

  const {
    data
  } = await config.storeApiFetch(`/v3/carts/${cartId}/redirect_urls`, {
    method: 'POST'
  });
  const customerId = customerToken && (await (0,get_customer_id/* default */.Z)({
    customerToken,
    config
  })); //if there is a customer create a jwt token

  if (!customerId) {
    if (fullCheckout) {
      res.redirect(data.checkout_url);
      return;
    }
  } else {
    const dateCreated = Math.round(new Date().getTime() / 1000);
    const payload = {
      iss: config.storeApiClientId,
      iat: dateCreated,
      jti: (0,external_uuidv4_namespaceObject.uuid)(),
      operation: 'customer_login',
      store_hash: config.storeHash,
      customer_id: customerId,
      channel_id: config.storeChannelId,
      redirect_to: data.checkout_url
    };
    let token = external_jsonwebtoken_default().sign(payload, config.storeApiClientSecret, {
      algorithm: 'HS256'
    });
    let checkouturl = `${config.storeUrl}/login/token/${token}`; // console.log('checkouturl', checkouturl)

    if (fullCheckout) {
      res.redirect(checkouturl);
      return;
    }
  } // TODO: make the embedded checkout work too!


  const html = `
       <!DOCTYPE html>
         <html lang="en">
         <head>
           <meta charset="UTF-8">
           <meta name="viewport" content="width=device-width, initial-scale=1.0">
           <title>Checkout</title>
           <script src="https://checkout-sdk.bigcommerce.com/v1/loader.js"></script>
           <script>
             window.onload = function() {
               checkoutKitLoader.load('checkout-sdk').then(function (service) {
                 service.embedCheckout({
                   containerId: 'checkout',
                   url: '${data.embedded_checkout_url}'
                 });
               });
             }
           </script>
         </head>
         <body>
           <div id="checkout"></div>
         </body>
       </html>
     `;
  res.status(200);
  res.setHeader('Content-Type', 'text/html');
  res.write(html);
  res.end();
};

/* harmony default export */ const get_checkout = (getCheckout);
;// CONCATENATED MODULE: ./framework/bigcommerce/api/endpoints/checkout/index.ts



const handlers = {
  getCheckout: get_checkout
};
const checkoutApi = (0,api/* createEndpoint */.dg)({
  handler: checkout,
  handlers
});
/* harmony default export */ const endpoints_checkout = (checkoutApi);
// EXTERNAL MODULE: ./lib/api/commerce.ts + 17 modules
var commerce = __webpack_require__(1862);
;// CONCATENATED MODULE: ./pages/api/checkout.ts


/* harmony default export */ const api_checkout = (endpoints_checkout(commerce/* default */.Z));

/***/ }),

/***/ 2937:
/***/ ((module) => {

module.exports = require("@vercel/fetch");

/***/ }),

/***/ 2740:
/***/ ((module) => {

module.exports = require("immutability-helper");

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [370,862,971], () => (__webpack_exec__(6459)));
module.exports = __webpack_exports__;

})();