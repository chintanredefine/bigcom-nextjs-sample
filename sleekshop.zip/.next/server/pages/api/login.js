"use strict";
(() => {
var exports = {};
exports.id = 994;
exports.ids = [994];
exports.modules = {

/***/ 7220:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ api_login)
});

// EXTERNAL MODULE: ./framework/commerce/api/index.ts + 1 modules
var api = __webpack_require__(9520);
// EXTERNAL MODULE: ./framework/commerce/api/utils/errors.ts
var errors = __webpack_require__(3076);
// EXTERNAL MODULE: ./framework/commerce/api/utils/is-allowed-operation.ts + 1 modules
var is_allowed_operation = __webpack_require__(9218);
;// CONCATENATED MODULE: ./framework/commerce/api/endpoints/login.ts
function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) { symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); } keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }




const loginEndpoint = async ctx => {
  const {
    req,
    res,
    handlers
  } = ctx;

  if (!(0,is_allowed_operation/* default */.Z)(req, res, {
    POST: handlers['login']
  })) {
    return;
  }

  try {
    var _req$body;

    const body = (_req$body = req.body) !== null && _req$body !== void 0 ? _req$body : {};
    return await handlers['login'](_objectSpread(_objectSpread({}, ctx), {}, {
      body
    }));
  } catch (error) {
    console.error(error);
    const message = error instanceof errors/* CommerceAPIError */.$ ? 'An unexpected error ocurred with the Commerce API' : 'An unexpected error ocurred';
    res.status(500).json({
      data: null,
      errors: [{
        message
      }]
    });
  }
};

/* harmony default export */ const login = (loginEndpoint);
// EXTERNAL MODULE: ./framework/commerce/utils/errors.ts
var utils_errors = __webpack_require__(6370);
;// CONCATENATED MODULE: ./framework/bigcommerce/api/endpoints/login/login.ts

const invalidCredentials = /invalid credentials/i;

const login_login = async ({
  res,
  body: {
    email,
    password
  },
  config,
  commerce
}) => {
  // TODO: Add proper validations with something like Ajv
  if (!(email && password)) {
    return res.status(400).json({
      data: null,
      errors: [{
        message: 'Invalid request'
      }]
    });
  } // TODO: validate the password and email
  // Passwords must be at least 7 characters and contain both alphabetic
  // and numeric characters.


  try {
    await commerce.login({
      variables: {
        email,
        password
      },
      config,
      res
    });
  } catch (error) {
    // Check if the email and password didn't match an existing account
    if (error instanceof utils_errors/* FetcherError */.T4 && invalidCredentials.test(error.message)) {
      return res.status(401).json({
        data: null,
        errors: [{
          message: 'Cannot find an account that matches the provided credentials',
          code: 'invalid_credentials'
        }]
      });
    }

    throw error;
  }

  res.status(200).json({
    data: null
  });
};

/* harmony default export */ const endpoints_login_login = (login_login);
;// CONCATENATED MODULE: ./framework/bigcommerce/api/endpoints/login/index.ts



const handlers = {
  login: endpoints_login_login
};
const loginApi = (0,api/* createEndpoint */.dg)({
  handler: login,
  handlers
});
/* harmony default export */ const endpoints_login = (loginApi);
// EXTERNAL MODULE: ./lib/api/commerce.ts + 17 modules
var commerce = __webpack_require__(1862);
;// CONCATENATED MODULE: ./pages/api/login.ts


/* harmony default export */ const api_login = (endpoints_login(commerce/* default */.Z));

/***/ }),

/***/ 2937:
/***/ ((module) => {

module.exports = require("@vercel/fetch");

/***/ }),

/***/ 2740:
/***/ ((module) => {

module.exports = require("immutability-helper");

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [370,862,971], () => (__webpack_exec__(7220)));
module.exports = __webpack_exports__;

})();