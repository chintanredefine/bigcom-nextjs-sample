"use strict";
(() => {
var exports = {};
exports.id = 560;
exports.ids = [560];
exports.modules = {

/***/ 8248:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* unused harmony export getCustomerIdQuery */
const getCustomerIdQuery =
/* GraphQL */
`
  query getCustomerId {
    customer {
      entityId
    }
  }
`;

async function getCustomerId({
  customerToken,
  config
}) {
  var _data$customer;

  const {
    data
  } = await config.fetch(getCustomerIdQuery, undefined, {
    headers: {
      cookie: `${config.customerCookie}=${customerToken}`
    }
  });
  return String(data === null || data === void 0 ? void 0 : (_data$customer = data.customer) === null || _data$customer === void 0 ? void 0 : _data$customer.entityId);
}

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (getCustomerId);

/***/ }),

/***/ 9576:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "x": () => (/* binding */ parseWishlistItem),
/* harmony export */   "_": () => (/* binding */ parseCartItem)
/* harmony export */ });
const parseWishlistItem = item => ({
  product_id: Number(item.productId),
  variant_id: Number(item.variantId)
});
const parseCartItem = item => ({
  quantity: item.quantity,
  product_id: Number(item.productId),
  variant_id: Number(item.variantId),
  option_selections: item.optionSelections
});

/***/ }),

/***/ 340:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ api_wishlist)
});

// EXTERNAL MODULE: ./framework/commerce/api/index.ts + 1 modules
var api = __webpack_require__(9520);
// EXTERNAL MODULE: ./framework/commerce/api/utils/errors.ts
var errors = __webpack_require__(3076);
// EXTERNAL MODULE: ./framework/commerce/api/utils/is-allowed-operation.ts + 1 modules
var is_allowed_operation = __webpack_require__(9218);
;// CONCATENATED MODULE: ./framework/commerce/api/endpoints/wishlist.ts
function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) { symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); } keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }




const wishlistEndpoint = async ctx => {
  const {
    req,
    res,
    handlers,
    config
  } = ctx;

  if (!(0,is_allowed_operation/* default */.Z)(req, res, {
    GET: handlers['getWishlist'],
    POST: handlers['addItem'],
    DELETE: handlers['removeItem']
  })) {
    return;
  }

  const {
    cookies
  } = req;
  const customerToken = cookies[config.customerCookie];

  try {
    // Return current wishlist info
    if (req.method === 'GET') {
      const body = {
        customerToken,
        includeProducts: req.query.products === '1'
      };
      return await handlers['getWishlist'](_objectSpread(_objectSpread({}, ctx), {}, {
        body
      }));
    } // Add an item to the wishlist


    if (req.method === 'POST') {
      const body = _objectSpread(_objectSpread({}, req.body), {}, {
        customerToken
      });

      return await handlers['addItem'](_objectSpread(_objectSpread({}, ctx), {}, {
        body
      }));
    } // Remove an item from the wishlist


    if (req.method === 'DELETE') {
      const body = _objectSpread(_objectSpread({}, req.body), {}, {
        customerToken
      });

      return await handlers['removeItem'](_objectSpread(_objectSpread({}, ctx), {}, {
        body
      }));
    }
  } catch (error) {
    console.error(error);
    const message = error instanceof errors/* CommerceAPIError */.$ ? 'An unexpected error ocurred with the Commerce API' : 'An unexpected error ocurred';
    res.status(500).json({
      data: null,
      errors: [{
        message
      }]
    });
  }
};

/* harmony default export */ const wishlist = (wishlistEndpoint);
// EXTERNAL MODULE: ./framework/bigcommerce/api/utils/get-customer-id.ts
var get_customer_id = __webpack_require__(8248);
;// CONCATENATED MODULE: ./framework/bigcommerce/api/endpoints/wishlist/get-wishlist.ts


// Return wishlist info
const getWishlist = async ({
  res,
  body: {
    customerToken,
    includeProducts
  },
  config,
  commerce
}) => {
  var _result$data;

  let result = {};

  if (customerToken) {
    const customerId = customerToken && (await (0,get_customer_id/* default */.Z)({
      customerToken,
      config
    }));

    if (!customerId) {
      // If the customerToken is invalid, then this request is too
      return res.status(404).json({
        data: null,
        errors: [{
          message: 'Wishlist not found'
        }]
      });
    }

    const {
      wishlist
    } = await commerce.getCustomerWishlist({
      variables: {
        customerId
      },
      includeProducts,
      config
    });
    result = {
      data: wishlist
    };
  }

  res.status(200).json({
    data: (_result$data = result.data) !== null && _result$data !== void 0 ? _result$data : null
  });
};

/* harmony default export */ const get_wishlist = (getWishlist);
// EXTERNAL MODULE: ./framework/bigcommerce/api/utils/parse-item.ts
var parse_item = __webpack_require__(9576);
;// CONCATENATED MODULE: ./framework/bigcommerce/api/endpoints/wishlist/add-item.ts



// Return wishlist info
const addItem = async ({
  res,
  body: {
    customerToken,
    item
  },
  config,
  commerce
}) => {
  if (!item) {
    return res.status(400).json({
      data: null,
      errors: [{
        message: 'Missing item'
      }]
    });
  }

  const customerId = customerToken && (await (0,get_customer_id/* default */.Z)({
    customerToken,
    config
  }));

  if (!customerId) {
    return res.status(400).json({
      data: null,
      errors: [{
        message: 'Invalid request'
      }]
    });
  }

  const {
    wishlist
  } = await commerce.getCustomerWishlist({
    variables: {
      customerId
    },
    config
  });
  const options = {
    method: 'POST',
    body: JSON.stringify(wishlist ? {
      items: [(0,parse_item/* parseWishlistItem */.x)(item)]
    } : {
      name: 'Wishlist',
      customer_id: customerId,
      items: [(0,parse_item/* parseWishlistItem */.x)(item)],
      is_public: false
    })
  };
  const {
    data
  } = wishlist ? await config.storeApiFetch(`/v3/wishlists/${wishlist.id}/items`, options) : await config.storeApiFetch('/v3/wishlists', options);
  res.status(200).json({
    data
  });
};

/* harmony default export */ const add_item = (addItem);
;// CONCATENATED MODULE: ./framework/bigcommerce/api/endpoints/wishlist/remove-item.ts


// Return wishlist info
const removeItem = async ({
  res,
  body: {
    customerToken,
    itemId
  },
  config,
  commerce
}) => {
  var _result$data;

  const customerId = customerToken && (await (0,get_customer_id/* default */.Z)({
    customerToken,
    config
  }));
  const {
    wishlist
  } = customerId && (await commerce.getCustomerWishlist({
    variables: {
      customerId
    },
    config
  })) || {};

  if (!wishlist || !itemId) {
    return res.status(400).json({
      data: null,
      errors: [{
        message: 'Invalid request'
      }]
    });
  }

  const result = await config.storeApiFetch(`/v3/wishlists/${wishlist.id}/items/${itemId}`, {
    method: 'DELETE'
  });
  const data = (_result$data = result === null || result === void 0 ? void 0 : result.data) !== null && _result$data !== void 0 ? _result$data : null;
  res.status(200).json({
    data
  });
};

/* harmony default export */ const remove_item = (removeItem);
;// CONCATENATED MODULE: ./framework/bigcommerce/api/endpoints/wishlist/index.ts





const handlers = {
  getWishlist: get_wishlist,
  addItem: add_item,
  removeItem: remove_item
};
const wishlistApi = (0,api/* createEndpoint */.dg)({
  handler: wishlist,
  handlers
});
/* harmony default export */ const endpoints_wishlist = (wishlistApi);
// EXTERNAL MODULE: ./lib/api/commerce.ts + 17 modules
var commerce = __webpack_require__(1862);
;// CONCATENATED MODULE: ./pages/api/wishlist.ts


/* harmony default export */ const api_wishlist = (endpoints_wishlist(commerce/* default */.Z));

/***/ }),

/***/ 2937:
/***/ ((module) => {

module.exports = require("@vercel/fetch");

/***/ }),

/***/ 2740:
/***/ ((module) => {

module.exports = require("immutability-helper");

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [370,862,971], () => (__webpack_exec__(340)));
module.exports = __webpack_exports__;

})();