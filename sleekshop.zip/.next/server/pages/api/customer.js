"use strict";
(() => {
var exports = {};
exports.id = 858;
exports.ids = [858];
exports.modules = {

/***/ 3694:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ api_customer)
});

// EXTERNAL MODULE: ./framework/commerce/api/index.ts + 1 modules
var api = __webpack_require__(9520);
// EXTERNAL MODULE: ./framework/commerce/api/utils/errors.ts
var errors = __webpack_require__(3076);
// EXTERNAL MODULE: ./framework/commerce/api/utils/is-allowed-operation.ts + 1 modules
var is_allowed_operation = __webpack_require__(9218);
;// CONCATENATED MODULE: ./framework/commerce/api/endpoints/customer/index.ts
function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) { symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); } keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }




const customerEndpoint = async ctx => {
  const {
    req,
    res,
    handlers
  } = ctx;

  if (!(0,is_allowed_operation/* default */.Z)(req, res, {
    GET: handlers['getLoggedInCustomer']
  })) {
    return;
  }

  try {
    const body = null;
    return await handlers['getLoggedInCustomer'](_objectSpread(_objectSpread({}, ctx), {}, {
      body
    }));
  } catch (error) {
    console.error(error);
    const message = error instanceof errors/* CommerceAPIError */.$ ? 'An unexpected error ocurred with the Commerce API' : 'An unexpected error ocurred';
    res.status(500).json({
      data: null,
      errors: [{
        message
      }]
    });
  }
};

/* harmony default export */ const customer = (customerEndpoint);
;// CONCATENATED MODULE: ./framework/bigcommerce/api/endpoints/customer/get-logged-in-customer.ts
const getLoggedInCustomerQuery =
/* GraphQL */
`
  query getLoggedInCustomer {
    customer {
      entityId
      firstName
      lastName
      email
      company
      customerGroupId
      notes
      phone
      addressCount
      attributeCount
      storeCredit {
        value
        currencyCode
      }
    }
  }
`;

const getLoggedInCustomer = async ({
  req,
  res,
  config
}) => {
  const token = req.cookies[config.customerCookie];

  if (token) {
    const {
      data
    } = await config.fetch(getLoggedInCustomerQuery, undefined, {
      headers: {
        cookie: `${config.customerCookie}=${token}`
      }
    });
    const {
      customer
    } = data;

    if (!customer) {
      return res.status(400).json({
        data: null,
        errors: [{
          message: 'Customer not found',
          code: 'not_found'
        }]
      });
    }

    return res.status(200).json({
      data: {
        customer
      }
    });
  }

  res.status(200).json({
    data: null
  });
};

/* harmony default export */ const get_logged_in_customer = (getLoggedInCustomer);
;// CONCATENATED MODULE: ./framework/bigcommerce/api/endpoints/customer/index.ts



const handlers = {
  getLoggedInCustomer: get_logged_in_customer
};
const customerApi = (0,api/* createEndpoint */.dg)({
  handler: customer,
  handlers
});
/* harmony default export */ const endpoints_customer = (customerApi);
// EXTERNAL MODULE: ./lib/api/commerce.ts + 17 modules
var commerce = __webpack_require__(1862);
;// CONCATENATED MODULE: ./pages/api/customer/index.ts


/* harmony default export */ const api_customer = (endpoints_customer(commerce/* default */.Z));

/***/ }),

/***/ 2937:
/***/ ((module) => {

module.exports = require("@vercel/fetch");

/***/ }),

/***/ 2740:
/***/ ((module) => {

module.exports = require("immutability-helper");

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [370,862,971], () => (__webpack_exec__(3694)));
module.exports = __webpack_exports__;

})();