(() => {
var exports = {};
exports.id = 277;
exports.ids = [277];
exports.modules = {

/***/ 5044:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ Profile),
  "getStaticProps": () => (/* binding */ getStaticProps)
});

// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(9297);
// EXTERNAL MODULE: ./framework/bigcommerce/customer/use-customer.tsx + 1 modules
var use_customer = __webpack_require__(7951);
// EXTERNAL MODULE: ./lib/api/commerce.ts + 17 modules
var commerce = __webpack_require__(1862);
// EXTERNAL MODULE: ./components/common/Layout/Layout.tsx + 36 modules
var Layout = __webpack_require__(6428);
// EXTERNAL MODULE: ./components/ui/context.tsx
var context = __webpack_require__(7079);
// EXTERNAL MODULE: ./components/ui/Container/Container.tsx
var Container = __webpack_require__(9698);
;// CONCATENATED MODULE: ./assets/sleekshop-new-svg/hello-icon-image.svg
var _rect, _path;

function _extends() { _extends = Object.assign || function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; }; return _extends.apply(this, arguments); }



var SvgHelloIconImage = function SvgHelloIconImage(props) {
  return /*#__PURE__*/external_react_.createElement("svg", _extends({
    width: 80,
    height: 80,
    fill: "none",
    xmlns: "http://www.w3.org/2000/svg"
  }, props), _rect || (_rect = /*#__PURE__*/external_react_.createElement("rect", {
    width: 80,
    height: 80,
    rx: 40,
    fill: "#637381"
  })), _path || (_path = /*#__PURE__*/external_react_.createElement("path", {
    fillRule: "evenodd",
    clipRule: "evenodd",
    d: "m45.5 17 4.997 13.503L64 35.5l-13.503 4.997L45.5 54l-4.997-13.503L27 35.5l13.503-4.997L45.5 17Zm-2.904 15.596-7.85 2.904 7.85 2.904 2.904 7.85 2.904-7.85 7.85-2.904-7.85-2.904-2.904-7.85-2.904 7.85ZM26 45l2.43 6.57L35 54l-6.57 2.43L26 63l-2.43-6.57L17 54l6.57-2.43L26 45Zm-1.413 7.587L20.77 54l3.818 1.413L26 59.23l1.413-3.818L31.23 54l-3.818-1.413L26 48.77l-1.413 3.818Z",
    fill: "#F7F8F9"
  })));
};

/* harmony default export */ const hello_icon_image = (SvgHelloIconImage);
;// CONCATENATED MODULE: ./assets/sleekshop-new-svg/shopping-bag.svg
var shopping_bag_path, _path2;

function shopping_bag_extends() { shopping_bag_extends = Object.assign || function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; }; return shopping_bag_extends.apply(this, arguments); }



var SvgShoppingBag = function SvgShoppingBag(props) {
  return /*#__PURE__*/external_react_.createElement("svg", shopping_bag_extends({
    width: 24,
    height: 24,
    fill: "none",
    xmlns: "http://www.w3.org/2000/svg"
  }, props), shopping_bag_path || (shopping_bag_path = /*#__PURE__*/external_react_.createElement("path", {
    d: "M16 8h-1.333a2.666 2.666 0 1 0-5.334 0H8c-.733 0-1.333.6-1.333 1.333v8c0 .734.6 1.334 1.333 1.334h8c.733 0 1.333-.6 1.333-1.334v-8C17.333 8.6 16.733 8 16 8Zm-4-1.333c.733 0 1.333.6 1.333 1.333h-2.666c0-.733.6-1.333 1.333-1.333Zm4 10.666H8v-8h1.333v1.334c0 .366.3.666.667.666.367 0 .667-.3.667-.666V9.333h2.666v1.334c0 .366.3.666.667.666.367 0 .667-.3.667-.666V9.333H16v8Z",
    fill: "#637381"
  })), _path2 || (_path2 = /*#__PURE__*/external_react_.createElement("path", {
    fillRule: "evenodd",
    clipRule: "evenodd",
    d: "M21.44 19.408a11.997 11.997 0 0 0-4.404-18.3A12.001 12.001 0 0 0 1.714 5.816V2.9a.5.5 0 0 0-.5-.5H.054A.054.054 0 0 0 0 2.454v4.653A1.463 1.463 0 0 0 1.463 8.57h4.484A.053.053 0 0 0 6 8.517V7.356a.5.5 0 0 0-.5-.5H3.104a10.298 10.298 0 1 1 11.234 15.188 10.3 10.3 0 0 1-11.465-5.3l-1.52.793a11.998 11.998 0 0 0 15.388 5.486 12 12 0 0 0 4.699-3.615Z",
    fill: "#637381"
  })));
};

/* harmony default export */ const shopping_bag = (SvgShoppingBag);
;// CONCATENATED MODULE: ./assets/sleekshop-new-svg/sticky-note-2.svg
var sticky_note_2_path;

function sticky_note_2_extends() { sticky_note_2_extends = Object.assign || function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; }; return sticky_note_2_extends.apply(this, arguments); }



var SvgStickyNote2 = function SvgStickyNote2(props) {
  return /*#__PURE__*/external_react_.createElement("svg", sticky_note_2_extends({
    width: 24,
    height: 24,
    fill: "none",
    xmlns: "http://www.w3.org/2000/svg"
  }, props), sticky_note_2_path || (sticky_note_2_path = /*#__PURE__*/external_react_.createElement("path", {
    d: "M19 5v9h-5v5H5V5h14Zm0-2H5c-1.1 0-2 .9-2 2v14c0 1.1.9 2 2 2h10l6-6V5c0-1.1-.9-2-2-2Zm-7 11H7v-2h5v2Zm5-4H7V8h10v2Z",
    fill: "#637381"
  })));
};

/* harmony default export */ const sticky_note_2 = (SvgStickyNote2);
;// CONCATENATED MODULE: ./assets/sleekshop-new-svg/SleekVault.svg
var SleekVault_path;

function SleekVault_extends() { SleekVault_extends = Object.assign || function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; }; return SleekVault_extends.apply(this, arguments); }



var SvgSleekVault = function SvgSleekVault(props) {
  return /*#__PURE__*/external_react_.createElement("svg", SleekVault_extends({
    width: 24,
    height: 24,
    fill: "none",
    xmlns: "http://www.w3.org/2000/svg"
  }, props), SleekVault_path || (SleekVault_path = /*#__PURE__*/external_react_.createElement("path", {
    fillRule: "evenodd",
    clipRule: "evenodd",
    d: "m12 1.678 2.788 7.534L22.322 12l-7.534 2.788L12 22.322l-2.788-7.534L1.678 12l7.534-2.788L12 1.678Zm-1.62 8.701L6 12l4.38 1.62L12 18l1.62-4.38L18 12l-4.38-1.62L12 6l-1.62 4.38Z",
    fill: "#637381"
  })));
};

/* harmony default export */ const SleekVault = (SvgSleekVault);
;// CONCATENATED MODULE: ./assets/sleekshop-new-svg/wishlist.svg
var wishlist_path;

function wishlist_extends() { wishlist_extends = Object.assign || function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; }; return wishlist_extends.apply(this, arguments); }



var SvgWishlist = function SvgWishlist(props) {
  return /*#__PURE__*/external_react_.createElement("svg", wishlist_extends({
    width: 24,
    height: 24,
    fill: "none",
    xmlns: "http://www.w3.org/2000/svg"
  }, props), wishlist_path || (wishlist_path = /*#__PURE__*/external_react_.createElement("path", {
    d: "M7.5 3.892C5.015 3.892 3 5.886 3 8.347c0 1.986.788 6.7 8.54 11.466a.887.887 0 0 0 .92 0C20.213 15.047 21 10.333 21 8.347c0-2.46-2.015-4.455-4.5-4.455s-4.5 2.7-4.5 2.7-2.015-2.7-4.5-2.7Z",
    stroke: "#637381",
    strokeWidth: 2,
    strokeLinecap: "round",
    strokeLinejoin: "round"
  })));
};

/* harmony default export */ const wishlist = (SvgWishlist);
;// CONCATENATED MODULE: ./assets/sleekshop-new-svg/recently-viewed.svg
var recently_viewed_path;

function recently_viewed_extends() { recently_viewed_extends = Object.assign || function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; }; return recently_viewed_extends.apply(this, arguments); }



var SvgRecentlyViewed = function SvgRecentlyViewed(props) {
  return /*#__PURE__*/external_react_.createElement("svg", recently_viewed_extends({
    width: 24,
    height: 24,
    fill: "none",
    xmlns: "http://www.w3.org/2000/svg"
  }, props), recently_viewed_path || (recently_viewed_path = /*#__PURE__*/external_react_.createElement("path", {
    d: "M13 3a9 9 0 0 0-9 9H1l3.89 3.89.07.14L9 12H6c0-3.87 3.13-7 7-7s7 3.13 7 7-3.13 7-7 7c-1.93 0-3.68-.79-4.94-2.06l-1.42 1.42A8.954 8.954 0 0 0 13 21a9 9 0 0 0 0-18Zm-1 5v5l4.25 2.52.77-1.28-3.52-2.09V8H12Z",
    fill: "#637381"
  })));
};

/* harmony default export */ const recently_viewed = (SvgRecentlyViewed);
;// CONCATENATED MODULE: ./assets/sleekshop-new-svg/message.svg
var message_path;

function message_extends() { message_extends = Object.assign || function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; }; return message_extends.apply(this, arguments); }



var SvgMessage = function SvgMessage(props) {
  return /*#__PURE__*/external_react_.createElement("svg", message_extends({
    width: 24,
    height: 24,
    fill: "none",
    xmlns: "http://www.w3.org/2000/svg"
  }, props), message_path || (message_path = /*#__PURE__*/external_react_.createElement("path", {
    d: "M4 4h16v12H5.17L4 17.17V4Zm0-2c-1.1 0-1.99.9-1.99 2L2 22l4-4h14c1.1 0 2-.9 2-2V4c0-1.1-.9-2-2-2H4Zm2 10h12v2H6v-2Zm0-3h12v2H6V9Zm0-3h12v2H6V6Z",
    fill: "#637381"
  })));
};

/* harmony default export */ const message = (SvgMessage);
;// CONCATENATED MODULE: ./assets/sleekshop-new-svg/edit-info.svg
var edit_info_path;

function edit_info_extends() { edit_info_extends = Object.assign || function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; }; return edit_info_extends.apply(this, arguments); }



var SvgEditInfo = function SvgEditInfo(props) {
  return /*#__PURE__*/external_react_.createElement("svg", edit_info_extends({
    width: 24,
    height: 24,
    fill: "none",
    xmlns: "http://www.w3.org/2000/svg"
  }, props), edit_info_path || (edit_info_path = /*#__PURE__*/external_react_.createElement("path", {
    d: "M19 2H5a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h4l3 3 3-3h4c1.1 0 2-.9 2-2V4c0-1.1-.9-2-2-2Zm0 16h-4.83l-.59.59L12 20.17l-1.59-1.59-.58-.58H5V4h14v14Zm-7-7c1.65 0 3-1.35 3-3s-1.35-3-3-3-3 1.35-3 3 1.35 3 3 3Zm0-4c.55 0 1 .45 1 1s-.45 1-1 1-1-.45-1-1 .45-1 1-1Zm6 8.58c0-2.5-3.97-3.58-6-3.58s-6 1.08-6 3.58V17h12v-1.42ZM8.48 15c.74-.51 2.23-1 3.52-1s2.78.49 3.52 1H8.48Z",
    fill: "#637381"
  })));
};

/* harmony default export */ const edit_info = (SvgEditInfo);
// EXTERNAL MODULE: ./assets/sleekshop-new-svg/addresses-icon.svg
var addresses_icon = __webpack_require__(3372);
;// CONCATENATED MODULE: ./assets/sleekshop-new-svg/payment-methods.svg
var payment_methods_path;

function payment_methods_extends() { payment_methods_extends = Object.assign || function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; }; return payment_methods_extends.apply(this, arguments); }



var SvgPaymentMethods = function SvgPaymentMethods(props) {
  return /*#__PURE__*/external_react_.createElement("svg", payment_methods_extends({
    width: 24,
    height: 24,
    fill: "none",
    xmlns: "http://www.w3.org/2000/svg"
  }, props), payment_methods_path || (payment_methods_path = /*#__PURE__*/external_react_.createElement("path", {
    d: "M20 4H4c-1.11 0-1.99.89-1.99 2L2 18c0 1.11.89 2 2 2h16c1.11 0 2-.89 2-2V6c0-1.11-.89-2-2-2Zm0 14H4v-6h16v6Zm0-10H4V6h16v2Z",
    fill: "#637381"
  })));
};

/* harmony default export */ const payment_methods = (SvgPaymentMethods);
;// CONCATENATED MODULE: ./assets/sleekshop-new-svg/signout.svg
var signout_path;

function signout_extends() { signout_extends = Object.assign || function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; }; return signout_extends.apply(this, arguments); }



var SvgSignout = function SvgSignout(props) {
  return /*#__PURE__*/external_react_.createElement("svg", signout_extends({
    width: 24,
    height: 24,
    fill: "none",
    xmlns: "http://www.w3.org/2000/svg"
  }, props), signout_path || (signout_path = /*#__PURE__*/external_react_.createElement("path", {
    d: "M13.91 15.59 12.5 17l-5-5 5-5 1.41 1.41L11.33 11H21v2h-9.67l2.58 2.59ZM5 3h14a2 2 0 0 1 2 2v4h-2V5H5v14h14v-4h2v4a2 2 0 0 1-2 2H5c-1.1 0-2-.9-2-2V5c0-1.1.9-2 2-2Z",
    fill: "#637381"
  })));
};

/* harmony default export */ const signout = (SvgSignout);
// EXTERNAL MODULE: ./framework/bigcommerce/auth/use-logout.tsx + 1 modules
var use_logout = __webpack_require__(4626);
// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(5282);
;// CONCATENATED MODULE: ./components/common/ProfileNavlink/profile_head.tsx


















const ProfileHead = ({
  userName,
  setShowPage,
  ShowPage,
  setShowOrderHistoryDetails
}) => {
  const logout = (0,use_logout/* default */.Z)();
  const {
    openModal,
    setModalView
  } = (0,context/* useUI */.l8)();
  const {
    data
  } = (0,use_customer/* default */.Z)();

  const HandleLogin = () => {
    setModalView('LOGIN_VIEW');
    return openModal();
  };

  return /*#__PURE__*/jsx_runtime_.jsx(jsx_runtime_.Fragment, {
    children: /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
      className: "left-menu",
      children: [/*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
        className: "name-and-details",
        children: [/*#__PURE__*/jsx_runtime_.jsx("div", {
          className: "name-icon",
          children: /*#__PURE__*/jsx_runtime_.jsx(hello_icon_image, {})
        }), /*#__PURE__*/jsx_runtime_.jsx("div", {
          className: "name-details",
          children: /*#__PURE__*/(0,jsx_runtime_.jsxs)("span", {
            children: ["Hello, ", /*#__PURE__*/jsx_runtime_.jsx("strong", {
              children: userName === null || userName === void 0 ? void 0 : userName.toUpperCase()
            })]
          })
        })]
      }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
        className: "status-and-point",
        children: [/*#__PURE__*/jsx_runtime_.jsx("div", {
          className: "status-details",
          children: /*#__PURE__*/(0,jsx_runtime_.jsxs)("span", {
            children: ["Your Status, ", /*#__PURE__*/jsx_runtime_.jsx("strong", {
              children: "Mogul"
            })]
          })
        }), /*#__PURE__*/jsx_runtime_.jsx("div", {
          className: "points-details",
          children: /*#__PURE__*/(0,jsx_runtime_.jsxs)("span", {
            children: ["Your Points, ", /*#__PURE__*/jsx_runtime_.jsx("strong", {
              children: "325"
            })]
          })
        })]
      }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
        className: "order-details",
        children: [/*#__PURE__*/jsx_runtime_.jsx("div", {
          className: "order-details-title",
          children: "Orders"
        }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("ul", {
          children: [/*#__PURE__*/(0,jsx_runtime_.jsxs)("li", {
            className: `${ShowPage === 1 && 'active'}`,
            onClick: () => setShowPage(1),
            children: [/*#__PURE__*/jsx_runtime_.jsx(shopping_bag, {}), /*#__PURE__*/jsx_runtime_.jsx("span", {
              children: "Buy it again"
            })]
          }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("li", {
            onClick: () => {
              setShowPage(2);
              setShowOrderHistoryDetails(false);
            },
            className: `${ShowPage === 2 && 'active'}`,
            children: [/*#__PURE__*/jsx_runtime_.jsx(sticky_note_2, {}), /*#__PURE__*/jsx_runtime_.jsx("span", {
              children: "Order History"
            })]
          })]
        })]
      }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
        className: "order-details",
        children: [/*#__PURE__*/jsx_runtime_.jsx("div", {
          className: "order-details-title",
          children: "Rewards"
        }), /*#__PURE__*/jsx_runtime_.jsx("ul", {
          children: /*#__PURE__*/(0,jsx_runtime_.jsxs)("li", {
            onClick: () => setShowPage(3),
            className: `${ShowPage === 3 && 'active'}`,
            children: [/*#__PURE__*/jsx_runtime_.jsx(SleekVault, {}), /*#__PURE__*/jsx_runtime_.jsx("span", {
              children: "SleekVault"
            })]
          })
        })]
      }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
        className: "order-details",
        children: [/*#__PURE__*/jsx_runtime_.jsx("div", {
          className: "order-details-title",
          children: "My Account"
        }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("ul", {
          children: [/*#__PURE__*/(0,jsx_runtime_.jsxs)("li", {
            onClick: () => setShowPage(4),
            className: `${ShowPage === 4 && 'active'}`,
            children: [/*#__PURE__*/jsx_runtime_.jsx(wishlist, {}), /*#__PURE__*/jsx_runtime_.jsx("span", {
              children: "Wishlist"
            })]
          }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("li", {
            onClick: () => setShowPage(5),
            className: `${ShowPage === 5 && 'active'}`,
            children: [/*#__PURE__*/jsx_runtime_.jsx(recently_viewed, {}), /*#__PURE__*/jsx_runtime_.jsx("span", {
              children: "Recently Viewed"
            })]
          }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("li", {
            onClick: () => setShowPage(6),
            className: `${ShowPage === 6 && 'active'}`,
            children: [/*#__PURE__*/jsx_runtime_.jsx(message, {}), /*#__PURE__*/jsx_runtime_.jsx("span", {
              children: "Messages"
            })]
          })]
        })]
      }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
        className: "order-details",
        children: [/*#__PURE__*/jsx_runtime_.jsx("div", {
          className: "order-details-title",
          children: "Account Settings"
        }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("ul", {
          children: [/*#__PURE__*/(0,jsx_runtime_.jsxs)("li", {
            onClick: () => setShowPage(7),
            className: `${ShowPage === 7 && 'active'}`,
            children: [/*#__PURE__*/jsx_runtime_.jsx(edit_info, {}), /*#__PURE__*/jsx_runtime_.jsx("span", {
              children: "Edit Info"
            })]
          }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("li", {
            onClick: () => setShowPage(8),
            className: `${ShowPage === 8 && 'active'}`,
            children: [/*#__PURE__*/jsx_runtime_.jsx(addresses_icon/* default */.Z, {}), /*#__PURE__*/jsx_runtime_.jsx("span", {
              children: "Addresses"
            })]
          }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("li", {
            onClick: () => setShowPage(9),
            className: `${ShowPage === 9 && 'active'}`,
            children: [/*#__PURE__*/jsx_runtime_.jsx(payment_methods, {}), /*#__PURE__*/jsx_runtime_.jsx("span", {
              children: "Payment Methods"
            })]
          }), data ? /*#__PURE__*/(0,jsx_runtime_.jsxs)("li", {
            onClick: () => logout(),
            children: [/*#__PURE__*/jsx_runtime_.jsx(signout, {}), /*#__PURE__*/jsx_runtime_.jsx("span", {
              children: "Sign Out"
            })]
          }) : /*#__PURE__*/(0,jsx_runtime_.jsxs)("li", {
            onClick: () => HandleLogin(),
            children: [/*#__PURE__*/jsx_runtime_.jsx("div", {
              style: {
                transform: 'rotate(180deg)'
              },
              children: /*#__PURE__*/jsx_runtime_.jsx(signout, {})
            }), /*#__PURE__*/jsx_runtime_.jsx("span", {
              children: "Sign In"
            })]
          })]
        })]
      })]
    })
  });
};

/* harmony default export */ const profile_head = (ProfileHead);
// EXTERNAL MODULE: ./node_modules/next/link.js
var next_link = __webpack_require__(1664);
// EXTERNAL MODULE: ./components/icons/Bag.tsx
var Bag = __webpack_require__(3426);
// EXTERNAL MODULE: ./framework/bigcommerce/cart/use-add-item.tsx + 1 modules
var use_add_item = __webpack_require__(3889);
// EXTERNAL MODULE: ./components/ProfileInnerPages/ProfileInner.module.css
var ProfileInner_module = __webpack_require__(2629);
var ProfileInner_module_default = /*#__PURE__*/__webpack_require__.n(ProfileInner_module);
;// CONCATENATED MODULE: ./assets/sleekshop-new-svg/addToCartPlus.svg
var addToCartPlus_path, addToCartPlus_path2;

function addToCartPlus_extends() { addToCartPlus_extends = Object.assign || function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; }; return addToCartPlus_extends.apply(this, arguments); }



var SvgAddToCartPlus = function SvgAddToCartPlus(props) {
  return /*#__PURE__*/external_react_.createElement("svg", addToCartPlus_extends({
    width: 32,
    height: 32,
    fill: "none",
    xmlns: "http://www.w3.org/2000/svg"
  }, props), addToCartPlus_path || (addToCartPlus_path = /*#__PURE__*/external_react_.createElement("path", {
    fill: "#95BFB8",
    d: "M0 0h32v32H0z"
  })), addToCartPlus_path2 || (addToCartPlus_path2 = /*#__PURE__*/external_react_.createElement("path", {
    d: "M16.764 8.361h-1.68a3.36 3.36 0 1 0-6.723 0h-1.68c-.925 0-1.681.756-1.681 1.68v10.084c0 .924.756 1.68 1.68 1.68h10.084c.924 0 1.68-.756 1.68-1.68V10.042c0-.925-.756-1.68-1.68-1.68Zm-5.042-1.68c.925 0 1.68.756 1.68 1.68h-3.36c0-.924.756-1.68 1.68-1.68Zm5.042 13.444H6.68V10.042h1.68v1.68c0 .462.378.84.84.84.463 0 .84-.378.84-.84v-1.68h3.362v1.68c0 .462.378.84.84.84.462 0 .84-.378.84-.84v-1.68h1.68v10.083ZM24.067 19.483a.733.733 0 1 0-1.467 0v2.2h-2.2a.733.733 0 0 0 0 1.467h2.2v2.2a.733.733 0 1 0 1.467 0v-2.2h2.2a.733.733 0 1 0 0-1.467h-2.2v-2.2Z",
    fill: "#F7F8F9"
  })));
};

/* harmony default export */ const addToCartPlus = (SvgAddToCartPlus);
;// CONCATENATED MODULE: ./assets/sleekshop-new-svg/Minus.svg
var Minus_path;

function Minus_extends() { Minus_extends = Object.assign || function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; }; return Minus_extends.apply(this, arguments); }



var SvgMinus = function SvgMinus(props) {
  return /*#__PURE__*/external_react_.createElement("svg", Minus_extends({
    width: 12,
    height: 2,
    fill: "none",
    xmlns: "http://www.w3.org/2000/svg"
  }, props), Minus_path || (Minus_path = /*#__PURE__*/external_react_.createElement("path", {
    d: "M.5.5v1h11v-1H.5Z",
    fill: "#50585E"
  })));
};

/* harmony default export */ const Minus = (SvgMinus);
;// CONCATENATED MODULE: ./assets/sleekshop-new-svg/Plus.svg
var Plus_path;

function Plus_extends() { Plus_extends = Object.assign || function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; }; return Plus_extends.apply(this, arguments); }



var SvgPlus = function SvgPlus(props) {
  return /*#__PURE__*/external_react_.createElement("svg", Plus_extends({
    width: 12,
    height: 12,
    fill: "none",
    xmlns: "http://www.w3.org/2000/svg"
  }, props), Plus_path || (Plus_path = /*#__PURE__*/external_react_.createElement("path", {
    d: "M5.5.5v5h-5v1h5v5h1v-5h5v-1h-5v-5h-1Z",
    fill: "#50585E"
  })));
};

/* harmony default export */ const Plus = (SvgPlus);
;// CONCATENATED MODULE: external "react-modal"
const external_react_modal_namespaceObject = require("react-modal");
var external_react_modal_default = /*#__PURE__*/__webpack_require__.n(external_react_modal_namespaceObject);
;// CONCATENATED MODULE: ./assets/sleekshop-new-svg/close.svg
function close_extends() { close_extends = Object.assign || function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; }; return close_extends.apply(this, arguments); }



var SvgClose = function SvgClose(props) {
  return /*#__PURE__*/external_react_.createElement("svg", close_extends({
    xmlns: "http://www.w3.org/2000/svg",
    width: 16,
    height: 16,
    viewBox: "0 0 256 256",
    xmlSpace: "preserve"
  }, props), /*#__PURE__*/external_react_.createElement("g", null, /*#__PURE__*/external_react_.createElement("g", {
    style: {
      stroke: "none",
      strokeWidth: 0,
      strokeDasharray: "none",
      strokeLinecap: "butt",
      strokeLinejoin: "miter",
      strokeMiterlimit: 10,
      fill: "none",
      fillRule: "nonzero",
      opacity: 1
    }
  }, /*#__PURE__*/external_react_.createElement("path", {
    d: "M47.098 45 89.565 2.532A1.482 1.482 0 1 0 87.467.434L45 42.902 2.532.435A1.482 1.482 0 1 0 .434 2.533L42.902 45 .435 87.468a1.482 1.482 0 1 0 2.098 2.097L45 47.098l42.468 42.468c.29.29.669.435 1.049.435s.759-.145 1.049-.435c.58-.58.58-1.518 0-2.098L47.098 45z",
    style: {
      stroke: "none",
      strokeWidth: 1,
      strokeDasharray: "none",
      strokeLinecap: "butt",
      strokeLinejoin: "miter",
      strokeMiterlimit: 10,
      fill: "#000",
      fillRule: "nonzero",
      opacity: 1
    },
    transform: "translate(1.964 1.964) scale(2.8008)"
  }))));
};

/* harmony default export */ const sleekshop_new_svg_close = (SvgClose);
;// CONCATENATED MODULE: ./components/ProfileInnerPages/Modals/AddToCartModal.jsx
function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) { symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); } keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }










const customStyles = {
  content: {
    top: '20%',
    left: '0px',
    right: '0px',
    bottom: '0px',
    width: '100vw',
    position: "fixed",
    inset: "0px",
    backgroundColor: "rgb(0 0 0 / 35%)"
  }
};

const ModalCompo = ({
  setShowPartialProductDetailsPage,
  ShowPartialProductDetailsPage,
  CurrentObj
}) => {
  var _CurrentObj$product_o;

  const addItem = (0,use_add_item/* default */.Z)();

  function closeModal(e) {
    setShowPartialProductDetailsPage(false);
    return false;
  }

  const {
    0: itemCountState,
    1: setitemCountState
  } = (0,external_react_.useState)({
    val: 1,
    status: '',
    diableAddToCart: false
  });

  const handleDecrement = () => {
    if (itemCountState.val > 1) {
      setitemCountState(prevState => _objectSpread(_objectSpread({}, prevState), {}, {
        val: itemCountState.val - 1
      }));

      if (itemCountState.val - 1 <= CurrentObj.quantity) {
        let itemStatus = 'inStock';
        setitemCountState(prevState => _objectSpread(_objectSpread({}, prevState), {}, {
          status: itemStatus,
          diableAddToCart: false
        }));
      }
    }
  };

  const handleIncrement = () => {
    if (CurrentObj.quantity > itemCountState.val) {
      setitemCountState(prevState => _objectSpread(_objectSpread({}, prevState), {}, {
        val: itemCountState.val + 1
      }));
    } else {
      let itemStatus = 'outOfStock';
      setitemCountState(prevState => _objectSpread(_objectSpread({}, prevState), {}, {
        val: itemCountState.val + 1,
        status: itemStatus,
        diableAddToCart: true
      }));
    }
  };

  return /*#__PURE__*/jsx_runtime_.jsx((external_react_modal_default()), {
    isOpen: ShowPartialProductDetailsPage,
    onRequestClose: e => closeModal(e),
    style: customStyles,
    className: "ModalUpperMostParent",
    children: /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
      className: "maskForProductDetailsPage",
      children: [/*#__PURE__*/jsx_runtime_.jsx("div", {
        className: "d-flex align-items-center justify-content-end closeSvg ",
        children: /*#__PURE__*/jsx_runtime_.jsx("button", {
          onClick: e => closeModal(e),
          children: /*#__PURE__*/jsx_runtime_.jsx(sleekshop_new_svg_close, {})
        })
      }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
        className: "detailproductCardParent align-items-center",
        children: [/*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
          className: "detailproductCard detailproductCardAddTCM",
          children: [/*#__PURE__*/jsx_runtime_.jsx("div", {
            className: "productCardImgParent productCardImgParentmodal d-flex align-items-center justify-content-center",
            children: /*#__PURE__*/jsx_runtime_.jsx("img", {
              className: "detailProductImg ",
              src: CurrentObj === null || CurrentObj === void 0 ? void 0 : CurrentObj.prod_image,
              alt: "image not found"
            })
          }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
            className: "detailsParentModal",
            children: [/*#__PURE__*/jsx_runtime_.jsx("div", {
              className: "Product-Model-Parent mt-3 skuFontSt",
              children: /*#__PURE__*/(0,jsx_runtime_.jsxs)("p", {
                className: "Product-Model",
                children: ["SKU: ", CurrentObj === null || CurrentObj === void 0 ? void 0 : CurrentObj.sku]
              })
            }), /*#__PURE__*/jsx_runtime_.jsx("div", {
              className: "mt-12 CurrentObjNameP productName",
              children: /*#__PURE__*/jsx_runtime_.jsx("p", {
                className: "Product-Name",
                children: CurrentObj === null || CurrentObj === void 0 ? void 0 : CurrentObj.name
              })
            }), /*#__PURE__*/jsx_runtime_.jsx("p", {
              className: "Product-brand mt-12 productBrandText",
              children: CurrentObj === null || CurrentObj === void 0 ? void 0 : (_CurrentObj$product_o = CurrentObj.product_options[0]) === null || _CurrentObj$product_o === void 0 ? void 0 : _CurrentObj$product_o.display_value
            }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("p", {
              className: "Product-price mt-12 productPriceAdd",
              children: ["$ ", Number(CurrentObj === null || CurrentObj === void 0 ? void 0 : CurrentObj.price_inc_tax).toFixed(2)]
            })]
          })]
        }), /*#__PURE__*/jsx_runtime_.jsx("div", {
          className: `${(ProfileInner_module_default()).incrementParent} ${(ProfileInner_module_default()).incrementParentModel}  mt-2`,
          children: /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
            className: `d-flex justify-content-center align-items-center`,
            children: [/*#__PURE__*/jsx_runtime_.jsx("p", {
              className: `${(ProfileInner_module_default()).detailsQtyText}`,
              children: "QTY"
            }), /*#__PURE__*/jsx_runtime_.jsx("button", {
              className: `${(ProfileInner_module_default()).decrementBtn}`,
              onClick: () => {
                return handleDecrement();
              },
              children: /*#__PURE__*/jsx_runtime_.jsx(Minus, {})
            }), /*#__PURE__*/jsx_runtime_.jsx("input", {
              disabled: true,
              className: `${(ProfileInner_module_default()).inputEDCartVal}  ${itemCountState.status === 'outOfStock' ? (ProfileInner_module_default()).outOfStock : itemCountState.status === 'inStock' && (ProfileInner_module_default()).inStock}`,
              value: itemCountState.val
            }), /*#__PURE__*/jsx_runtime_.jsx("button", {
              className: ` ${(ProfileInner_module_default()).incrementBtn} `,
              onClick: () => {
                return handleIncrement();
              },
              children: /*#__PURE__*/jsx_runtime_.jsx(Plus, {})
            })]
          })
        }), /*#__PURE__*/jsx_runtime_.jsx("button", {
          disabled: itemCountState.diableAddToCart,
          className: "h6AddToCart detailsh6AddToCart detailsh6AddToCartModel",
          onClick: async () => {
            let productId = CurrentObj === null || CurrentObj === void 0 ? void 0 : CurrentObj.product_id;
            let variantId = CurrentObj === null || CurrentObj === void 0 ? void 0 : CurrentObj.variant_id;
            await addItem({
              productId,
              variantId,
              quantity: itemCountState.val
            });
            closeModal();
          },
          children: "ADD TO BAG"
        })]
      })]
    })
  });
};

/* harmony default export */ const AddToCartModal = (ModalCompo);
;// CONCATENATED MODULE: ./components/ProfileInnerPages/orders.tsx
// import type { GetStaticPropsContext } from 'next'














function Orders() {
  const {
    0: orderedItem,
    1: setorderedItem
  } = (0,external_react_.useState)([]);
  const {
    openSidebar
  } = (0,context/* useUI */.l8)();
  const {
    0: itemCountState,
    1: setitemCountState
  } = (0,external_react_.useState)([{
    id: 0,
    val: 1,
    status: '',
    diableAddToCart: false
  }]);
  const {
    0: ShowPartialProductDetailsPage,
    1: setShowPartialProductDetailsPage
  } = (0,external_react_.useState)(false);
  const {
    data: customer
  } = (0,use_customer/* default */.Z)();
  const addItem = (0,use_add_item/* default */.Z)();
  const {
    0: CurrentObj,
    1: setCurrentObj
  } = (0,external_react_.useState)(null);
  (0,external_react_.useEffect)(() => {
    let cid = customer === null || customer === void 0 ? void 0 : customer.entityId;

    if (customer && customer !== null && customer !== void 0 && customer.entityId) {
      fetch('https://www.ystore.us/sleekshop/getOrderProducts.php?customer_id=' + cid).then(response => response.json()).then(rs1 => {
        setorderedItem(rs1); // rs1.map((order: any, index: any) => {
        //   let productQuantity = order?.quantity || 0
        //   let newObj = {
        //     id: index,
        //     val: productQuantity >= 2 ? 2 : 1,
        //     status: '',
        //     diableAddToCart: false,
        //   }
        //   let newArr = [...itemCountState, newObj] // copying the old datas array
        //   setitemCountState(newArr)
        // })
      });
    }
  }, [customer]);

  const handleDecrement = (index, incrementData) => {
    let newArr = [...incrementData]; // copying the old datas array

    newArr.map(oneObjOfNewArray => {
      if (oneObjOfNewArray.id === index) {
        if (oneObjOfNewArray.val > 1) {
          oneObjOfNewArray.val = oneObjOfNewArray.val - 1;
          let newArr = [...incrementData]; // copying the old datas array

          newArr.map(oneObjOfNewArray => {
            if (oneObjOfNewArray.id === index) {
              oneObjOfNewArray.status = 'inStock';
              oneObjOfNewArray.diableAddToCart = false;
            }

            return;
          });
          return setitemCountState(newArr);
        }
      }
    });
    return setitemCountState(newArr);
  };

  const handleIncrement = (index, productQuantity, incrementData) => {
    const checkExistanceFunc = param => {
      // incrementData[index]
      let res = false;
      incrementData.map(oneObjOfState => {
        if (param === 'id' && oneObjOfState.id === index) {
          res = true;

          if (productQuantity > oneObjOfState.val) {
            let newArr = [...incrementData]; // copying the old datas array

            newArr.map(oneObjOfNewArray => {
              if (oneObjOfNewArray.id === index) {
                oneObjOfNewArray.val = oneObjOfNewArray.val + 1;
              }

              return;
            });
            return setitemCountState(newArr);
          } else {
            let newArr = [...incrementData]; // copying the old datas array

            newArr.map(oneObjOfNewArray => {
              if (oneObjOfNewArray.id === index && oneObjOfNewArray.val !== productQuantity + 1) {
                oneObjOfNewArray.val = oneObjOfNewArray.val + 1;
                oneObjOfNewArray.status = 'outOfStock';
                oneObjOfNewArray.diableAddToCart = true;
              }

              return;
            });
            return setitemCountState(newArr);
          }
        }

        return;
      });
      return [res];
    };

    if (checkExistanceFunc('id')[0]) {
      return;
    } else {
      let newObj = {
        id: index,
        val: productQuantity >= 2 ? 2 : 1,
        status: '',
        diableAddToCart: false
      };
      let newArr = [...incrementData, newObj]; // copying the old datas array

      setitemCountState(newArr);
    }
  };

  const handleRenderingItemCount = (index, incrementData) => {
    let val = 1;
    let stockStatus = '';
    let diableAddToCart = false;
    incrementData.map(eachObjOfState => {
      if (eachObjOfState.id === index) {
        val = eachObjOfState.val;
        stockStatus = eachObjOfState.status;
        diableAddToCart = eachObjOfState.diableAddToCart;
      }
    });
    return [val, stockStatus, diableAddToCart];
  };

  return /*#__PURE__*/(0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
    children: [ShowPartialProductDetailsPage && /*#__PURE__*/jsx_runtime_.jsx(AddToCartModal, {
      setShowPartialProductDetailsPage: setShowPartialProductDetailsPage,
      ShowPartialProductDetailsPage: ShowPartialProductDetailsPage,
      CurrentObj: CurrentObj
    }), Array.isArray(orderedItem) && orderedItem.length > 0 ? /*#__PURE__*/jsx_runtime_.jsx(jsx_runtime_.Fragment, {
      children: /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
        className: "MainContentInnerdiv mb-2",
        children: [/*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
          className: "mainContentChild d-flex justify-content-between",
          children: [/*#__PURE__*/jsx_runtime_.jsx("div", {
            className: "Heading buyItAgainHeading",
            children: "Buy It Again"
          }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
            className: "Heading itemQuantity",
            children: [orderedItem === null || orderedItem === void 0 ? void 0 : orderedItem.length, " Items"]
          })]
        }), /*#__PURE__*/jsx_runtime_.jsx("div", {
          className: "d-flex row",
          children: orderedItem.map((order, index) => {
            var _order$product_option;

            let productQuantity = (order === null || order === void 0 ? void 0 : order.quantity) || 0;
            let Model = order === null || order === void 0 ? void 0 : (_order$product_option = order.product_options[0]) === null || _order$product_option === void 0 ? void 0 : _order$product_option.display_value;
            Model = Model.replace('option :', '');
            Model.replace('Model', '');
            Model = Model.replace('Color :', '');
            Model = Model.replace('Size :', '');
            return /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
              className: "productCard",
              children: [/*#__PURE__*/jsx_runtime_.jsx("div", {
                className: "productCardImgParent",
                children: /*#__PURE__*/jsx_runtime_.jsx("img", {
                  className: "ProductImg",
                  src: order === null || order === void 0 ? void 0 : order.prod_image,
                  alt: "image not found"
                })
              }), /*#__PURE__*/jsx_runtime_.jsx("div", {
                className: "Product-Model-Parent mt-3 skuParent",
                children: /*#__PURE__*/(0,jsx_runtime_.jsxs)("p", {
                  className: "Product-Model skuFontSt",
                  children: ["SKU: ", order.sku]
                })
              }), /*#__PURE__*/jsx_runtime_.jsx("div", {
                className: "mt-2 orderNameP ",
                children: /*#__PURE__*/jsx_runtime_.jsx(next_link.default, {
                  href: `/products/${order === null || order === void 0 ? void 0 : order.name.split(' ').join('-').split('(').join('').split(')').join('')}`,
                  children: /*#__PURE__*/jsx_runtime_.jsx("a", {
                    children: /*#__PURE__*/jsx_runtime_.jsx("p", {
                      className: "Product-Name productName",
                      children: order === null || order === void 0 ? void 0 : order.name
                    })
                  })
                })
              }), /*#__PURE__*/jsx_runtime_.jsx("div", {
                className: "productBrandP mt-2",
                children: /*#__PURE__*/jsx_runtime_.jsx("p", {
                  className: "Product-brand productBrandText",
                  children: Model
                })
              }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
                className: "mt-2 d-flex align-items-center justify-content-between pPrice_AddToCart ",
                children: [/*#__PURE__*/(0,jsx_runtime_.jsxs)("p", {
                  className: "Product-price productPriceAdd",
                  children: ["$ ", Number(order === null || order === void 0 ? void 0 : order.price_inc_tax).toFixed(2)]
                }), /*#__PURE__*/jsx_runtime_.jsx("p", {
                  className: "addToCartButton",
                  onClick: () => {
                    setCurrentObj(order);
                    setShowPartialProductDetailsPage(true);
                  },
                  children: /*#__PURE__*/jsx_runtime_.jsx(addToCartPlus, {})
                })]
              }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
                className: "AddToCartOnHover",
                children: [/*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
                  className: `${(ProfileInner_module_default()).incrementParent}`,
                  children: [/*#__PURE__*/jsx_runtime_.jsx("span", {
                    className: `${(ProfileInner_module_default()).QtyText}`,
                    children: "QTY"
                  }), /*#__PURE__*/jsx_runtime_.jsx("button", {
                    className: `${(ProfileInner_module_default()).decrementBtn}`,
                    onClick: () => {
                      return handleDecrement(index, itemCountState);
                    },
                    children: /*#__PURE__*/jsx_runtime_.jsx(Minus, {})
                  }), /*#__PURE__*/jsx_runtime_.jsx("input", {
                    disabled: true,
                    className: `${(ProfileInner_module_default()).inputEDCartVal} ${handleRenderingItemCount(index, itemCountState)[1] === 'outOfStock' ? (ProfileInner_module_default()).outOfStock : handleRenderingItemCount(index, itemCountState)[1] === 'inStock' && (ProfileInner_module_default()).inStock}`,
                    value: Number(handleRenderingItemCount(index, itemCountState)[0])
                  }), /*#__PURE__*/jsx_runtime_.jsx("button", {
                    className: ` ${(ProfileInner_module_default()).incrementBtn} `,
                    onClick: () => {
                      return handleIncrement(index, productQuantity, itemCountState);
                    },
                    children: /*#__PURE__*/jsx_runtime_.jsx(Plus, {})
                  })]
                }), /*#__PURE__*/jsx_runtime_.jsx("button", {
                  disabled: Boolean(handleRenderingItemCount(index, itemCountState)[2]),
                  className: `h6AddToCart`,
                  onClick: async () => {
                    let productId = order === null || order === void 0 ? void 0 : order.product_id;
                    let variantId = order === null || order === void 0 ? void 0 : order.variant_id;
                    let qty = handleRenderingItemCount(index, itemCountState)[0];
                    await addItem({
                      productId,
                      variantId,
                      quantity: Number(qty)
                    });
                    openSidebar();
                  },
                  children: "ADD TO BAG"
                })]
              })]
            });
          })
        })]
      })
    }) : /*#__PURE__*/jsx_runtime_.jsx(jsx_runtime_.Fragment, {
      children: /*#__PURE__*/jsx_runtime_.jsx("div", {
        className: "MainContentInnerdiv mb-2",
        children: /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
          className: "flex-1 PaddingForNoItemForDeskTopView flex flex-col justify-center items-center ",
          children: [/*#__PURE__*/jsx_runtime_.jsx("span", {
            className: "border border-dashed border-secondary rounded-full flex items-center justify-center w-16 h-16 p-12 bg-primary text-primary",
            children: /*#__PURE__*/jsx_runtime_.jsx(Bag/* default */.Z, {
              className: "absolute"
            })
          }), /*#__PURE__*/jsx_runtime_.jsx("h2", {
            className: "pt-6 text-2xl font-bold tracking-wide text-center",
            children: "No Products found"
          })]
        })
      })
    })]
  });
}
// EXTERNAL MODULE: ./components/checkout/PaymentWidget/PaymentWidget.tsx
var PaymentWidget = __webpack_require__(732);
// EXTERNAL MODULE: ./components/checkout/PaymentMethodView/PaymentMethodView.tsx
var PaymentMethodView = __webpack_require__(2029);
;// CONCATENATED MODULE: ./components/ProfileInnerPages/payments.tsx







function payments_Orders() {
  const {
    0: isValid,
    1: setisValid
  } = (0,external_react_.useState)(false);
  return /*#__PURE__*/jsx_runtime_.jsx(jsx_runtime_.Fragment, {
    children: /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
      className: "MainContentInnerdiv mb-2 orderHistory d-flex justify-content-between",
      style: {
        flexDirection: 'column'
      },
      children: [/*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
        className: "flex-1 PaddingForNoItemForDeskTopView flex flex-col justify-center items-center ",
        children: [/*#__PURE__*/jsx_runtime_.jsx("span", {
          className: "border border-dashed border-secondary rounded-full flex items-center justify-center w-16 h-16 p-12 bg-primary text-primary",
          children: /*#__PURE__*/jsx_runtime_.jsx(Bag/* default */.Z, {
            className: "absolute"
          })
        }), /*#__PURE__*/jsx_runtime_.jsx("h2", {
          className: "pt-6 text-2xl font-bold tracking-wide text-center",
          children: "No Payment method(s) found"
        })]
      }), /*#__PURE__*/jsx_runtime_.jsx("div", {
        onClick: () => setisValid(true),
        children: isValid ? /*#__PURE__*/jsx_runtime_.jsx(PaymentMethodView/* default */.Z, {}) : /*#__PURE__*/jsx_runtime_.jsx(PaymentWidget/* default */.Z, {
          isValid: isValid
        })
      })]
    })
  });
}
// EXTERNAL MODULE: external "js-cookie"
var external_js_cookie_ = __webpack_require__(6155);
var external_js_cookie_default = /*#__PURE__*/__webpack_require__.n(external_js_cookie_);
;// CONCATENATED MODULE: ./components/ProfileInnerPages/recentitems.tsx








function RecentItems() {
  const {
    0: orderedItem,
    1: setorderedItem
  } = (0,external_react_.useState)([]);
  const {
    data: customer
  } = (0,use_customer/* default */.Z)();
  (0,external_react_.useEffect)(() => {
    if (customer && customer !== null && customer !== void 0 && customer.entityId) {
      let productCookie = external_js_cookie_default().get('recently_viewed_products') || '["181986"]';
      const parsedCookie = JSON.parse(productCookie);

      if (parsedCookie.length > 0) {
        fetch('https://www.ystore.us/sleekshop/getProducts.php', {
          // Adding method type
          method: 'POST',
          // Adding body or contents to send
          body: JSON.stringify([...parsedCookie])
        }).then(res => {
          return res.json();
        }).then(res => {
          if (res.success) {
            setorderedItem(res.data);
          }
        });
      }
    }
  }, [customer]);
  return /*#__PURE__*/jsx_runtime_.jsx(jsx_runtime_.Fragment, {
    children: Array.isArray(orderedItem) && orderedItem.length > 0 ? /*#__PURE__*/jsx_runtime_.jsx(jsx_runtime_.Fragment, {
      children: /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
        className: "MainContentInnerdiv mb-2",
        children: [/*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
          className: "mainContentChild d-flex justify-content-between",
          children: [/*#__PURE__*/jsx_runtime_.jsx("div", {
            className: "Heading buyItAgainHeading",
            children: "Recently Viewed "
          }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
            className: "Heading itemQuantity",
            children: [orderedItem === null || orderedItem === void 0 ? void 0 : orderedItem.length, " Items"]
          })]
        }), /*#__PURE__*/jsx_runtime_.jsx("div", {
          className: "d-flex row",
          children: orderedItem.map(order => {
            var _order$custom_url, _order$custom_url$url;

            let RedirectUrl = order === null || order === void 0 ? void 0 : (_order$custom_url = order.custom_url) === null || _order$custom_url === void 0 ? void 0 : (_order$custom_url$url = _order$custom_url.url) === null || _order$custom_url$url === void 0 ? void 0 : _order$custom_url$url.replace('.html', '');
            return /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
              className: "productCard",
              children: [/*#__PURE__*/jsx_runtime_.jsx("div", {
                className: "productCardImgParent",
                children: /*#__PURE__*/jsx_runtime_.jsx("img", {
                  className: "ProductImg",
                  src: order === null || order === void 0 ? void 0 : order.product_image,
                  alt: "image not found"
                })
              }), /*#__PURE__*/jsx_runtime_.jsx("div", {
                className: "Product-Model-Parent mt-3 skuParent",
                children: /*#__PURE__*/(0,jsx_runtime_.jsxs)("p", {
                  className: "Product-Model skuFontSt",
                  children: ["SKU: ", order === null || order === void 0 ? void 0 : order.sku]
                })
              }), /*#__PURE__*/jsx_runtime_.jsx("div", {
                className: "mt-2 orderNameP",
                children: /*#__PURE__*/jsx_runtime_.jsx(next_link.default, {
                  href: RedirectUrl,
                  children: /*#__PURE__*/jsx_runtime_.jsx("a", {
                    children: /*#__PURE__*/jsx_runtime_.jsx("p", {
                      className: "Product-Name productName",
                      children: order === null || order === void 0 ? void 0 : order.name
                    })
                  })
                })
              }), /*#__PURE__*/jsx_runtime_.jsx("div", {
                className: "productBrandP mt-2",
                children: /*#__PURE__*/jsx_runtime_.jsx("p", {
                  className: "Product-brand productBrandText",
                  children: order.brand_id
                })
              }), /*#__PURE__*/jsx_runtime_.jsx("div", {
                className: "mt-2 d-flex align-items-center justify-content-between pPrice_AddToCart ",
                children: /*#__PURE__*/(0,jsx_runtime_.jsxs)("p", {
                  className: "Product-price productPriceAdd",
                  children: ["$ ", Number(order === null || order === void 0 ? void 0 : order.price).toFixed(2)]
                })
              })]
            });
          })
        })]
      })
    }) : /*#__PURE__*/jsx_runtime_.jsx(jsx_runtime_.Fragment, {
      children: /*#__PURE__*/jsx_runtime_.jsx("div", {
        className: "MainContentInnerdiv mb-2",
        children: /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
          className: "flex-1 PaddingForNoItemForDeskTopView flex flex-col justify-center items-center ",
          children: [/*#__PURE__*/jsx_runtime_.jsx("span", {
            className: "border border-dashed border-secondary rounded-full flex items-center justify-center w-16 h-16 p-12 bg-primary text-primary",
            children: /*#__PURE__*/jsx_runtime_.jsx(Bag/* default */.Z, {
              className: "absolute"
            })
          }), /*#__PURE__*/jsx_runtime_.jsx("h2", {
            className: "pt-6 text-2xl font-bold tracking-wide text-center",
            children: "No Products found"
          }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("h1", {
            children: ["View Some Products. ", /*#__PURE__*/jsx_runtime_.jsx(next_link.default, {
              href: "/",
              children: "Go to Home"
            })]
          })]
        })
      })
    })
  });
}
;// CONCATENATED MODULE: ./components/ProfileInnerPages/OrderhistoryDetails.tsx
// import { Bag } from '@components/icons'






function Reward(propData) {
  const {
    data: customer
  } = (0,use_customer/* default */.Z)();
  const {
    0: orderedItem,
    1: setorderedItem
  } = (0,external_react_.useState)({
    order_products: [],
    date_created: '',
    date_shipped: '',
    shipping_cost_inc_tax: '',
    base_shipping_cost: '',
    coupon_discount: '',
    subtotal_tax: '',
    total_inc_tax: '',
    billing_address: {
      first_name: '',
      last_name: '',
      street_1: '',
      country: '',
      country_iso2: '',
      zip: ''
    },
    shipping_addresses: [{
      first_name: '',
      last_name: '',
      street_1: '',
      country: '',
      country_iso2: '',
      zip: '',
      shipping_method: '',
      status: ''
    }]
  });
  (0,external_react_.useEffect)(() => {
    var _propData$data;

    let cid = propData === null || propData === void 0 ? void 0 : (_propData$data = propData.data) === null || _propData$data === void 0 ? void 0 : _propData$data.orderId;

    if (customer && customer !== null && customer !== void 0 && customer.entityId) {
      fetch('https://www.ystore.us/sleekshop/getAnOrder.php?order_id=' + cid).then(response => response.json()).then(rs1 => {
        setorderedItem(rs1);
      });
    }
  }, [customer]);
  return /*#__PURE__*/(0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
    children: [/*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
      className: "MainContentInnerdiv MainContentInnerdivOH MainContentInnerdivOHpd MainContentInnerdivOHMarMin  mb-2 orderHistory d-flex justify-content-between",
      children: [/*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
        className: `ThankYouCont`,
        children: [/*#__PURE__*/jsx_runtime_.jsx("p", {
          className: "Heading",
          children: "Order Details"
        }), /*#__PURE__*/jsx_runtime_.jsx("p", {
          className: "subHeading",
          children: "Thanks For Your Order"
        })]
      }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
        children: [/*#__PURE__*/(0,jsx_runtime_.jsxs)("p", {
          className: "subHeading",
          children: [/*#__PURE__*/jsx_runtime_.jsx("span", {
            className: "Heading",
            children: " Oder Id : "
          }), (orderedItem === null || orderedItem === void 0 ? void 0 : orderedItem.order_products[0]) && (orderedItem === null || orderedItem === void 0 ? void 0 : orderedItem.order_products[0]['order_id'])]
        }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("p", {
          className: "subHeading",
          children: [/*#__PURE__*/jsx_runtime_.jsx("span", {
            className: "Heading",
            children: " Order Data :"
          }), orderedItem.date_created]
        })]
      })]
    }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
      className: "MainContentInnerdiv MainContentInnerdivOH mb-2 BillingShipping",
      children: [/*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
        className: "Billing",
        children: [/*#__PURE__*/jsx_runtime_.jsx("p", {
          className: "BillingHeading Heading",
          children: "Billing"
        }), /*#__PURE__*/jsx_runtime_.jsx("p", {
          className: "subHeading",
          children: orderedItem.billing_address.first_name + ' ' + orderedItem.billing_address.last_name
        }), /*#__PURE__*/jsx_runtime_.jsx("p", {
          className: "subHeading",
          children: orderedItem.billing_address.street_1
        }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("p", {
          className: "subHeading",
          children: [orderedItem.billing_address.country, ",", orderedItem.billing_address.country_iso2, orderedItem.billing_address.zip]
        })]
      }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
        className: "Shipping",
        children: [/*#__PURE__*/jsx_runtime_.jsx("p", {
          className: "BillingHeading Heading",
          children: "Shipping"
        }), /*#__PURE__*/jsx_runtime_.jsx("p", {
          className: "subHeading",
          children: orderedItem.shipping_addresses[0].first_name + ' ' + orderedItem.shipping_addresses[0].last_name
        }), /*#__PURE__*/jsx_runtime_.jsx("p", {
          className: "subHeading",
          children: orderedItem.shipping_addresses[0].street_1
        }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("p", {
          className: "subHeading",
          children: [orderedItem.shipping_addresses[0].country, ",", orderedItem.shipping_addresses[0].country_iso2, orderedItem.shipping_addresses[0].zip]
        })]
      })]
    }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
      className: "MainContentInnerdiv MainContentInnerdivOH MainCoctOrdCont mb-2",
      children: [/*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
        className: "mainContentChild d-flex justify-content-between",
        children: [/*#__PURE__*/jsx_runtime_.jsx("div", {
          className: "Heading",
          children: "Products Ordered"
        }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
          className: "Heading",
          children: [orderedItem.order_products.length, " Items"]
        })]
      }), /*#__PURE__*/jsx_runtime_.jsx("div", {
        className: "d-flex justify-content-between row",
        children: orderedItem.order_products.map(ordPro => {
          return /*#__PURE__*/jsx_runtime_.jsx(jsx_runtime_.Fragment, {
            children: /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
              className: "productCard",
              children: [/*#__PURE__*/jsx_runtime_.jsx("div", {
                className: "productCardImgParent",
                children: /*#__PURE__*/jsx_runtime_.jsx("img", {
                  className: "ProductImg",
                  src: ordPro && ordPro['product_image'],
                  alt: ""
                })
              }), /*#__PURE__*/jsx_runtime_.jsx("div", {
                className: "Product-Model-Parent mt-3 skuParent",
                children: /*#__PURE__*/(0,jsx_runtime_.jsxs)("p", {
                  className: "Product-Model skuFontSt",
                  children: ["SKU: ", ordPro && ordPro['sku']]
                })
              }), /*#__PURE__*/jsx_runtime_.jsx("div", {
                className: "mt-2 orderNameP",
                children: /*#__PURE__*/jsx_runtime_.jsx(next_link.default, {
                  href: `/products/${ordPro.name.split(' ').join('-').split('(').join('').split(')').join('')}`,
                  children: /*#__PURE__*/jsx_runtime_.jsx("a", {
                    children: /*#__PURE__*/jsx_runtime_.jsx("p", {
                      className: "Product-Name productName",
                      children: ordPro && ordPro['name']
                    })
                  })
                })
              }), /*#__PURE__*/jsx_runtime_.jsx("div", {
                className: "productBrandP mt-2",
                children: /*#__PURE__*/jsx_runtime_.jsx("p", {
                  className: "Product-brand productBrandText",
                  children: ordPro && ordPro['product_options'][0]['display_value'].replace('Model', '')
                })
              }), /*#__PURE__*/jsx_runtime_.jsx("div", {
                className: "mt-2 d-flex align-items-center justify-content-between pPrice_AddToCart ",
                children: /*#__PURE__*/(0,jsx_runtime_.jsxs)("p", {
                  className: "Product-price productPriceAdd",
                  children: ["$ ", ordPro && Number(ordPro['base_total']).toFixed(2)]
                })
              })]
            })
          });
        })
      })]
    }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
      className: "MainContentInnerdiv MainContentInnerdivOH mb-2 BillingShipping ShippngOnly d-flex justify-content-between",
      children: [/*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
        className: "Billing subHeading BillingOfShippingOnly",
        children: [/*#__PURE__*/jsx_runtime_.jsx("p", {
          className: "BillingHeading Heading mb-2 shipement-p",
          children: "Shipment"
        }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("p", {
          children: ["Shipping method :", orderedItem.shipping_addresses[0].shipping_method]
        }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("p", {
          children: ["Shipping data : ", orderedItem.date_shipped]
        }), /*#__PURE__*/jsx_runtime_.jsx("p", {
          children: "Tracking # : 485098495884598"
        })]
      }), /*#__PURE__*/jsx_runtime_.jsx("div", {
        className: "Shipping subHeading trackOrderParent BillingOfShippingBtnContOnly d-flex justify-content-around align-items-center",
        children: orderedItem.shipping_addresses[0].status !== 'Cancelled' ? /*#__PURE__*/jsx_runtime_.jsx("button", {
          className: "ButtonTrackOrder",
          children: "TRACK ORDER"
        }) : /*#__PURE__*/jsx_runtime_.jsx("button", {
          className: "ButtonTrackOrder",
          style: {
            border: '2px solid rgba(255, 71, 15, 0.767)'
          },
          children: "Canceled"
        })
      })]
    }), /*#__PURE__*/jsx_runtime_.jsx("div", {
      className: "MainContentInnerdiv MainContentInnerdivOH MainContentInnerdivOHpd mb-2 orderHistory d-flex justify-content-between",
      children: /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
        children: [/*#__PURE__*/jsx_runtime_.jsx("p", {
          className: "Heading",
          children: "Payment Details"
        }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("p", {
          className: "subHeading d-flex align-items-center",
          children: [/*#__PURE__*/jsx_runtime_.jsx("img", {
            className: "cardImg",
            src: "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAOEAAADhCAMAAAAJbSJIAAAAclBMVEX///8AAADo6Ojc3NwaGhp0dHTX19e1tbWwsLDv7+9ZWVmWlpYjIyMwMDD19fX6+vrR0dFkZGQTExM+Pj6Ghoaenp52dnYNDQ0pKSnHx8dWVlY4ODioqKjExMR+fn7h4eFERERMTEyOjo5oaGiCgoIXFxdidBdzAAAEDklEQVR4nO2d7XqiMBBGKREQVFCKIEJpRff+b3Ht2iYBscTKGia8519R+8wpMPmQzlgWAAAAAAAAAAAAAAAAAAAAAAAoEoU+c8cK88PoETefeafD7mXc7A4nj/m/8YzyZK87emX2SX6vI6uLWHfYdxEXNbvDb11luiP+BVm1VvTznaXuYH/JLvVV/EqK5++brOx1ZBvdQT7I8f1nwflMd4QPM5v/4BdtdYc3CNubI0fkXL05K4Lay5k9Tlju1UFxnTecG4r2sfXGpVO6Yd+Nq53QLa+Sv9OZb6K0fbIJ6F0I3fbtVXWcxdYl+lpS0bsQlq99F2rzr1D15NwR8l41r8D263P51V2uI8SHyRvrIK/5oi8npM09c9gx0ZiuZI1sE8o34eaRRaVeIlnRkTNJKb2Q0BU8KyaSSSmOh9IFfKSVQ9uE0qC+Eiq1OBrQFjwrBkKm/j7IVkKbapIRdNkshPWb1uCG4U3oLC5HbCF91BvbQIiEurL/HRCD/crVHNswuOKUXdaKH9d3JnFE5vz4/NEV24a23sAGw+ZG8edVKabcle7IBkNMwreNVRPN+XYXOXc6r6Lsgg/2KpuNNPD5sF/Y1lo+ocYgbr21NFZ4/R8kgyeNF3wyvqO3rL/NO19LJGIC8EF9zi0T8kF+Y/ENnEB3VIPCU82rxbcaT7qDGpTTt9bS4hs0C91BDQpfL2UWTzpl/8cIIYYLYRikjjmk+w5D+t+ryQgbYUj1q+1uhA0MqQJD+sCQPjCkDwzpA0P6wJA+0zScvczMIetaAW+ZSXTt05i0qS9v68OQKjCkDwzpA0P6wJA+MKQPDOkDQ/rAkD4wpA8M6QND+sDwC1+FcT48rWh43Ae97Mf55K2ioVIVLOf54SugaLjqMmqTPj98BWD4BQxhqBEYfqH0eAbp0WK7UGCcsz3MS+kDQ/rAkD4wpI+ioTvcs4LP3utQnbVlAz3u+WepWuL3yYZKM28lMuMNYxjCEIYw/O+GY82lw/2TyVgNy/lgPLtQGual9IEhfWBIHxjSx3zDeYehSYUhG7W+zK/XZn7NPfPrJppf+5KfTmPrl5pfg9b8OsJm1oLmhSELewL1vM2vyT6Buvrm90aYQH8L83uUmN9nZgK9gszv92T5xvfsMrTvmtxU1sjeeWnjajS+/6G8oHoxs4flBPqQTqCXrFn9gNPObOmb3tO5sy93XATJqPtyJ0ERX0V9qy/3BHqrn5nT7+Mxm//gZ7UGTYoce6crfnl9XdMhLlW2RP2UaknhXaq65buusv5fNzqy6p6H51jdkYTHTFzU964XojzZ9//ikbBP8t8s+SKfeaeDUtUBjewOJ4/5jyxpozBk7lhhYUh3uQ4AAAAAAAAAAAAAAAAAAAAAeDp/AZk4bngcGPyAAAAAAElFTkSuQmCC",
            alt: ""
          }), /*#__PURE__*/jsx_runtime_.jsx("span", {
            className: "ml-2",
            children: " Visa "
          })]
        })]
      })
    }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
      className: "MainContentInnerdiv MainContentInnerdivOH MainContentInnerdivOHpd mb-2 orderHistory",
      children: [/*#__PURE__*/jsx_runtime_.jsx("p", {
        className: "Heading mb-4",
        children: "Order Total"
      }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
        className: "d-flex justify-content-between mb-2",
        children: [/*#__PURE__*/jsx_runtime_.jsx("div", {
          children: "Subtotal :"
        }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
          children: ["$ ", Number(orderedItem.base_shipping_cost).toFixed(2)]
        })]
      }), /*#__PURE__*/jsx_runtime_.jsx("hr", {}), /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
        className: "d-flex justify-content-between mb-2",
        children: [/*#__PURE__*/jsx_runtime_.jsx("div", {
          children: "Coupon :"
        }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
          children: ["$ ", Number(orderedItem.coupon_discount).toFixed(2)]
        })]
      }), /*#__PURE__*/jsx_runtime_.jsx("hr", {}), /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
        className: "d-flex justify-content-between mb-2",
        children: [/*#__PURE__*/jsx_runtime_.jsx("div", {
          children: "Shipping :"
        }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
          children: ["$ ", Number(orderedItem.shipping_cost_inc_tax).toFixed(2)]
        })]
      }), /*#__PURE__*/jsx_runtime_.jsx("hr", {}), /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
        className: "d-flex justify-content-between mb-2",
        children: [/*#__PURE__*/jsx_runtime_.jsx("div", {
          children: "Sales Tax :"
        }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
          children: ["$ ", Number(orderedItem.subtotal_tax).toFixed(2)]
        })]
      }), /*#__PURE__*/jsx_runtime_.jsx("hr", {}), /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
        className: "Heading-grandTotal d-flex justify-content-between mb-2 mt-3",
        children: [/*#__PURE__*/jsx_runtime_.jsx("div", {
          children: "Grand Total :"
        }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
          children: ["$ ", Number(orderedItem.total_inc_tax).toFixed(2)]
        })]
      })]
    })]
  });
}
;// CONCATENATED MODULE: ./assets/sleekshop-new-svg/BackIcon.svg
var BackIcon_path;

function BackIcon_extends() { BackIcon_extends = Object.assign || function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; }; return BackIcon_extends.apply(this, arguments); }



var SvgBackIcon = function SvgBackIcon(props) {
  return /*#__PURE__*/external_react_.createElement("svg", BackIcon_extends({
    width: 16,
    height: 16,
    fill: "none",
    xmlns: "http://www.w3.org/2000/svg"
  }, props), BackIcon_path || (BackIcon_path = /*#__PURE__*/external_react_.createElement("path", {
    d: "M16 7H3.83l5.59-5.59L8 0 0 8l8 8 1.41-1.41L3.83 9H16V7Z",
    fill: "#50585E"
  })));
};

/* harmony default export */ const BackIcon = (SvgBackIcon);
;// CONCATENATED MODULE: ./components/ProfileInnerPages/OrderHistory.tsx









const OrderHistory_Reward = ({
  ShowOrderHistoryDetails,
  setShowOrderHistoryDetails
}) => {
  const {
    data: customer
  } = (0,use_customer/* default */.Z)();
  const {
    0: OrderHistoryData,
    1: setOrderHistoryData
  } = (0,external_react_.useState)([]);
  const {
    0: DetailedData,
    1: setDetailedData
  } = (0,external_react_.useState)([]);
  (0,external_react_.useEffect)(() => {
    let cid = customer === null || customer === void 0 ? void 0 : customer.entityId;

    if (customer && customer !== null && customer !== void 0 && customer.entityId) {
      fetch('https://www.ystore.us/sleekshop/getOrders.php?customer_id=' + cid).then(response => response.json()).then(rs1 => {
        setOrderHistoryData(rs1);
      });
    }
  }, [customer]);
  return /*#__PURE__*/(0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
    children: [Array.isArray(OrderHistoryData) && OrderHistoryData.length > 0 && /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
      className: "d-flex align-items-center orderHistoryHeading",
      children: [ShowOrderHistoryDetails && /*#__PURE__*/jsx_runtime_.jsx("div", {
        className: "backBtnOH",
        onClick: () => setShowOrderHistoryDetails(false),
        children: /*#__PURE__*/jsx_runtime_.jsx(BackIcon, {})
      }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
        className: "orderHistoryHeadingUnd",
        children: [/*#__PURE__*/jsx_runtime_.jsx("p", {
          className: "Heading",
          children: "Order History"
        }), /*#__PURE__*/jsx_runtime_.jsx("p", {
          className: "subHeading d-flex align-items-center",
          children: "Review Your Order Here"
        })]
      })]
    }), ShowOrderHistoryDetails ? /*#__PURE__*/jsx_runtime_.jsx(Reward, {
      data: DetailedData
    }) : /*#__PURE__*/jsx_runtime_.jsx(jsx_runtime_.Fragment, {
      children: Array.isArray(OrderHistoryData) && OrderHistoryData.length > 0 ? /*#__PURE__*/jsx_runtime_.jsx(jsx_runtime_.Fragment, {
        children: OrderHistoryData.map(order => {
          return /*#__PURE__*/jsx_runtime_.jsx(jsx_runtime_.Fragment, {
            children: /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
              className: "MainContentInnerdivOrderHis mb-2 orderHistory ViewOrderGparent",
              children: [/*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
                className: "ViewOrderGparentChld",
                children: [/*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
                  children: [/*#__PURE__*/(0,jsx_runtime_.jsxs)("p", {
                    className: "subHeading subHeadingOrdrHis",
                    children: [/*#__PURE__*/jsx_runtime_.jsx("span", {
                      className: "Heading HeadingOrdrHis",
                      children: "Oder Id :"
                    }), /*#__PURE__*/jsx_runtime_.jsx("span", {
                      children: order === null || order === void 0 ? void 0 : order.orderId
                    })]
                  }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("p", {
                    className: "subHeading subHeadingOrdrHis",
                    children: [/*#__PURE__*/jsx_runtime_.jsx("span", {
                      className: "Heading HeadingOrdrHis",
                      children: "Order Data :"
                    }), /*#__PURE__*/jsx_runtime_.jsx("span", {
                      children: order === null || order === void 0 ? void 0 : order.dateCreated
                    })]
                  })]
                }), /*#__PURE__*/jsx_runtime_.jsx("div", {
                  className: "trackOrderParent trackOrderParentDeskV",
                  children: /*#__PURE__*/(0,jsx_runtime_.jsxs)("p", {
                    className: "subHeading subHeadingOrdrHis",
                    children: [/*#__PURE__*/jsx_runtime_.jsx("span", {
                      className: "Heading HeadingOrdrHis",
                      children: "Grand Total :"
                    }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("span", {
                      children: ["$ ", Number(order === null || order === void 0 ? void 0 : order.orderTotal).toFixed(2)]
                    })]
                  })
                })]
              }), /*#__PURE__*/jsx_runtime_.jsx("div", {
                className: "OrderHistoryImagesContainer OrderHistoryImagesContainerdesk",
                children: order === null || order === void 0 ? void 0 : order.productImage.map(imgString => /*#__PURE__*/jsx_runtime_.jsx("div", {
                  className: " productCardImgParentOnly",
                  children: /*#__PURE__*/jsx_runtime_.jsx("img", {
                    className: "ProductImageOnlyOrderHistory",
                    src: imgString,
                    alt: ""
                  })
                }))
              }), /*#__PURE__*/jsx_runtime_.jsx("div", {
                className: "\r subHeading\r trackOrderParent\r d-flex\r justify-content-around\r align-items-center\r mt-3\r ",
                children: /*#__PURE__*/jsx_runtime_.jsx("button", {
                  className: "View-Order-Button",
                  onClick: () => {
                    setShowOrderHistoryDetails(true);
                    setDetailedData(order);
                  },
                  children: "View Order"
                })
              })]
            })
          });
        })
      }) : /*#__PURE__*/jsx_runtime_.jsx(jsx_runtime_.Fragment, {
        children: /*#__PURE__*/jsx_runtime_.jsx("div", {
          className: "MainContentInnerdiv mb-2",
          children: /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
            className: "flex-1 PaddingForNoItemForDeskTopView flex flex-col justify-center items-center ",
            children: [/*#__PURE__*/jsx_runtime_.jsx("span", {
              className: "border border-dashed border-secondary rounded-full flex items-center justify-center w-16 h-16 p-12 bg-primary text-primary",
              children: /*#__PURE__*/jsx_runtime_.jsx(Bag/* default */.Z, {
                className: "absolute"
              })
            }), /*#__PURE__*/jsx_runtime_.jsx("h2", {
              className: "pt-6 text-2xl font-bold tracking-wide text-center",
              children: "No Orders found"
            })]
          })
        })
      })
    })]
  });
};

/* harmony default export */ const OrderHistory = (OrderHistory_Reward);
// EXTERNAL MODULE: ./components/icons/Heart.tsx
var Heart = __webpack_require__(8909);
// EXTERNAL MODULE: ./framework/commerce/product/use-price.tsx
var use_price = __webpack_require__(5420);
// EXTERNAL MODULE: ./framework/bigcommerce/wishlist/use-remove-item.tsx + 1 modules
var use_remove_item = __webpack_require__(5295);
// EXTERNAL MODULE: ./framework/bigcommerce/wishlist/use-wishlist.tsx + 1 modules
var use_wishlist = __webpack_require__(2056);
;// CONCATENATED MODULE: ./components/wishlist/Modals/AddToCartModal.jsx
function AddToCartModal_ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) { symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); } keys.push.apply(keys, symbols); } return keys; }

function AddToCartModal_objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { AddToCartModal_ownKeys(Object(source), true).forEach(function (key) { AddToCartModal_defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { AddToCartModal_ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function AddToCartModal_defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }











const AddToCartModal_customStyles = {
  content: {
    top: '20%',
    left: '0px',
    right: '0px',
    bottom: '0px',
    width: '100vw',
    position: 'fixed',
    inset: '0px',
    backgroundColor: 'rgb(0 0 0 / 35%)'
  }
};

const AddToCartModal_ModalCompo = ({
  setShowPartialProductDetailsPage,
  ShowPartialProductDetailsPage,
  CurrentObj
}) => {
  var _CurrentObj$price, _CurrentObj$price2, _CurrentObj$price3, _CurrentObj$images$, _CurrentObj$images$2, _CurrentObj$options$;

  const addItem = (0,use_add_item/* default */.Z)();
  const {
    0: loading,
    1: setLoading
  } = (0,external_react_.useState)(false);
  const {
    price
  } = (0,use_price/* default */.ZP)({
    amount: (_CurrentObj$price = CurrentObj.price) === null || _CurrentObj$price === void 0 ? void 0 : _CurrentObj$price.value,
    baseAmount: (_CurrentObj$price2 = CurrentObj.price) === null || _CurrentObj$price2 === void 0 ? void 0 : _CurrentObj$price2.retailPrice,
    currencyCode: (_CurrentObj$price3 = CurrentObj.price) === null || _CurrentObj$price3 === void 0 ? void 0 : _CurrentObj$price3.currencyCode
  });

  function closeModal(e) {
    setShowPartialProductDetailsPage(false);
    return false;
  }

  const {
    0: itemCountState,
    1: setitemCountState
  } = (0,external_react_.useState)({
    val: 1,
    status: '',
    diableAddToCart: false
  });

  const addToCart = async () => {
    setLoading(true);

    try {
      await addItem({
        productId: String(CurrentObj.id),
        variantId: String(CurrentObj.variants[0].id),
        quantity: itemCountState.val
      });
      setLoading(false);
    } catch (err) {
      setLoading(false);
    }

    closeModal();
  };

  const handleDecrement = () => {
    if (itemCountState.val > 1) {
      setitemCountState(prevState => AddToCartModal_objectSpread(AddToCartModal_objectSpread({}, prevState), {}, {
        val: itemCountState.val - 1
      })); // if (itemCountState.val - 1 <= CurrentObj.quantity) {
      //   let itemStatus = 'inStock'
      //   setitemCountState((prevState) => ({
      //     ...prevState,
      //     status: itemStatus,
      //     diableAddToCart: false,
      //   }))
      // }
    }
  };

  const handleIncrement = () => {
    // if (CurrentObj.quantity > itemCountState.val) {
    if (true) {
      setitemCountState(prevState => AddToCartModal_objectSpread(AddToCartModal_objectSpread({}, prevState), {}, {
        val: itemCountState.val + 1
      }));
    } else {}
  };

  return /*#__PURE__*/jsx_runtime_.jsx((external_react_modal_default()), {
    isOpen: ShowPartialProductDetailsPage,
    onRequestClose: e => closeModal(e),
    style: AddToCartModal_customStyles,
    className: "ModalUpperMostParent",
    children: /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
      className: "maskForProductDetailsPage",
      children: [/*#__PURE__*/jsx_runtime_.jsx("div", {
        className: "d-flex align-items-center justify-content-end closeSvg",
        children: /*#__PURE__*/jsx_runtime_.jsx("button", {
          onClick: e => closeModal(e),
          children: /*#__PURE__*/jsx_runtime_.jsx(sleekshop_new_svg_close, {})
        })
      }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
        className: "detailproductCardParent align-items-center",
        children: [/*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
          className: "detailproductCard detailproductCardAddTCM detailproductCardAddTCMWish",
          children: [/*#__PURE__*/jsx_runtime_.jsx("div", {
            className: "productCardImgParent productCardImgParentmodal d-flex align-items-center justify-content-center",
            children: /*#__PURE__*/jsx_runtime_.jsx("img", {
              className: "detailProductImg ",
              src: (_CurrentObj$images$ = CurrentObj.images[0]) === null || _CurrentObj$images$ === void 0 ? void 0 : _CurrentObj$images$.url,
              alt: ((_CurrentObj$images$2 = CurrentObj.images[0]) === null || _CurrentObj$images$2 === void 0 ? void 0 : _CurrentObj$images$2.alt) || 'Product Image'
            })
          }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
            className: "detailsParentModal",
            children: [/*#__PURE__*/jsx_runtime_.jsx("div", {
              className: "Product-Model-Parent mt-3 skuFontSt",
              children: /*#__PURE__*/(0,jsx_runtime_.jsxs)("p", {
                className: "Product-Model",
                children: ["SKU: ", CurrentObj.id]
              })
            }), /*#__PURE__*/jsx_runtime_.jsx("div", {
              className: "mt-1 CurrentObjNameP productName",
              children: /*#__PURE__*/jsx_runtime_.jsx("p", {
                className: "Product-Name",
                children: CurrentObj === null || CurrentObj === void 0 ? void 0 : CurrentObj.name
              })
            }), /*#__PURE__*/jsx_runtime_.jsx("p", {
              className: "Product-brand mt-1 productBrandText",
              children: CurrentObj === null || CurrentObj === void 0 ? void 0 : (_CurrentObj$options$ = CurrentObj.options[0]) === null || _CurrentObj$options$ === void 0 ? void 0 : _CurrentObj$options$.values[0].label.replace('Size :', '')
            }), /*#__PURE__*/jsx_runtime_.jsx("p", {
              className: "Product-price mt-12 productPriceAdd",
              children: price
            })]
          })]
        }), /*#__PURE__*/jsx_runtime_.jsx("div", {
          className: `${(ProfileInner_module_default()).incrementParent} ${(ProfileInner_module_default()).incrementParentModel} mt-2`,
          children: /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
            className: `d-flex justify-content-center align-items-center`,
            children: [/*#__PURE__*/jsx_runtime_.jsx("p", {
              className: `${(ProfileInner_module_default()).detailsQtyText}`,
              children: "QTY"
            }), /*#__PURE__*/jsx_runtime_.jsx("button", {
              className: `${(ProfileInner_module_default()).decrementBtn}`,
              onClick: () => {
                return handleDecrement();
              },
              children: /*#__PURE__*/jsx_runtime_.jsx(Minus, {})
            }), /*#__PURE__*/jsx_runtime_.jsx("input", {
              disabled: true,
              className: `${(ProfileInner_module_default()).inputEDCartVal}  ${itemCountState.status === 'outOfStock' ? (ProfileInner_module_default()).outOfStock : itemCountState.status === 'inStock' && (ProfileInner_module_default()).inStock}`,
              value: itemCountState.val
            }), /*#__PURE__*/jsx_runtime_.jsx("button", {
              className: ` ${(ProfileInner_module_default()).incrementBtn} `,
              onClick: () => {
                return handleIncrement();
              },
              children: /*#__PURE__*/jsx_runtime_.jsx(Plus, {})
            })]
          })
        }), /*#__PURE__*/jsx_runtime_.jsx("button", {
          disabled: itemCountState.diableAddToCart,
          className: "h6AddToCart detailsh6AddToCart detailsh6AddToCartModel",
          onClick: addToCart,
          children: "ADD TO BAG"
        })]
      })]
    })
  });
};

/* harmony default export */ const Modals_AddToCartModal = (AddToCartModal_ModalCompo);
;// CONCATENATED MODULE: ./components/wishlist/WishlistCard/WishlistCard.tsx
function WishlistCard_ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) { symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); } keys.push.apply(keys, symbols); } return keys; }

function WishlistCard_objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { WishlistCard_ownKeys(Object(source), true).forEach(function (key) { WishlistCard_defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { WishlistCard_ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function WishlistCard_defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

















const placeholderImg = '/product-img-placeholder.svg';

const WishlistCard = ({
  product,
  color
}) => {
  var _product$price, _product$price2, _product$price3, _product$images$, _product$images$2, _product$path;

  const {
    price
  } = (0,use_price/* default */.ZP)({
    amount: (_product$price = product.price) === null || _product$price === void 0 ? void 0 : _product$price.value,
    baseAmount: (_product$price2 = product.price) === null || _product$price2 === void 0 ? void 0 : _product$price2.retailPrice,
    currencyCode: (_product$price3 = product.price) === null || _product$price3 === void 0 ? void 0 : _product$price3.currencyCode
  }); // @ts-ignore Wishlist is not always enabled

  const removeItem = (0,use_remove_item/* default */.Z)({
    wishlist: {
      includeProducts: true
    }
  });
  const {
    0: loading,
    1: setLoading
  } = (0,external_react_.useState)(false);
  const {
    0: removing,
    1: setRemoving
  } = (0,external_react_.useState)(false);
  const {
    0: ShowPartialProductDetailsPage,
    1: setShowPartialProductDetailsPage
  } = (0,external_react_.useState)(false);
  const {
    0: itemCountState,
    1: setitemCountState
  } = (0,external_react_.useState)({
    val: 1,
    status: '',
    diableAddToCart: false
  }); // TODO: fix this missing argument issue

  /* @ts-ignore */

  const addItem = (0,use_add_item/* default */.Z)();
  const {
    openSidebar
  } = (0,context/* useUI */.l8)();
  const {
    data
  } = (0,use_wishlist/* default */.Z)();

  const handleRemove = async () => {
    setRemoving(true); // console.log('productIdToRemove', product.id!)

    try {
      var _data$items;

      // If this action succeeds then there's no need to do `setRemoving(true)`
      // because the component will be removed from the view
      // console.log('product which has to be deleted ', product)
      const itemInWishlist = data === null || data === void 0 ? void 0 : (_data$items = data.items) === null || _data$items === void 0 ? void 0 : _data$items.find( // @ts-ignore Wishlist is not always enabled
      item => {
        return item.product_id === Number(product.id) && item.variant_id === Number(product.variants[0].id);
      });

      if (itemInWishlist) {
        let deleteRes = await removeItem({
          id: itemInWishlist.id
        });
      }
    } catch (error) {
      setRemoving(false);
    }
  };

  const addToCart = async () => {
    setLoading(true);

    try {
      await addItem({
        productId: String(product.id),
        variantId: String(product.variants[0].id),
        quantity: itemCountState.val
      });
      openSidebar();
      setLoading(false);
    } catch (err) {
      setLoading(false);
    }
  };

  const handleDecrement = () => {
    if (itemCountState.val > 1) {
      setitemCountState(prevState => WishlistCard_objectSpread(WishlistCard_objectSpread({}, prevState), {}, {
        val: itemCountState.val - 1
      }));
    }
  };

  const handleIncrement = () => {
    if (true) {
      setitemCountState(prevState => WishlistCard_objectSpread(WishlistCard_objectSpread({}, prevState), {}, {
        val: itemCountState.val + 1
      }));
    } else {}
  };

  let Model = color.label;
  Model = Model.replace('Color :', '');
  Model = Model.replace('option :', '');
  Model.replace('Model', '');
  Model = Model.replace('Color :', '');
  Model = Model.replace('Size :', '');
  return /*#__PURE__*/(0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
    children: [ShowPartialProductDetailsPage && /*#__PURE__*/jsx_runtime_.jsx(Modals_AddToCartModal, {
      setShowPartialProductDetailsPage: setShowPartialProductDetailsPage,
      ShowPartialProductDetailsPage: ShowPartialProductDetailsPage,
      CurrentObj: product
    }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
      className: "productCard",
      children: [/*#__PURE__*/jsx_runtime_.jsx("button", {
        className: "deleteButtonWishlist",
        onClick: handleRemove,
        children: /*#__PURE__*/jsx_runtime_.jsx(sleekshop_new_svg_close, {})
      }), /*#__PURE__*/jsx_runtime_.jsx("div", {
        className: "productCardImgParent",
        children: /*#__PURE__*/jsx_runtime_.jsx("img", {
          className: "ProductImg",
          src: (_product$images$ = product.images[0]) === null || _product$images$ === void 0 ? void 0 : _product$images$.url,
          alt: ((_product$images$2 = product.images[0]) === null || _product$images$2 === void 0 ? void 0 : _product$images$2.alt) || 'Product Image'
        })
      }), /*#__PURE__*/jsx_runtime_.jsx("div", {
        className: "Product-Model-Parent mt-3 skuParent",
        children: /*#__PURE__*/(0,jsx_runtime_.jsxs)("p", {
          className: "Product-Model skuFontSt",
          children: ["SKU: ", product.id]
        })
      }), /*#__PURE__*/jsx_runtime_.jsx("div", {
        className: "mt-2 orderNameP",
        children: /*#__PURE__*/jsx_runtime_.jsx(next_link.default, {
          href: `${(_product$path = product.path) === null || _product$path === void 0 ? void 0 : _product$path.replace('.html', '')}`,
          children: /*#__PURE__*/jsx_runtime_.jsx("a", {
            children: /*#__PURE__*/jsx_runtime_.jsx("p", {
              className: "Product-Name productName",
              children: product.name
            })
          })
        })
      }), /*#__PURE__*/jsx_runtime_.jsx("div", {
        className: "productBrandP mt-2",
        children: /*#__PURE__*/jsx_runtime_.jsx("p", {
          className: "Product-brand productBrandText",
          children: Model
        })
      }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
        className: "mt-2 d-flex align-items-center justify-content-between pPrice_AddToCart ",
        children: [/*#__PURE__*/jsx_runtime_.jsx("p", {
          className: "Product-price productPriceAdd",
          children: price
        }), /*#__PURE__*/jsx_runtime_.jsx("p", {
          className: "addToCartButton",
          onClick: () => {
            setShowPartialProductDetailsPage(true);
          },
          children: /*#__PURE__*/jsx_runtime_.jsx(addToCartPlus, {})
        })]
      }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
        className: "AddToCartOnHover",
        children: [/*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
          className: `${(ProfileInner_module_default()).incrementParent}`,
          children: [/*#__PURE__*/jsx_runtime_.jsx("span", {
            className: `${(ProfileInner_module_default()).QtyText}`,
            children: "QTY"
          }), /*#__PURE__*/jsx_runtime_.jsx("button", {
            className: `${(ProfileInner_module_default()).decrementBtn}`,
            onClick: () => {
              return handleDecrement();
            },
            children: /*#__PURE__*/jsx_runtime_.jsx(Minus, {})
          }), /*#__PURE__*/jsx_runtime_.jsx("input", {
            disabled: true,
            className: `${(ProfileInner_module_default()).inputEDCartVal}  ${itemCountState.status === 'outOfStock' ? (ProfileInner_module_default()).outOfStock : itemCountState.status === 'inStock' && (ProfileInner_module_default()).inStock}`,
            value: itemCountState.val
          }), /*#__PURE__*/jsx_runtime_.jsx("button", {
            className: ` ${(ProfileInner_module_default()).incrementBtn} `,
            onClick: () => {
              return handleIncrement();
            },
            children: /*#__PURE__*/jsx_runtime_.jsx(Plus, {})
          })]
        }), /*#__PURE__*/jsx_runtime_.jsx("button", {
          // disabled={Boolean(
          //   handleRenderingItemCount(index, itemCountState)[2]
          // )}
          className: "h6AddToCart",
          onClick: addToCart,
          children: "ADD TO BAG"
        })]
      })]
    })]
  });
};

/* harmony default export */ const WishlistCard_WishlistCard = (WishlistCard);
;// CONCATENATED MODULE: ./components/ProfileInnerPages/wishlist.tsx
 // import { useCustomer } from '@framework/customer'






function Wishlist() {
  var _data$items, _data$items2;

  // const { data: customer } = useCustomer()
  // @ts-ignore Shopify - Fix this types
  const {
    data,
    isLoading,
    isEmpty
  } = (0,use_wishlist/* default */.Z)({
    includeProducts: true
  });
  return /*#__PURE__*/jsx_runtime_.jsx("div", {
    className: "MainContentInnerdiv mb-2 orderHistory d-flex justify-content-between",
    children: isLoading || isEmpty ? /*#__PURE__*/jsx_runtime_.jsx("div", {
      className: "mt-3 mb-20 w-100",
      children: /*#__PURE__*/jsx_runtime_.jsx("div", {
        className: "group flex flex-col",
        children: /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
          className: "flex-1 PaddingForNoItemForDeskTopView flex flex-col justify-center items-center ",
          children: [/*#__PURE__*/jsx_runtime_.jsx("span", {
            className: "border border-dashed border-secondary rounded-full flex items-center justify-center w-16 h-16 p-12 bg-primary text-primary",
            children: /*#__PURE__*/jsx_runtime_.jsx(Heart/* default */.Z, {
              className: "absolute"
            })
          }), /*#__PURE__*/jsx_runtime_.jsx("h2", {
            className: "pt-6 text-2xl font-bold tracking-wide text-center",
            children: "Your wishlist is empty"
          }), /*#__PURE__*/jsx_runtime_.jsx("p", {
            className: "text-accent-6 px-10 text-center pt-2",
            children: "Biscuit oat cake wafer icing ice cream tiramisu pudding cupcake."
          })]
        })
      })
    }) : /*#__PURE__*/jsx_runtime_.jsx(jsx_runtime_.Fragment, {
      children: /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
        className: "d-flex row",
        children: [/*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
          className: "mainContentChild d-flex justify-content-between",
          children: [/*#__PURE__*/jsx_runtime_.jsx("div", {
            className: "Heading buyItAgainHeading",
            children: "Wishlist"
          }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
            className: "Heading itemQuantity",
            children: [(_data$items = data.items) === null || _data$items === void 0 ? void 0 : _data$items.length, " Items"]
          })]
        }), data && ( // @ts-ignore Shopify - Fix this types
        (_data$items2 = data.items) === null || _data$items2 === void 0 ? void 0 : _data$items2.map(item => {
          var _item$product, _item$product$options;

          return /*#__PURE__*/jsx_runtime_.jsx(WishlistCard_WishlistCard, {
            product: item.product,
            color: item === null || item === void 0 ? void 0 : (_item$product = item.product) === null || _item$product === void 0 ? void 0 : (_item$product$options = _item$product.options[0]) === null || _item$product$options === void 0 ? void 0 : _item$product$options.values[0]
          }, item.id);
        }))]
      })
    })
  });
}
// EXTERNAL MODULE: external "next/router"
var router_ = __webpack_require__(6731);
// EXTERNAL MODULE: ./assets/css/edit_shipping_address.module.css
var edit_shipping_address_module = __webpack_require__(1752);
var edit_shipping_address_module_default = /*#__PURE__*/__webpack_require__.n(edit_shipping_address_module);
;// CONCATENATED MODULE: ./components/ShippingAddress/edit_shipping_address.tsx
function edit_shipping_address_ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) { symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); } keys.push.apply(keys, symbols); } return keys; }

function edit_shipping_address_objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { edit_shipping_address_ownKeys(Object(source), true).forEach(function (key) { edit_shipping_address_defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { edit_shipping_address_ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function edit_shipping_address_defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }








const EditAddressCompo = props => {
  const router = (0,router_.useRouter)();
  const {
    0: countries,
    1: setcountries
  } = (0,external_react_.useState)([]);
  const {
    0: States,
    1: setStates
  } = (0,external_react_.useState)([]);
  const {
    0: FetchCountries,
    1: setFetchCountries
  } = (0,external_react_.useState)(false);
  let {
    0: formData,
    1: setformData
  } = (0,external_react_.useState)({
    firstName: props.FormData.first_name,
    lastName: props.FormData.last_name,
    address1: props.FormData.street_1,
    address2: props.FormData.street_2,
    company: props.FormData.company,
    city: props.FormData.city,
    phoneNumber: props.FormData.phone,
    zipCode: props.FormData.zip,
    country: props.FormData.country,
    state: props.FormData.state,
    customerId: props.FormData.customer_id,
    address_id: props.FormData.id,
    country_code: props.FormData.country_iso2
  });
  (0,external_react_.useEffect)(() => {
    if (FetchCountries) {
      fetch('https://www.ystore.us/sleekshop/getCountries.php').then(res => res.json()).then(AllCountry => {
        setcountries(AllCountry);
      });
    }
  }, [FetchCountries]);

  const fetchAllStates = countryId => {
    fetch('https://www.ystore.us/sleekshop/getStates.php', {
      method: 'Post',
      body: JSON.stringify({
        country_id: countryId
      })
    }).then(res => res.json()).then(allState => {
      setStates(allState);
    });
  };

  const handleEditCoustomerDetails = () => {
    const data = edit_shipping_address_objectSpread({}, formData);

    if (true) {
      fetch('https://www.ystore.us/sleekshop/update-customer-address.php', // 'http://10.0.10.59/webProjects/sleekshop/api/update-customer-address.php',
      {
        method: 'POST',
        body: JSON.stringify(data),
        headers: {
          'Content-Type': 'application/json'
        }
      }).then(res => {
        return res.json();
      }).then(data => console.log('customer address updated ', data));
    }
  };

  return /*#__PURE__*/jsx_runtime_.jsx(jsx_runtime_.Fragment, {
    children: /*#__PURE__*/jsx_runtime_.jsx("div", {
      className: "MainContentInnerdiv",
      children: /*#__PURE__*/jsx_runtime_.jsx("div", {
        className: `${(edit_shipping_address_module_default()).formComtainer} `,
        style: {
          width: '100%'
        },
        children: /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
          className: "flex-1 flex flex-col justify-center items-center W-90",
          style: {
            width: '85%'
          },
          children: [/*#__PURE__*/jsx_runtime_.jsx("h2", {
            className: "page-heading mt-10",
            style: {
              width: 'auto'
            },
            children: "Edit Address"
          }), /*#__PURE__*/jsx_runtime_.jsx("div", {
            className: "account-body ",
            style: {
              width: '100%'
            },
            children: /*#__PURE__*/(0,jsx_runtime_.jsxs)("form", {
              className: `${(edit_shipping_address_module_default()).form}`,
              children: [/*#__PURE__*/jsx_runtime_.jsx("fieldset", {
                className: "form-fieldset",
                children: /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
                  className: "form-row form-row--half",
                  children: [/*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
                    className: "form-field form-field--select",
                    "data-validation": "{\"type\":\"singleselect\",\"label\":\"Country\",\"required\":true,\"prefix\":\"Choose a Country\"}",
                    "data-type": "Country",
                    children: [/*#__PURE__*/(0,jsx_runtime_.jsxs)("label", {
                      className: "form-label",
                      children: ["Country", /*#__PURE__*/jsx_runtime_.jsx("small", {
                        children: "Required"
                      })]
                    }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("select", {
                      className: `${(edit_shipping_address_module_default()).inputFieldAd} form-select `,
                      id: "FormField_11_select",
                      "data-label": "Country",
                      value: formData.country,
                      onChange: e => {
                        const arr = e.target.value.split(',');
                        fetchAllStates(arr[1]);
                        setformData(edit_shipping_address_objectSpread(edit_shipping_address_objectSpread({}, formData), {}, {
                          country: arr[0],
                          country_code: arr[2]
                        }));
                      },
                      onClick: () => {
                        if (!FetchCountries) {
                          setformData(edit_shipping_address_objectSpread(edit_shipping_address_objectSpread({}, formData), {}, {
                            state: '',
                            country: ''
                          }));
                        }

                        setFetchCountries(true);
                      },
                      children: [formData.country ? /*#__PURE__*/jsx_runtime_.jsx("option", {
                        disabled: true,
                        value: formData.country,
                        children: formData.country
                      }) : /*#__PURE__*/jsx_runtime_.jsx("span", {
                        children: "Choose a Country"
                      }), countries.map(country => {
                        let countryName = country['country'] || '';
                        let countryId = country['id'] || '';
                        let countryCode = country['country_iso2'] || '';
                        return /*#__PURE__*/jsx_runtime_.jsx(jsx_runtime_.Fragment, {
                          children: /*#__PURE__*/jsx_runtime_.jsx("option", {
                            value: [countryName, countryId, countryCode],
                            children: countryName
                          })
                        });
                      })]
                    })]
                  }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
                    className: "form-field form-field--input form-field--inputText",
                    id: "FormField_4",
                    "data-validation": "{\"type\":\"singleline\",\"label\":\"First Name\",\"required\":true,\"maxlength\":0}",
                    "data-type": "FirstName",
                    children: [/*#__PURE__*/(0,jsx_runtime_.jsxs)("label", {
                      className: "form-label",
                      children: ["First Name", /*#__PURE__*/jsx_runtime_.jsx("small", {
                        children: "Required"
                      })]
                    }), /*#__PURE__*/jsx_runtime_.jsx("input", {
                      className: `${(edit_shipping_address_module_default()).inputFieldAd} form-input`,
                      type: "text",
                      id: "FormField_4_input",
                      "data-label": "First Name",
                      name: "FormField[2][4]",
                      value: formData.firstName,
                      "aria-required": "true",
                      "data-field-type": "FirstName",
                      onChange: e => {
                        setformData(edit_shipping_address_objectSpread(edit_shipping_address_objectSpread({}, formData), {}, {
                          firstName: e.target.value
                        }));
                      }
                    }), /*#__PURE__*/jsx_runtime_.jsx("span", {
                      style: {
                        display: 'none'
                      }
                    })]
                  }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
                    className: "form-field form-field--input form-field--inputText",
                    id: "FormField_5",
                    "data-validation": "{\"type\":\"singleline\",\"label\":\"Last Name\",\"required\":true,\"maxlength\":0}",
                    "data-type": "LastName",
                    children: [/*#__PURE__*/(0,jsx_runtime_.jsxs)("label", {
                      className: "form-label",
                      children: ["Last Name", /*#__PURE__*/jsx_runtime_.jsx("small", {
                        children: "Required"
                      })]
                    }), /*#__PURE__*/jsx_runtime_.jsx("input", {
                      className: `${(edit_shipping_address_module_default()).inputFieldAd} form-input`,
                      type: "text",
                      id: "FormField_5_input",
                      "data-label": "Last Name",
                      name: "FormField[2][5]",
                      value: formData.lastName,
                      "aria-required": "true",
                      "data-field-type": "LastName",
                      onChange: e => {
                        setformData(edit_shipping_address_objectSpread(edit_shipping_address_objectSpread({}, formData), {}, {
                          lastName: e.target.value
                        }));
                      }
                    }), /*#__PURE__*/jsx_runtime_.jsx("span", {
                      style: {
                        display: 'none'
                      }
                    })]
                  }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
                    className: "form-field form-field--input form-field--inputText",
                    id: "FormField_8",
                    "data-validation": "{\"type\":\"singleline\",\"label\":\"Address Line 1\",\"required\":true,\"maxlength\":0}",
                    "data-type": "AddressLine1",
                    children: [/*#__PURE__*/(0,jsx_runtime_.jsxs)("label", {
                      className: "form-label",
                      children: ["Address Line 1", /*#__PURE__*/jsx_runtime_.jsx("small", {
                        children: "Required"
                      })]
                    }), /*#__PURE__*/jsx_runtime_.jsx("input", {
                      className: `${(edit_shipping_address_module_default()).inputFieldAd} form-input`,
                      type: "text",
                      id: "FormField_8_input",
                      "data-label": "Address Line 1",
                      name: "FormField[2][8]",
                      value: formData.address1,
                      "aria-required": "true",
                      "data-field-type": "AddressLine1",
                      onChange: e => {
                        setformData(edit_shipping_address_objectSpread(edit_shipping_address_objectSpread({}, formData), {}, {
                          address1: e.target.value
                        }));
                      }
                    }), /*#__PURE__*/jsx_runtime_.jsx("span", {
                      style: {
                        display: 'none'
                      }
                    })]
                  }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
                    className: "form-field form-field--input form-field--inputText",
                    id: "FormField_9",
                    "data-validation": "{\"type\":\"singleline\",\"label\":\"Address Line 2\",\"required\":false,\"maxlength\":0}",
                    "data-type": "AddressLine2",
                    children: [/*#__PURE__*/jsx_runtime_.jsx("label", {
                      className: "form-label",
                      children: "Address Line 2"
                    }), /*#__PURE__*/jsx_runtime_.jsx("input", {
                      className: `${(edit_shipping_address_module_default()).inputFieldAd} form-input`,
                      type: "text",
                      id: "FormField_9_input",
                      "data-label": "Address Line 2",
                      name: "FormField[2][9]",
                      value: formData.address2,
                      "aria-required": "false",
                      "data-field-type": "AddressLine2",
                      onChange: e => {
                        setformData(edit_shipping_address_objectSpread(edit_shipping_address_objectSpread({}, formData), {}, {
                          address2: e.target.value
                        }));
                      }
                    })]
                  }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
                    className: "form-field form-field--input form-field--inputText",
                    id: "FormField_6",
                    "data-validation": "{\"type\":\"singleline\",\"label\":\"Company Name\",\"required\":false,\"maxlength\":0}",
                    "data-type": "CompanyName",
                    children: [/*#__PURE__*/jsx_runtime_.jsx("label", {
                      className: "form-label",
                      children: "Company Name"
                    }), /*#__PURE__*/jsx_runtime_.jsx("input", {
                      className: `${(edit_shipping_address_module_default()).inputFieldAd} form-input`,
                      type: "text",
                      id: "FormField_6_input",
                      "data-label": "Company Name",
                      name: "FormField[2][6]",
                      "aria-required": "false",
                      value: formData.company,
                      "data-field-type": "CompanyName",
                      onChange: e => {
                        setformData(edit_shipping_address_objectSpread(edit_shipping_address_objectSpread({}, formData), {}, {
                          company: e.target.value
                        }));
                      }
                    })]
                  }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
                    className: "form-field form-field--input form-field--inputText",
                    id: "FormField_10",
                    "data-validation": "{\"type\":\"singleline\",\"label\":\"Suburb\\/City\",\"required\":true,\"maxlength\":0}",
                    "data-type": "City",
                    children: [/*#__PURE__*/(0,jsx_runtime_.jsxs)("label", {
                      className: "form-label",
                      children: ["Suburb/City", /*#__PURE__*/jsx_runtime_.jsx("small", {
                        children: "Required"
                      })]
                    }), /*#__PURE__*/jsx_runtime_.jsx("input", {
                      className: `${(edit_shipping_address_module_default()).inputFieldAd} form-input`,
                      type: "text",
                      id: "FormField_10_input",
                      "data-label": "Suburb/City",
                      name: "FormField[2][10]",
                      value: formData.city,
                      "aria-required": "true",
                      "data-field-type": "City",
                      onChange: e => {
                        setformData(edit_shipping_address_objectSpread(edit_shipping_address_objectSpread({}, formData), {}, {
                          city: e.target.value
                        }));
                      }
                    }), /*#__PURE__*/jsx_runtime_.jsx("span", {
                      style: {
                        display: 'none'
                      }
                    })]
                  }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
                    className: "form-field form-field--select",
                    id: "FormField_12",
                    "data-validation": "{\"type\":\"selectortext\",\"label\":\"State\\/Province\",\"required\":true}",
                    "data-type": "State",
                    children: [/*#__PURE__*/(0,jsx_runtime_.jsxs)("label", {
                      className: "form-label",
                      children: ["State/Province", /*#__PURE__*/jsx_runtime_.jsx("small", {
                        children: "Required"
                      })]
                    }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("select", {
                      name: "FormField[2][12]",
                      className: `${(edit_shipping_address_module_default()).inputFieldAd} form-select `,
                      "aria-required": "true",
                      id: "FormField_12_select",
                      "data-label": "State/Province",
                      "data-field-type": "State",
                      value: formData.state,
                      onChange: e => {
                        setformData(edit_shipping_address_objectSpread(edit_shipping_address_objectSpread({}, formData), {}, {
                          state: e.target.value
                        }));
                      },
                      children: [formData.state ? /*#__PURE__*/jsx_runtime_.jsx("option", {
                        disabled: true,
                        value: formData.state,
                        children: formData.state
                      }) : /*#__PURE__*/jsx_runtime_.jsx("span", {
                        children: "Choose a State"
                      }), States && States.length > 0 && States.map(state => {
                        let stateName = state['state'] || '';
                        return /*#__PURE__*/jsx_runtime_.jsx(jsx_runtime_.Fragment, {
                          children: /*#__PURE__*/jsx_runtime_.jsx("option", {
                            value: stateName,
                            children: stateName
                          })
                        });
                      })]
                    }), /*#__PURE__*/jsx_runtime_.jsx("span", {
                      style: {
                        display: 'none'
                      }
                    })]
                  }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
                    className: "form-field form-field--input form-field--inputText",
                    id: "FormField_7",
                    "data-validation": "{\"type\":\"singleline\",\"label\":\"Phone Number\",\"required\":true,\"maxlength\":0}",
                    "data-type": "Phone",
                    children: [/*#__PURE__*/(0,jsx_runtime_.jsxs)("label", {
                      className: "form-label",
                      children: ["Phone Number", /*#__PURE__*/jsx_runtime_.jsx("small", {
                        children: "Required"
                      })]
                    }), /*#__PURE__*/jsx_runtime_.jsx("input", {
                      className: `${(edit_shipping_address_module_default()).inputFieldAd} form-input`,
                      type: "text",
                      id: "FormField_7_input",
                      "data-label": "Phone Number",
                      name: "FormField[2][7]",
                      value: formData.phoneNumber,
                      "aria-required": "true",
                      "data-field-type": "Phone",
                      onChange: e => {
                        setformData(edit_shipping_address_objectSpread(edit_shipping_address_objectSpread({}, formData), {}, {
                          phoneNumber: e.target.value
                        }));
                      }
                    }), /*#__PURE__*/jsx_runtime_.jsx("span", {
                      style: {
                        display: 'none'
                      }
                    })]
                  }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
                    className: "form-field form-field--input form-field--inputText",
                    id: "FormField_13",
                    "data-validation": "{\"type\":\"singleline\",\"label\":\"Zip\\/Postcode\",\"required\":true,\"maxlength\":0}",
                    "data-type": "Zip",
                    children: [/*#__PURE__*/(0,jsx_runtime_.jsxs)("label", {
                      className: "form-label",
                      children: ["Zip/Postcode", /*#__PURE__*/jsx_runtime_.jsx("small", {
                        children: "Required"
                      })]
                    }), /*#__PURE__*/jsx_runtime_.jsx("input", {
                      className: `${(edit_shipping_address_module_default()).inputFieldAd} form-input`,
                      type: "text",
                      id: "FormField_13_input",
                      "data-label": "Zip/Postcode",
                      name: "FormField[2][13]",
                      value: formData.zipCode,
                      "aria-required": "true",
                      "data-field-type": "Zip",
                      onChange: e => {
                        setformData(edit_shipping_address_objectSpread(edit_shipping_address_objectSpread({}, formData), {}, {
                          zipCode: e.target.value
                        }));
                      }
                    }), /*#__PURE__*/jsx_runtime_.jsx("span", {
                      style: {
                        display: 'none'
                      }
                    })]
                  })]
                })
              }), /*#__PURE__*/jsx_runtime_.jsx("fieldset", {
                className: "form-fieldset",
                children: /*#__PURE__*/jsx_runtime_.jsx("div", {
                  className: "form-row form-row--half",
                  children: /*#__PURE__*/jsx_runtime_.jsx("div", {
                    className: "form-field form-field--select",
                    id: "FormField_11",
                    "data-validation": "{\"type\":\"singleselect\",\"label\":\"Country\",\"required\":true,\"prefix\":\"Choose a Country\"}",
                    "data-type": "Country",
                    children: /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
                      className: `form-fieldset `,
                      children: [/*#__PURE__*/jsx_runtime_.jsx("button", {
                        className: `button button--primary ${(edit_shipping_address_module_default()).submitBtn}`,
                        type: "button",
                        onClick: () => {
                          handleEditCoustomerDetails(); // props.setfetchAgain(!props.fetchAgain)

                          setTimeout(() => {
                            props.setshowEditAddressCompo(false);
                          }, 2000);
                        },
                        children: "Save Address"
                      }), /*#__PURE__*/jsx_runtime_.jsx("a", {
                        href: "#",
                        onClick: () => props.setshowEditAddressCompo(false),
                        className: "button",
                        children: "Cancel"
                      })]
                    })
                  })
                })
              })]
            })
          })]
        })
      })
    })
  });
};

/* harmony default export */ const edit_shipping_address = (EditAddressCompo);
;// CONCATENATED MODULE: ./components/ShippingAddress/add_address.tsx
function add_address_ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) { symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); } keys.push.apply(keys, symbols); } return keys; }

function add_address_objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { add_address_ownKeys(Object(source), true).forEach(function (key) { add_address_defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { add_address_ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function add_address_defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }








const AddAddressCompo = props => {
  const {
    data: customer
  } = (0,use_customer/* default */.Z)();
  const {
    0: countries,
    1: setcountries
  } = (0,external_react_.useState)([]);
  const {
    0: States,
    1: setStates
  } = (0,external_react_.useState)([]);
  const {
    0: FetchCountries,
    1: setFetchCountries
  } = (0,external_react_.useState)(false);
  let {
    0: formData,
    1: setformData
  } = (0,external_react_.useState)({
    firstName: '',
    lastName: '',
    address1: '',
    address2: '',
    company: '',
    city: '',
    phoneNumber: '',
    zipCode: '',
    country: '',
    state: '',
    customerId: customer === null || customer === void 0 ? void 0 : customer.entityId,
    address_id: '',
    country_code: ''
  });

  const handleAddAddress = async event => {
    event.preventDefault(); // don't redirect the page

    const data = add_address_objectSpread({}, formData);

    await fetch('https://www.ystore.us/sleekshop/add-customer-address.php', // 'http://10.0.10.59/webProjects/sleekshop/api/add-customer-address.php',
    {
      body: JSON.stringify(data),
      headers: {
        'Content-Type': 'application/json'
      },
      method: 'POST'
    });
    setTimeout(() => {
      props.setshowAddAddressCompo(false);
    }, 2000);
  };

  (0,external_react_.useEffect)(() => {
    fetch('https://www.ystore.us/sleekshop/getCountries.php').then(res => res.json()).then(AllCountry => {
      setcountries(AllCountry);
    });
  }, []);

  const fetchAllStates = countryId => {
    fetch('https://www.ystore.us/sleekshop/getStates.php', {
      method: 'Post',
      body: JSON.stringify({
        country_id: countryId
      })
    }).then(res => res.json()).then(allState => {
      setStates(allState);
    });
  };

  return /*#__PURE__*/jsx_runtime_.jsx("div", {
    className: "MainContentInnerdiv",
    children: /*#__PURE__*/jsx_runtime_.jsx("div", {
      className: `${(edit_shipping_address_module_default()).formComtainer} W-100`,
      style: {
        width: '100%'
      },
      children: /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
        className: "flex-1 flex flex-col justify-center items-center W-90",
        style: {
          width: '85%'
        },
        children: [/*#__PURE__*/jsx_runtime_.jsx("h2", {
          className: "page-heading mt-10",
          style: {
            width: 'auto'
          },
          children: "Add New Address"
        }), /*#__PURE__*/jsx_runtime_.jsx("div", {
          className: "account-body W-100",
          style: {
            width: '100%'
          },
          children: customer && /*#__PURE__*/jsx_runtime_.jsx("form", {
            className: `${(edit_shipping_address_module_default()).form}`,
            onSubmit: handleAddAddress,
            children: /*#__PURE__*/(0,jsx_runtime_.jsxs)("fieldset", {
              className: "form-fieldset",
              children: [/*#__PURE__*/jsx_runtime_.jsx("div", {
                className: "form-row form-row--half",
                children: /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
                  className: "form-field form-field--select",
                  id: "FormField_11",
                  "data-validation": "{\"type\":\"singleselect\",\"label\":\"Country\",\"required\":true,\"prefix\":\"Choose a Country\"}",
                  "data-type": "Country",
                  children: [/*#__PURE__*/(0,jsx_runtime_.jsxs)("label", {
                    className: "form-label",
                    children: ["Country", /*#__PURE__*/jsx_runtime_.jsx("small", {
                      children: "Required"
                    })]
                  }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("select", {
                    className: `${(edit_shipping_address_module_default()).inputFieldAd} form-select `,
                    id: "FormField_11_select",
                    "data-label": "Country",
                    value: formData.country,
                    onChange: e => {
                      const arr = e.target.value.split(',');
                      fetchAllStates(arr[1]);
                      setformData(add_address_objectSpread(add_address_objectSpread({}, formData), {}, {
                        country: arr[0],
                        country_code: arr[2]
                      }));
                    },
                    onClick: () => {
                      if (!FetchCountries) {
                        setformData(add_address_objectSpread(add_address_objectSpread({}, formData), {}, {
                          state: '',
                          country: ''
                        }));
                      }

                      setFetchCountries(true);
                    },
                    children: [formData.country ? /*#__PURE__*/jsx_runtime_.jsx("option", {
                      disabled: true,
                      value: formData.country,
                      children: formData.country
                    }) : /*#__PURE__*/jsx_runtime_.jsx("span", {
                      children: "Choose a Country"
                    }), countries.map(country => {
                      let countryName = country['country'] || '';
                      let countryId = country['id'] || '';
                      let countryCode = country['country_iso2'] || '';
                      return /*#__PURE__*/jsx_runtime_.jsx(jsx_runtime_.Fragment, {
                        children: /*#__PURE__*/jsx_runtime_.jsx("option", {
                          value: [countryName, countryId, countryCode],
                          children: countryName
                        })
                      });
                    })]
                  })]
                })
              }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
                className: "form-field form-field--input form-field--inputText",
                id: "FormField_4",
                "data-validation": "{\"type\":\"singleline\",\"label\":\"First Name\",\"required\":true,\"maxlength\":0}",
                "data-type": "FirstName",
                children: [/*#__PURE__*/(0,jsx_runtime_.jsxs)("label", {
                  className: "form-label",
                  children: ["First Name", /*#__PURE__*/jsx_runtime_.jsx("small", {
                    children: "Required"
                  })]
                }), /*#__PURE__*/jsx_runtime_.jsx("input", {
                  className: `${(edit_shipping_address_module_default()).inputFieldAd} form-input`,
                  type: "text",
                  id: "FormField_4_input",
                  "data-label": "First Name",
                  name: "FormField[2][4]",
                  value: formData.firstName,
                  "aria-required": "true",
                  "data-field-type": "FirstName",
                  onChange: e => {
                    setformData(add_address_objectSpread(add_address_objectSpread({}, formData), {}, {
                      firstName: e.target.value
                    }));
                  }
                }), /*#__PURE__*/jsx_runtime_.jsx("span", {
                  style: {
                    display: 'none'
                  }
                })]
              }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
                className: "form-field form-field--input form-field--inputText",
                id: "FormField_5",
                "data-validation": "{\"type\":\"singleline\",\"label\":\"Last Name\",\"required\":true,\"maxlength\":0}",
                "data-type": "LastName",
                children: [/*#__PURE__*/(0,jsx_runtime_.jsxs)("label", {
                  className: "form-label",
                  children: ["Last Name", /*#__PURE__*/jsx_runtime_.jsx("small", {
                    children: "Required"
                  })]
                }), /*#__PURE__*/jsx_runtime_.jsx("input", {
                  className: `${(edit_shipping_address_module_default()).inputFieldAd} form-input`,
                  type: "text",
                  id: "FormField_5_input",
                  "data-label": "Last Name",
                  name: "FormField[2][5]",
                  value: formData.lastName,
                  "aria-required": "true",
                  "data-field-type": "LastName",
                  onChange: e => {
                    setformData(add_address_objectSpread(add_address_objectSpread({}, formData), {}, {
                      lastName: e.target.value
                    }));
                  }
                }), /*#__PURE__*/jsx_runtime_.jsx("span", {
                  style: {
                    display: 'none'
                  }
                })]
              }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
                className: "form-field form-field--input form-field--inputText",
                id: "FormField_8",
                "data-validation": "{\"type\":\"singleline\",\"label\":\"Address Line 1\",\"required\":true,\"maxlength\":0}",
                "data-type": "AddressLine1",
                children: [/*#__PURE__*/(0,jsx_runtime_.jsxs)("label", {
                  className: "form-label",
                  children: ["Address Line 1", /*#__PURE__*/jsx_runtime_.jsx("small", {
                    children: "Required"
                  })]
                }), /*#__PURE__*/jsx_runtime_.jsx("input", {
                  className: `${(edit_shipping_address_module_default()).inputFieldAd} form-input`,
                  type: "text",
                  id: "FormField_8_input",
                  "data-label": "Address Line 1",
                  name: "FormField[2][8]",
                  value: formData.address1,
                  "aria-required": "true",
                  "data-field-type": "AddressLine1",
                  onChange: e => {
                    setformData(add_address_objectSpread(add_address_objectSpread({}, formData), {}, {
                      address1: e.target.value
                    }));
                  }
                }), /*#__PURE__*/jsx_runtime_.jsx("span", {
                  style: {
                    display: 'none'
                  }
                })]
              }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
                className: "form-field form-field--input form-field--inputText",
                id: "FormField_9",
                "data-validation": "{\"type\":\"singleline\",\"label\":\"Address Line 2\",\"required\":false,\"maxlength\":0}",
                "data-type": "AddressLine2",
                children: [/*#__PURE__*/jsx_runtime_.jsx("label", {
                  className: "form-label",
                  children: "Address Line 2"
                }), /*#__PURE__*/jsx_runtime_.jsx("input", {
                  className: `${(edit_shipping_address_module_default()).inputFieldAd} form-input`,
                  type: "text",
                  id: "FormField_9_input",
                  "data-label": "Address Line 2",
                  name: "FormField[2][9]",
                  value: formData.address2,
                  "aria-required": "false",
                  "data-field-type": "AddressLine2",
                  onChange: e => {
                    setformData(add_address_objectSpread(add_address_objectSpread({}, formData), {}, {
                      address2: e.target.value
                    }));
                  }
                })]
              }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
                className: "form-field form-field--input form-field--inputText",
                id: "FormField_6",
                "data-validation": "{\"type\":\"singleline\",\"label\":\"Company Name\",\"required\":false,\"maxlength\":0}",
                "data-type": "CompanyName",
                children: [/*#__PURE__*/jsx_runtime_.jsx("label", {
                  className: "form-label",
                  children: "Company Name"
                }), /*#__PURE__*/jsx_runtime_.jsx("input", {
                  className: `${(edit_shipping_address_module_default()).inputFieldAd} form-input`,
                  type: "text",
                  id: "FormField_6_input",
                  "data-label": "Company Name",
                  name: "FormField[2][6]",
                  "aria-required": "false",
                  value: formData.company,
                  "data-field-type": "CompanyName",
                  onChange: e => {
                    setformData(add_address_objectSpread(add_address_objectSpread({}, formData), {}, {
                      company: e.target.value
                    }));
                  }
                })]
              }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
                className: "form-field form-field--input form-field--inputText",
                id: "FormField_10",
                "data-validation": "{\"type\":\"singleline\",\"label\":\"Suburb\\/City\",\"required\":true,\"maxlength\":0}",
                "data-type": "City",
                children: [/*#__PURE__*/(0,jsx_runtime_.jsxs)("label", {
                  className: "form-label",
                  children: ["Suburb/City", /*#__PURE__*/jsx_runtime_.jsx("small", {
                    children: "Required"
                  })]
                }), /*#__PURE__*/jsx_runtime_.jsx("input", {
                  className: `${(edit_shipping_address_module_default()).inputFieldAd} form-input`,
                  type: "text",
                  id: "FormField_10_input",
                  "data-label": "Suburb/City",
                  name: "FormField[2][10]",
                  value: formData.city,
                  "aria-required": "true",
                  "data-field-type": "City",
                  onChange: e => {
                    setformData(add_address_objectSpread(add_address_objectSpread({}, formData), {}, {
                      city: e.target.value
                    }));
                  }
                }), /*#__PURE__*/jsx_runtime_.jsx("span", {
                  style: {
                    display: 'none'
                  }
                })]
              }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
                className: "form-field form-field--select",
                id: "FormField_12",
                "data-validation": "{\"type\":\"selectortext\",\"label\":\"State\\/Province\",\"required\":true}",
                "data-type": "State",
                children: [/*#__PURE__*/(0,jsx_runtime_.jsxs)("label", {
                  className: "form-label",
                  children: ["State/Province", /*#__PURE__*/jsx_runtime_.jsx("small", {
                    children: "Required"
                  })]
                }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("select", {
                  name: "FormField[2][12]",
                  className: `${(edit_shipping_address_module_default()).inputFieldAd} form-select `,
                  "aria-required": "true",
                  id: "FormField_12_select",
                  "data-label": "State/Province",
                  "data-field-type": "State",
                  value: formData.state,
                  onChange: e => {
                    setformData(add_address_objectSpread(add_address_objectSpread({}, formData), {}, {
                      state: e.target.value
                    }));
                  },
                  children: [formData.state ? /*#__PURE__*/jsx_runtime_.jsx("option", {
                    disabled: true,
                    value: formData.state,
                    children: formData.state
                  }) : /*#__PURE__*/jsx_runtime_.jsx("span", {
                    children: "Choose a State"
                  }), States && States.length > 0 && States.map(state => {
                    let stateName = state['state'] || '';
                    return /*#__PURE__*/jsx_runtime_.jsx(jsx_runtime_.Fragment, {
                      children: /*#__PURE__*/jsx_runtime_.jsx("option", {
                        value: stateName,
                        children: stateName
                      })
                    });
                  })]
                }), /*#__PURE__*/jsx_runtime_.jsx("span", {
                  style: {
                    display: 'none'
                  }
                })]
              }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
                className: "form-field form-field--input form-field--inputText",
                id: "FormField_7",
                "data-validation": "{\"type\":\"singleline\",\"label\":\"Phone Number\",\"required\":true,\"maxlength\":0}",
                "data-type": "Phone",
                children: [/*#__PURE__*/(0,jsx_runtime_.jsxs)("label", {
                  className: "form-label",
                  children: ["Phone Number", /*#__PURE__*/jsx_runtime_.jsx("small", {
                    children: "Required"
                  })]
                }), /*#__PURE__*/jsx_runtime_.jsx("input", {
                  className: `${(edit_shipping_address_module_default()).inputFieldAd} form-input`,
                  type: "text",
                  id: "FormField_7_input",
                  "data-label": "Phone Number",
                  name: "FormField[2][7]",
                  value: formData.phoneNumber,
                  "aria-required": "true",
                  "data-field-type": "Phone",
                  onChange: e => {
                    setformData(add_address_objectSpread(add_address_objectSpread({}, formData), {}, {
                      phoneNumber: e.target.value
                    }));
                  }
                }), /*#__PURE__*/jsx_runtime_.jsx("span", {
                  style: {
                    display: 'none'
                  }
                })]
              }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
                className: "form-field form-field--input form-field--inputText",
                id: "FormField_13",
                "data-validation": "{\"type\":\"singleline\",\"label\":\"Zip\\/Postcode\",\"required\":true,\"maxlength\":0}",
                "data-type": "Zip",
                children: [/*#__PURE__*/(0,jsx_runtime_.jsxs)("label", {
                  className: "form-label",
                  children: ["Zip/Postcode", /*#__PURE__*/jsx_runtime_.jsx("small", {
                    children: "Required"
                  })]
                }), /*#__PURE__*/jsx_runtime_.jsx("input", {
                  className: `${(edit_shipping_address_module_default()).inputFieldAd} form-input`,
                  type: "text",
                  id: "FormField_13_input",
                  "data-label": "Zip/Postcode",
                  name: "FormField[2][13]",
                  value: formData.zipCode,
                  "aria-required": "true",
                  "data-field-type": "Zip",
                  onChange: e => {
                    setformData(add_address_objectSpread(add_address_objectSpread({}, formData), {}, {
                      zipCode: e.target.value
                    }));
                  }
                }), /*#__PURE__*/jsx_runtime_.jsx("span", {
                  style: {
                    display: 'none'
                  }
                })]
              }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
                className: "form-field form-field--textarea d-flex",
                children: [/*#__PURE__*/jsx_runtime_.jsx("button", {
                  type: "submit",
                  className: "btn ",
                  style: {
                    background: '#e99da1',
                    border: 'none',
                    textTransform: 'capitalize',
                    color: 'white',
                    padding: '10px 20px ',
                    borderRadius: '4px'
                  },
                  children: "ADD Address"
                }), /*#__PURE__*/jsx_runtime_.jsx("button", {
                  className: "btn ",
                  style: {
                    background: 'white',
                    border: '1px solid #B0B0B0	',
                    textTransform: 'capitalize',
                    color: 'black',
                    padding: '10px 20px',
                    borderRadius: '4px',
                    marginLeft: '20px'
                  },
                  onClick: () => props.setshowAddAddressCompo(false),
                  children: "Cancel"
                })]
              })]
            })
          })
        })]
      })
    })
  });
};

/* harmony default export */ const add_address = (AddAddressCompo);
// EXTERNAL MODULE: ./assets/css/addresses.module.css
var addresses_module = __webpack_require__(6899);
var addresses_module_default = /*#__PURE__*/__webpack_require__.n(addresses_module);
;// CONCATENATED MODULE: ./components/ProfileInnerPages/addresses.tsx









function Address() {
  const {
    0: addressData,
    1: setaddressData
  } = (0,external_react_.useState)([]);
  const {
    0: FormData,
    1: setFormData
  } = (0,external_react_.useState)([]);
  const {
    0: showEditAddressCompo,
    1: setshowEditAddressCompo
  } = (0,external_react_.useState)(false);
  const {
    0: showAddAddressCompo,
    1: setshowAddAddressCompo
  } = (0,external_react_.useState)(false);
  const {
    0: refresh,
    1: setrefresh
  } = (0,external_react_.useState)(false);
  const {
    data: customer
  } = (0,use_customer/* default */.Z)();
  const {
    openModal,
    setModalView
  } = (0,context/* useUI */.l8)();
  (0,external_react_.useEffect)(() => {
    if (!customer) {
      setModalView('LOGIN_VIEW');
      return openModal();
    }
  }, [customer]); // listing of all admin or users inside address tab

  (0,external_react_.useEffect)(() => {
    let cid = customer === null || customer === void 0 ? void 0 : customer.entityId;

    if (customer && customer !== null && customer !== void 0 && customer.entityId) {
      fetch('https://www.ystore.us/sleekshop/getAddresses.php?customer_id=' + cid).then(response => response.json()).then(rs1 => {
        setaddressData(rs1);
      });
    }
  }, [customer, showEditAddressCompo, showAddAddressCompo, refresh]);

  const handleDeleteAddress = address_id => {
    fetch('https://www.ystore.us/sleekshop/deleteAddress.php', {
      // Adding method type
      method: 'POST',
      // Adding body or contents to send
      body: JSON.stringify({
        address_id
      })
    }).then(res => res.json()).then(res => {
      if (res.success) {
        setrefresh(!refresh);
      }
    });
  };

  return /*#__PURE__*/jsx_runtime_.jsx(jsx_runtime_.Fragment, {
    children: /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
      className: "MainContentInnerdiv mb-2",
      children: [/*#__PURE__*/(0,jsx_runtime_.jsxs)("ul", {
        className: `flex justify-center items-center ${(addresses_module_default()).ulParen}`,
        children: [Array.isArray(addressData) && addressData.length > 0 ? /*#__PURE__*/jsx_runtime_.jsx(jsx_runtime_.Fragment, {
          children: addressData.map(item => {
            return /*#__PURE__*/jsx_runtime_.jsx("li", {
              className: `${(addresses_module_default()).panelbodyCo} `,
              children: /*#__PURE__*/jsx_runtime_.jsx("div", {
                className: "panel panel--address",
                children: /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
                  className: `${(addresses_module_default()).panelbody} panel-body`,
                  children: [/*#__PURE__*/(0,jsx_runtime_.jsxs)("h5", {
                    className: "address-title",
                    children: [item === null || item === void 0 ? void 0 : item.first_name, " ", item === null || item === void 0 ? void 0 : item.last_name]
                  }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("ul", {
                    className: "address-details address-details--postal",
                    style: {
                      height: '120px'
                    },
                    children: [/*#__PURE__*/jsx_runtime_.jsx("li", {
                      children: item === null || item === void 0 ? void 0 : item.company
                    }), /*#__PURE__*/jsx_runtime_.jsx("li", {
                      children: item === null || item === void 0 ? void 0 : item.street_1
                    }), /*#__PURE__*/jsx_runtime_.jsx("li", {
                      children: item === null || item === void 0 ? void 0 : item.street_2
                    }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("li", {
                      children: [item === null || item === void 0 ? void 0 : item.city, ", ", item === null || item === void 0 ? void 0 : item.state, " ", item === null || item === void 0 ? void 0 : item.zip]
                    }), /*#__PURE__*/jsx_runtime_.jsx("li", {
                      children: item === null || item === void 0 ? void 0 : item.country
                    })]
                  }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("dl", {
                    className: "address-details",
                    children: [/*#__PURE__*/jsx_runtime_.jsx("dt", {
                      className: "address-label",
                      children: "Phone:"
                    }), /*#__PURE__*/jsx_runtime_.jsx("dd", {
                      className: "address-description",
                      children: item === null || item === void 0 ? void 0 : item.phone
                    })]
                  }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
                    className: "form-actions",
                    children: [/*#__PURE__*/jsx_runtime_.jsx("a", {
                      className: "button button--primary button--small",
                      href: "#editAddressForm",
                      onClick: () => {
                        setFormData(item);
                        setshowEditAddressCompo(true);
                        setshowAddAddressCompo(false);
                      },
                      children: "Edit"
                    }), /*#__PURE__*/jsx_runtime_.jsx("button", {
                      type: "submit",
                      className: "button secondary button--small",
                      onClick: () => handleDeleteAddress(item.id),
                      children: "Delete"
                    })]
                  })]
                })
              })
            }, item.id);
          })
        }) : /*#__PURE__*/jsx_runtime_.jsx("div", {
          className: "flex-1 flex flex-col justify-center items-center",
          children: /*#__PURE__*/jsx_runtime_.jsx("h1", {
            className: `p-20`,
            children: "LOADING ..."
          })
        }), /*#__PURE__*/jsx_runtime_.jsx("div", {
          className: "MainContentInnerdiv mb-2",
          children: /*#__PURE__*/jsx_runtime_.jsx("li", {
            className: "address",
            children: /*#__PURE__*/jsx_runtime_.jsx("a", {
              className: "panel panel--address panel--newAddress",
              href: "#addAddressForm",
              onClick: () => {
                setshowAddAddressCompo(true);
                setshowEditAddressCompo(false);
              },
              children: /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
                children: [/*#__PURE__*/jsx_runtime_.jsx("span", {
                  className: "address-symbol",
                  children: "+"
                }), /*#__PURE__*/jsx_runtime_.jsx("h5", {
                  className: "address-title",
                  children: "New Address"
                })]
              })
            })
          })
        })]
      }), showEditAddressCompo ? /*#__PURE__*/jsx_runtime_.jsx(edit_shipping_address, {
        setshowEditAddressCompo: setshowEditAddressCompo,
        FormData: FormData
      }) : showAddAddressCompo && /*#__PURE__*/jsx_runtime_.jsx(add_address, {
        setshowAddAddressCompo: setshowAddAddressCompo
      })]
    })
  });
}
// EXTERNAL MODULE: ./components/ui/Button/Button.tsx
var Button = __webpack_require__(1180);
// EXTERNAL MODULE: ./assets/css/profileAccount.module.css
var profileAccount_module = __webpack_require__(7120);
var profileAccount_module_default = /*#__PURE__*/__webpack_require__.n(profileAccount_module);
;// CONCATENATED MODULE: ./components/ProfileInnerPages/editProfile.tsx
function editProfile_ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) { symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); } keys.push.apply(keys, symbols); } return keys; }

function editProfile_objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { editProfile_ownKeys(Object(source), true).forEach(function (key) { editProfile_defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { editProfile_ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function editProfile_defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }










function editProfile() {
  const {
    data
  } = (0,use_customer/* default */.Z)();
  const {
    openModal,
    setModalView
  } = (0,context/* useUI */.l8)();
  let {
    0: formData,
    1: setformData
  } = (0,external_react_.useState)({
    first_name: '',
    last_name: '',
    customerId: '',
    email: '',
    phone: '',
    company: '',
    password: '',
    confirmPassword: ''
  });
  let {
    0: resMessage,
    1: setresMessage
  } = (0,external_react_.useState)({
    type: '',
    msg: ''
  });
  const {
    0: Toggle,
    1: setToggle
  } = (0,external_react_.useState)(false);
  (0,external_react_.useEffect)(() => {
    if (!data) {
      setModalView('LOGIN_VIEW');
      return openModal();
    }

    setformData(editProfile_objectSpread(editProfile_objectSpread({}, formData), {}, {
      first_name: data === null || data === void 0 ? void 0 : data.firstName,
      last_name: data === null || data === void 0 ? void 0 : data.lastName,
      customerId: data === null || data === void 0 ? void 0 : data.entityId,
      email: data === null || data === void 0 ? void 0 : data.email,
      phone: data === null || data === void 0 ? void 0 : data.phone,
      company: data === null || data === void 0 ? void 0 : data.company
    }));
  }, [data]);

  const handleUpdateProfile = async event => {
    event.preventDefault(); // don't redirect the page

    const {
      first_name,
      last_name,
      customerId,
      email,
      phone,
      company,
      password,
      confirmPassword
    } = formData;

    function validate() {
      let letters = /[a-zA-Z]/;
      let number = /\d+/g;

      if (first_name && last_name && customerId && email && phone && company) {
        if (Toggle) {
          if (password && confirmPassword && password === confirmPassword) {
            if (password.length < 7 || !password.match(letters) || !password.match(number)) {
              setresMessage({
                type: 'warn',
                msg: 'Passwords must be "at least 7 characters" and contain both "alphabetic" and "numeric" characters.'
              });
              setTimeout(() => {
                setresMessage({
                  type: '',
                  msg: ''
                });
              }, 4000);
            } else {
              return true;
            }

            return false;
          } else {
            setresMessage({
              type: 'warn',
              msg: 'Password and confirm password should be equal and filled'
            });
            setTimeout(() => {
              setresMessage({
                type: '',
                msg: ''
              });
            }, 4000);
            return false;
          }
        }

        return true;
      } else {
        setresMessage({
          type: 'warn',
          msg: 'All Fields Are Required'
        });
        setTimeout(() => {
          setresMessage({
            type: '',
            msg: ''
          });
        }, 4000);
        return false;
      }
    }

    if (validate()) {
      fetch('https://www.ystore.us/sleekshop/updatecustomer.php', {
        mode: 'cors',
        body: JSON.stringify(editProfile_objectSpread({}, formData)),
        headers: {
          'Content-Type': 'application/json'
        },
        method: 'POST'
      }).then(res => {
        return res.json();
      }).then(resObj => {
        if (resObj.success) {
          setresMessage({
            type: 'success',
            msg: resObj.message
          });
          setTimeout(() => {
            setresMessage({
              type: '',
              msg: ''
            });
          }, 4000);
        } else {
          setresMessage({
            type: 'danger',
            msg: resObj.message || 'Cant Update Now , Please Talk To Administrator'
          });
          setTimeout(() => {
            setresMessage({
              type: '',
              msg: ''
            });
          }, 4000);
        }
      });
    }
  };

  return /*#__PURE__*/jsx_runtime_.jsx(jsx_runtime_.Fragment, {
    children: /*#__PURE__*/jsx_runtime_.jsx("div", {
      className: "MainContentInnerdiv",
      children: /*#__PURE__*/jsx_runtime_.jsx("div", {
        className: `${(edit_shipping_address_module_default()).formComtainer} `,
        style: {
          width: '100%'
        },
        children: /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
          className: "flex-1 flex flex-col justify-center items-center W-90",
          style: {
            width: '85%'
          },
          children: [/*#__PURE__*/jsx_runtime_.jsx("h2", {
            className: "page-heading mt-10",
            style: {
              width: 'auto'
            },
            children: "Edit Profile"
          }), /*#__PURE__*/jsx_runtime_.jsx("div", {
            className: "account-body ",
            style: {
              width: '100%'
            }
          }), /*#__PURE__*/jsx_runtime_.jsx("form", {
            onSubmit: handleUpdateProfile,
            className: `${(edit_shipping_address_module_default()).form}`,
            children: /*#__PURE__*/(0,jsx_runtime_.jsxs)("fieldset", {
              className: "form-fieldset",
              children: [/*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
                className: `form-row form-row--half pb-30 ${(profileAccount_module_default()).mb_30}`,
                children: [/*#__PURE__*/jsx_runtime_.jsx("label", {
                  className: "form-label",
                  children: "First Name"
                }), /*#__PURE__*/jsx_runtime_.jsx("input", {
                  type: "text",
                  className: "Input_root__2vmVG",
                  placeholder: "First Name",
                  onChange: e => setformData(editProfile_objectSpread(editProfile_objectSpread({}, formData), {}, {
                    first_name: e.target.value
                  })),
                  value: formData.first_name
                })]
              }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
                className: `form-row form-row--half pb-30 ${(profileAccount_module_default()).mb_30}`,
                children: [/*#__PURE__*/jsx_runtime_.jsx("label", {
                  className: "form-label",
                  children: "Last Name"
                }), /*#__PURE__*/jsx_runtime_.jsx("input", {
                  type: "text",
                  placeholder: "Last Name",
                  onChange: e => setformData(editProfile_objectSpread(editProfile_objectSpread({}, formData), {}, {
                    last_name: e.target.value
                  })),
                  value: formData.last_name,
                  className: "Input_root__2vmVG"
                })]
              }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
                className: `form-row form-row--half pb-30 ${(profileAccount_module_default()).mb_30}`,
                children: [/*#__PURE__*/jsx_runtime_.jsx("label", {
                  className: "form-label",
                  children: "Company"
                }), /*#__PURE__*/jsx_runtime_.jsx("input", {
                  type: "text",
                  placeholder: "Company",
                  onChange: e => setformData(editProfile_objectSpread(editProfile_objectSpread({}, formData), {}, {
                    company: e.target.value
                  })),
                  value: formData.company,
                  className: "Input_root__2vmVG"
                })]
              }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
                className: `form-row form-row--half pb-30 ${(profileAccount_module_default()).mb_30}`,
                children: [/*#__PURE__*/jsx_runtime_.jsx("label", {
                  className: "form-label",
                  children: "Phone Number"
                }), /*#__PURE__*/jsx_runtime_.jsx("input", {
                  type: "text",
                  placeholder: "Phone Number",
                  onChange: e => setformData(editProfile_objectSpread(editProfile_objectSpread({}, formData), {}, {
                    phone: e.target.value
                  })),
                  value: formData.phone,
                  className: "Input_root__2vmVG"
                })]
              }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
                className: `form-row form-row--half pb-30 ${(profileAccount_module_default()).mb_30}`,
                children: [/*#__PURE__*/jsx_runtime_.jsx("label", {
                  className: "form-label",
                  children: "Email"
                }), /*#__PURE__*/jsx_runtime_.jsx("input", {
                  type: "text",
                  placeholder: "Email",
                  onChange: e => setformData(editProfile_objectSpread(editProfile_objectSpread({}, formData), {}, {
                    email: e.target.value
                  })),
                  value: formData.email,
                  className: "Input_root__2vmVG"
                })]
              }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
                className: `form-row form-row--half pb-30 ${(profileAccount_module_default()).mb_30}`,
                children: [/*#__PURE__*/jsx_runtime_.jsx("label", {
                  className: "form-label",
                  children: "Change Password"
                }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("label", {
                  className: `${(profileAccount_module_default()).switch}`,
                  children: [/*#__PURE__*/jsx_runtime_.jsx("input", {
                    type: "checkbox",
                    onChange: e => {
                      setToggle(e.target.checked);
                    }
                  }), /*#__PURE__*/jsx_runtime_.jsx("span", {
                    className: `${(profileAccount_module_default()).slider} ${(profileAccount_module_default()).round} `
                  })]
                })]
              }), Toggle && /*#__PURE__*/(0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
                children: [/*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
                  className: `form-row form-row--half pb-30 ${(profileAccount_module_default()).mb_30}`,
                  children: [/*#__PURE__*/jsx_runtime_.jsx("label", {
                    className: "form-label",
                    children: "New Password"
                  }), /*#__PURE__*/jsx_runtime_.jsx("input", {
                    type: "password",
                    placeholder: "Password",
                    onChange: e => setformData(editProfile_objectSpread(editProfile_objectSpread({}, formData), {}, {
                      password: e.target.value
                    })),
                    value: formData.password,
                    className: "Input_root__2vmVG"
                  })]
                }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
                  className: `form-row form-row--half pb-30 ${(profileAccount_module_default()).mb_30}`,
                  children: [/*#__PURE__*/jsx_runtime_.jsx("label", {
                    className: "form-label",
                    children: "Confirm New Password"
                  }), /*#__PURE__*/jsx_runtime_.jsx("input", {
                    type: "password",
                    placeholder: "Confirm Password",
                    onChange: e => setformData(editProfile_objectSpread(editProfile_objectSpread({}, formData), {}, {
                      confirmPassword: e.target.value
                    })),
                    value: formData.confirmPassword,
                    className: "Input_root__2vmVG"
                  })]
                })]
              }), resMessage.msg && /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
                className: resMessage.type === 'danger' ? 'bg-danger' : resMessage.type === 'warn' ? 'bg-warn' : 'bg-success',
                children: ["* ", resMessage.msg]
              }), /*#__PURE__*/jsx_runtime_.jsx("div", {
                className: "pt-2 w-full flex flex-col mb-6",
                children: /*#__PURE__*/jsx_runtime_.jsx(Button/* default */.Z, {
                  className: "Button_root__24MxS Button_slim__2caxo",
                  style: {
                    background: '#e99da1',
                    border: 'none',
                    textTransform: 'capitalize',
                    color: 'white',
                    padding: '10px 20px ',
                    borderRadius: '4px'
                  },
                  variant: "slim",
                  type: "submit",
                  children: "Update Profile"
                })
              })]
            })
          })]
        })
      })
    })
  });
}
;// CONCATENATED MODULE: ./components/ProfileInnerPages/messages.tsx
function messages_ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) { symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); } keys.push.apply(keys, symbols); } return keys; }

function messages_objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { messages_ownKeys(Object(source), true).forEach(function (key) { messages_defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { messages_ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function messages_defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }







function messages_Orders() {
  const {
    0: adata,
    1: setVariants
  } = (0,external_react_.useState)([]);
  const {
    data: customer
  } = (0,use_customer/* default */.Z)();
  let {
    0: formData,
    1: setformData
  } = (0,external_react_.useState)({
    message_order_id: '',
    message_subject: '',
    message_content: ''
  });
  let {
    0: resMessage,
    1: setresMessage
  } = (0,external_react_.useState)({
    type: '',
    msg: ''
  });
  (0,external_react_.useEffect)(() => {
    let cid = customer === null || customer === void 0 ? void 0 : customer.entityId;

    if (customer && customer !== null && customer !== void 0 && customer.entityId) {
      fetch('https://www.ystore.us/sleekshop/getOrders.php?customer_id=' + cid).then(response => response.json()).then(rs1 => {
        setVariants(rs1);
      });
    }

    setformData(messages_objectSpread(messages_objectSpread({}, formData), {}, {
      message_order_id: 'Select Your Order'
    }));
  }, [customer]);

  const handleSendMessage = newMessage => {
    const {
      message_order_id,
      message_subject,
      message_content
    } = formData;

    if (message_order_id !== 'Select Your Order' && message_subject && message_content) {
      fetch('https://www.ystore.us/sleekshop/sendMessage.php', {
        // Adding method type
        method: 'POST',
        // Adding body or contents to send
        body: JSON.stringify({
          newMessage
        }),
        headers: {
          'Content-Type': 'application/json'
        }
      }).then(res => {
        return res.json();
      }).then(resObj => {
        if (resObj.success) {
          setresMessage({
            type: 'success',
            msg: resObj.message
          });
          setTimeout(() => {
            setresMessage({
              type: '',
              msg: ''
            });
            setformData({
              message_order_id: '',
              message_subject: '',
              message_content: ''
            });
          }, 4000);
        } else {
          setresMessage({
            type: 'danger',
            msg: resObj.message
          });
          setTimeout(() => {
            setresMessage({
              type: '',
              msg: ''
            });
          }, 4000);
        }
      });
    } else {
      setresMessage({
        type: 'warn',
        msg: 'All Fields Are Required'
      });
      setTimeout(() => {
        setresMessage({
          type: '',
          msg: ''
        });
      }, 4000);
    }
  };

  const handleClearForm = () => {
    setformData({
      message_order_id: 'Select Your Order',
      message_subject: '',
      message_content: ''
    });
  };

  return /*#__PURE__*/jsx_runtime_.jsx(jsx_runtime_.Fragment, {
    children: /*#__PURE__*/jsx_runtime_.jsx("div", {
      className: "MainContentInnerdiv",
      children: /*#__PURE__*/jsx_runtime_.jsx("div", {
        className: `${(edit_shipping_address_module_default()).formComtainer} `,
        style: {
          width: '100%'
        },
        children: /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
          className: "flex-1 flex flex-col justify-center items-center W-90",
          style: {
            width: '85%'
          },
          children: [/*#__PURE__*/jsx_runtime_.jsx("h2", {
            className: "page-heading mt-10",
            style: {
              width: 'auto'
            },
            children: "Send a Message"
          }), /*#__PURE__*/jsx_runtime_.jsx("div", {
            className: "account-body ",
            style: {
              width: '100%'
            },
            children: /*#__PURE__*/(0,jsx_runtime_.jsxs)("form", {
              className: `${(edit_shipping_address_module_default()).form}`,
              children: [/*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
                className: "form-field form-field--select",
                children: [/*#__PURE__*/(0,jsx_runtime_.jsxs)("label", {
                  className: "form-label",
                  children: ["Order:", /*#__PURE__*/jsx_runtime_.jsx("small", {
                    children: "Required"
                  })]
                }), /*#__PURE__*/jsx_runtime_.jsx("select", {
                  className: "form-select",
                  name: "message_order_id",
                  id: "message_order_id",
                  value: formData.message_order_id,
                  onChange: e => {
                    setformData(messages_objectSpread(messages_objectSpread({}, formData), {}, {
                      message_order_id: e.target.value
                    }));
                  },
                  children: Array.isArray(adata) && adata.length > 0 && /*#__PURE__*/(0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
                    children: [/*#__PURE__*/jsx_runtime_.jsx("option", {
                      selected: true,
                      disabled: true,
                      value: "Select Your Order",
                      children: "Select Your Order"
                    }), adata.map(order => {
                      return /*#__PURE__*/(0,jsx_runtime_.jsxs)("option", {
                        value: order.orderId,
                        children: ["Order #", order.orderId, " - Placed on", ' ', order.dateCreated, "for $ ", Number(order.orderTotal).toFixed(2)]
                      });
                    })]
                  })
                })]
              }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
                className: "form-field form-field--input form-field--inputText",
                id: "FormField_4",
                children: [/*#__PURE__*/(0,jsx_runtime_.jsxs)("label", {
                  className: "form-label",
                  children: ["Subject", /*#__PURE__*/jsx_runtime_.jsx("small", {
                    children: "Required"
                  })]
                }), /*#__PURE__*/jsx_runtime_.jsx("input", {
                  type: "text",
                  className: "form-input",
                  name: "message_subject",
                  id: "message_subject",
                  value: formData.message_subject,
                  onChange: e => {
                    setformData(messages_objectSpread(messages_objectSpread({}, formData), {}, {
                      message_subject: e.target.value
                    }));
                  }
                })]
              }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
                className: "form-field form-field--textarea",
                id: "FormField_4_input",
                children: [/*#__PURE__*/(0,jsx_runtime_.jsxs)("label", {
                  className: "form-label",
                  children: ["Message", /*#__PURE__*/jsx_runtime_.jsx("small", {
                    children: "Required"
                  })]
                }), /*#__PURE__*/jsx_runtime_.jsx("textarea", {
                  className: "form-input",
                  name: "message_content",
                  id: "message_content",
                  value: formData.message_content,
                  rows: 7,
                  onChange: e => {
                    setformData(messages_objectSpread(messages_objectSpread({}, formData), {}, {
                      message_content: e.target.value
                    }));
                  }
                })]
              }), resMessage.msg && /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
                className: resMessage.type === 'danger' ? 'bg-danger' : resMessage.type === 'warn' ? 'bg-warn' : 'bg-success',
                children: ["* ", resMessage.msg]
              }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
                className: "form-field form-field--textarea d-flex",
                children: [/*#__PURE__*/jsx_runtime_.jsx("button", {
                  type: "submit",
                  className: "btn ",
                  style: {
                    background: '#e99da1',
                    border: 'none',
                    color: 'white',
                    textTransform: 'capitalize',
                    padding: '10px 20px ',
                    borderRadius: '4px'
                  },
                  onClick: () => handleSendMessage(formData),
                  children: "Send Message"
                }), /*#__PURE__*/jsx_runtime_.jsx("button", {
                  className: "btn ",
                  style: {
                    background: 'white',
                    border: '1px solid #B0B0B0	',
                    textTransform: 'capitalize',
                    color: 'black',
                    padding: '10px 20px',
                    borderRadius: '4px',
                    marginLeft: '20px'
                  },
                  onClick: () => handleClearForm(),
                  children: "Clear"
                })]
              })]
            })
          })]
        })
      })
    })
  });
}
;// CONCATENATED MODULE: ./components/ProfileInnerPages/sleekValut.tsx


// import { useEffect } from 'react'
// import useCustomer from '@framework/customer/use-customer'
// import { useUI } from '@components/ui'
// declare global {
//   interface Window {
//     attachEvent(event: string, listener: EventListener): boolean
//     detachEvent(event: string, listener: EventListener): void
//   }
// }
function sleekValut_SleekVault() {
  // const { data } = useCustomer()
  // const { openModal, setModalView } = useUI()
  // let sa_uni: string[][] = []
  // let sa_emailid
  // let site_id = process.env.site_id || 7870040
  // const sa_async_load = () => {
  //   let sa = document.createElement('script')
  //   sa.type = 'text/javascript'
  //   sa.async = true
  //   sa.src = `//cdn.socialannex.com/partner/${site_id}/universal.js`
  //   var sax = document.getElementsByTagName('script')[0]
  //   sax?.parentNode?.insertBefore(sa, sax)
  //   return sa
  // }
  // useEffect(() => {
  //   if (!data) {
  //     setModalView('LOGIN_VIEW')
  //     return openModal()
  //   }
  //   sa_emailid = data?.email
  //   sa_uni.push(['sa_pg', '5'])
  //   let ScriptLogger = sa_async_load()
  //   console.log('ScriptLogger 41 abc ==>> ', ScriptLogger)
  //   if (window.attachEvent) {
  //     window.attachEvent('onload', sa_async_load)
  //   } else {
  //     window.addEventListener('load', sa_async_load, false)
  //   }
  // }, [data])
  return /*#__PURE__*/jsx_runtime_.jsx(jsx_runtime_.Fragment, {
    children: /*#__PURE__*/jsx_runtime_.jsx("div", {
      className: "MainContentInnerdiv mb-2 orderHistory d-flex justify-content-between",
      children: /*#__PURE__*/jsx_runtime_.jsx("div", {
        id: "socialannex_dashboard"
      })
    })
  });
}
;// CONCATENATED MODULE: ./components/ProfileInnerPages/login.tsx




const login = ({
  ShowPage
}) => {
  const {
    openModal,
    setModalView
  } = (0,context/* useUI */.l8)();
  (0,external_react_.useEffect)(() => {
    setModalView('LOGIN_VIEW');
    openModal();
  }, [ShowPage]);
  return /*#__PURE__*/jsx_runtime_.jsx("div", {
    className: "MainContentInnerdiv mb-2 orderHistory",
    style: {
      display: 'flex',
      height: '40vh',
      width: '100%',
      flexWrap: 'wrap',
      alignContent: 'center',
      justifyContent: 'space-evenly',
      fontSize: '20px',
      fontWeight: 600
    },
    children: "Login First ..."
  });
};

/* harmony default export */ const ProfileInnerPages_login = (login);
;// CONCATENATED MODULE: ./pages/profile.tsx





 // inner components














async function getStaticProps({
  preview,
  locale,
  locales
}) {
  const config = {
    locale,
    locales
  };
  const pagesPromise = commerce/* default.getAllPages */.Z.getAllPages({
    config,
    preview
  });
  const siteInfoPromise = commerce/* default.getSiteInfo */.Z.getSiteInfo({
    config,
    preview
  });
  const {
    pages
  } = await pagesPromise;
  const {
    categories
  } = await siteInfoPromise;
  return {
    props: {
      pages,
      categories
    }
  };
}
function Profile() {
  const {
    data
  } = (0,use_customer/* default */.Z)();
  const {
    openModal,
    setModalView,
    closeModal
  } = (0,context/* useUI */.l8)(); // Buy it again (1)  // Order History (2)  // SleekVault (3)  // Wishlist (4)
  // Recently Viewed (5)  // Messages (6)  // Edit Info (7)   // Addresses (8)
  // Payment Methods (9)

  const {
    0: ShowPage,
    1: setShowPage
  } = (0,external_react_.useState)(1);
  const {
    0: userName,
    1: setuserName
  } = (0,external_react_.useState)('User');
  const {
    0: ShowOrderHistoryDetails,
    1: setShowOrderHistoryDetails
  } = (0,external_react_.useState)(false);
  (0,external_react_.useEffect)(() => {
    if (data) {
      setModalView('');
      const newUserName = data.firstName + ' ' + data.lastName;
      setuserName(newUserName);
      return closeModal();
    } else {
      setuserName('User');
    }
  }, [data]);
  return /*#__PURE__*/jsx_runtime_.jsx(Container/* default */.Z, {
    children: /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
      className: "row p-t-30",
      children: [/*#__PURE__*/jsx_runtime_.jsx(profile_head, {
        userName: userName,
        setShowPage: setShowPage,
        ShowPage: ShowPage,
        setShowOrderHistoryDetails: setShowOrderHistoryDetails
      }), /*#__PURE__*/jsx_runtime_.jsx("div", {
        className: "right-side-content",
        children: data ?
        /*#__PURE__*/
        // {/* // all components are going to be here // */}
        jsx_runtime_.jsx(jsx_runtime_.Fragment, {
          children: ShowPage === 1 ? /*#__PURE__*/jsx_runtime_.jsx(Orders, {}) : ShowPage === 2 ? /*#__PURE__*/jsx_runtime_.jsx(OrderHistory, {
            ShowOrderHistoryDetails: ShowOrderHistoryDetails,
            setShowOrderHistoryDetails: setShowOrderHistoryDetails
          }) : ShowPage === 3 ? /*#__PURE__*/jsx_runtime_.jsx(sleekValut_SleekVault, {}) : ShowPage === 4 ? /*#__PURE__*/jsx_runtime_.jsx(Wishlist, {}) : ShowPage === 5 ? /*#__PURE__*/jsx_runtime_.jsx(RecentItems, {}) : ShowPage === 6 ? /*#__PURE__*/jsx_runtime_.jsx(messages_Orders, {}) : ShowPage === 7 ? /*#__PURE__*/jsx_runtime_.jsx(editProfile, {}) : ShowPage === 8 ? /*#__PURE__*/jsx_runtime_.jsx(Address, {}) : ShowPage === 9 && /*#__PURE__*/jsx_runtime_.jsx(payments_Orders, {})
        }) : /*#__PURE__*/jsx_runtime_.jsx(ProfileInnerPages_login, {
          ShowPage: ShowPage
        })
      })]
    })
  });
}
Profile.Layout = Layout/* default */.Z;

/***/ }),

/***/ 6899:
/***/ ((module) => {

// Exports
module.exports = {
	"panelbodyCo": "addresses_panelbodyCo__210KS",
	"ulParen": "addresses_ulParen__dysD9",
	"panelbody": "addresses_panelbody__OEjFO"
};


/***/ }),

/***/ 1752:
/***/ ((module) => {

// Exports
module.exports = {
	"formComtainer": "edit_shipping_address_formComtainer__1fnjU",
	"W-100": "edit_shipping_address_W-100__jaU-6",
	"W-90": "edit_shipping_address_W-90__3WaWv",
	"mb-6": "edit_shipping_address_mb-6__2Zbry",
	"W-80": "edit_shipping_address_W-80__2bAvA",
	"form": "edit_shipping_address_form__2Fnwk",
	"inputFieldAd": "edit_shipping_address_inputFieldAd__62C8f",
	"submitBtn": "edit_shipping_address_submitBtn__1MEFZ"
};


/***/ }),

/***/ 7120:
/***/ ((module) => {

// Exports
module.exports = {
	"switch": "profileAccount_switch__3Ta16",
	"slider": "profileAccount_slider__1tV0r",
	"round": "profileAccount_round__2ubFV",
	"mb_30": "profileAccount_mb_30__1JtBQ"
};


/***/ }),

/***/ 2629:
/***/ ((module) => {

// Exports
module.exports = {
	"incrementParent": "ProfileInner_incrementParent__37cVH",
	"QtyText": "ProfileInner_QtyText__2mDR8",
	"detailsQtyText": "ProfileInner_detailsQtyText__2ynZy",
	"decrementBtn": "ProfileInner_decrementBtn___Ch6a",
	"incrementBtn": "ProfileInner_incrementBtn__1Q4Id",
	"AddToCartOnHover_0ne": "ProfileInner_AddToCartOnHover_0ne__2mnF2",
	"inputEDCartVal": "ProfileInner_inputEDCartVal__3LBdE",
	"outOfStock": "ProfileInner_outOfStock__2LYgn",
	"inStock": "ProfileInner_inStock__3JRe8",
	"ShowPartialProductDetailsPage": "ProfileInner_ShowPartialProductDetailsPage__VyUD6",
	"incrementParentModel": "ProfileInner_incrementParentModel__2yP8Z"
};


/***/ }),

/***/ 2937:
/***/ ((module) => {

"use strict";
module.exports = require("@vercel/fetch");

/***/ }),

/***/ 8023:
/***/ ((module) => {

"use strict";
module.exports = require("body-scroll-lock");

/***/ }),

/***/ 4058:
/***/ ((module) => {

"use strict";
module.exports = require("classnames");

/***/ }),

/***/ 506:
/***/ ((module) => {

"use strict";
module.exports = require("email-validator");

/***/ }),

/***/ 2740:
/***/ ((module) => {

"use strict";
module.exports = require("immutability-helper");

/***/ }),

/***/ 6155:
/***/ ((module) => {

"use strict";
module.exports = require("js-cookie");

/***/ }),

/***/ 5371:
/***/ ((module) => {

"use strict";
module.exports = require("lodash.debounce");

/***/ }),

/***/ 1602:
/***/ ((module) => {

"use strict";
module.exports = require("lodash.throttle");

/***/ }),

/***/ 2517:
/***/ ((module) => {

"use strict";
module.exports = require("next-themes");

/***/ }),

/***/ 9325:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/server/denormalize-page-path.js");

/***/ }),

/***/ 822:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/server/image-config.js");

/***/ }),

/***/ 6695:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/head.js");

/***/ }),

/***/ 8300:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/i18n/detect-domain-locale.js");

/***/ }),

/***/ 5378:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/i18n/normalize-locale-path.js");

/***/ }),

/***/ 2307:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/loadable.js");

/***/ }),

/***/ 7162:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/mitt.js");

/***/ }),

/***/ 8773:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router-context.js");

/***/ }),

/***/ 2248:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/get-asset-path-from-route.js");

/***/ }),

/***/ 9372:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/is-dynamic.js");

/***/ }),

/***/ 665:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/parse-relative-url.js");

/***/ }),

/***/ 2747:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/querystring.js");

/***/ }),

/***/ 654:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/resolve-rewrites.js");

/***/ }),

/***/ 333:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/route-matcher.js");

/***/ }),

/***/ 3456:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/route-regex.js");

/***/ }),

/***/ 556:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/to-base-64.js");

/***/ }),

/***/ 7620:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/utils.js");

/***/ }),

/***/ 6731:
/***/ ((module) => {

"use strict";
module.exports = require("next/router");

/***/ }),

/***/ 8689:
/***/ ((module) => {

"use strict";
module.exports = require("next/script");

/***/ }),

/***/ 9297:
/***/ ((module) => {

"use strict";
module.exports = require("react");

/***/ }),

/***/ 123:
/***/ ((module) => {

"use strict";
module.exports = require("react-merge-refs");

/***/ }),

/***/ 5282:
/***/ ((module) => {

"use strict";
module.exports = require("react/jsx-runtime");

/***/ }),

/***/ 7749:
/***/ ((module) => {

"use strict";
module.exports = require("swr");

/***/ }),

/***/ 8047:
/***/ ((module) => {

"use strict";
module.exports = require("tabbable");

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [157,370,862,79,428,909], () => (__webpack_exec__(5044)));
module.exports = __webpack_exports__;

})();