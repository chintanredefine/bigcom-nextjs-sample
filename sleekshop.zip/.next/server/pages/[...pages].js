(() => {
var exports = {};
exports.id = 454;
exports.ids = [454];
exports.modules = {

/***/ 1460:
/***/ ((module) => {

const page = {
  id: 9,
  name: 'about-us',
  is_visible: true,
  sort_order: 41,
  //  body: `<h2class=\"fg-white\">AboutUs<\/h2><pclass=\"fg-white\">developing and supporting complex IT solutions.Touchingmillions of lives world wide by bringing in innovative technology <\/p>`,
  body: `<main class="page">
        <h1 class="page-heading" style="text-transform: uppercase;text-align: center;display: flex;align-items: center;justify-content: center;font-size: 28px;" >Who We Are</h1>
        <div class="page-content">
                <p><div id="socialannex1"></div></p><div class="about-us-team">
                <div class="about-team-row1">
                <div class="about-team-title"><span style="color: #222324;
                    display: block;
                    font-size: 25px;
                    font-weight: normal;
                    line-height: 25px;
                    margin: 0 auto;
                    padding: 5px 0;
                    text-transform: uppercase; border-top: 1px solid #00000085;">Mission Statement</span></div>
                <div class="about-team-datail">
                <p>Sleekshop.com seeks to be the world’s leading online source of exclusive, quality beauty products from classic, emerging and niche brands. Through exceptional service, creativity and innovation, we strive to be not only become the ultimate beauty destination for customers worldwide, but also a place where our brands can grow and flourish. We are deeply dedicated to serving our employees, customers and brand partners alike.</p>
                </div>
                </div>
                <div class="about-team-row1">
                <div class="about-team-title"><span style="color: #222324;
                    display: block;
                    font-size: 25px;
                    font-weight: normal;
                    line-height: 25px;
                    margin: 0 auto;
                    padding: 5px 0;
                    text-transform: uppercase; border-top: 1px solid #00000085;">History</span></div>
                <div class="about-team-datail">
                <p>Founded in 1997, Sleekshop.com was started by Andrew Ngo when he was just a junior in high school. As an avid and self-taught technology guru (from graphic design to building computers and everything in between), Andrew always had a natural ambition for achievement and innovation. His entrepreneurial spirit was nurtured at a very young age in his mother's salon where she worked as a nail technician and hairstylist. At the salon, Andrew was able to spend a lot of time watching and learning how to grow a business. By age 15, he was managing all aspects of the salon including inventory, sales and customer service. Discovering the gap in access to high quality beauty products for everyday consumers, Andrew quickly sought to make all exclusive leading brands available to the world at the best prices possible.</p>
                <p>Merging his passion for the internet with his extensive knowledge in the beauty industry, Andrew launched Sleekshop in the humble environment of his garage. While pursuing a Bachelor's of Economics at UC Irvine, Andrew steadily grew Sleekshop's volume from one order a month to several requests day. Despite various hurdles of juggling school and the increasing demands of a small business, Andrew pressed on with confidence that his vision would someday become a reality.</p>
                </div>
                </div>
                <div class="about-team-row1">
                <div class="about-team-title"><span style="color: #222324;
                    display: block;
                    font-size: 25px;
                    font-weight: normal;
                    line-height: 25px;
                    margin: 0 auto;
                    padding: 5px 0;
                    text-transform: uppercase; border-top: 1px solid #00000085;">Present Day</span></div>
                <div class="about-team-datail">
                <p>Today, more than a decade later, Sleekshop.com is one of the top online destinations for leading hair care products from every brand imaginable. And it's not just limited to hair—Sleekshop.com now offers brands for nails, skin, cosmetics, babies and even pets! With over 16,000 products of 300 salon-exclusive and specialty brands, Sleekhair.com is committed to helping customers worldwide (in 60+ countries) fulfill just about any beauty care need.</p>
                <p>From its beginnings in a garage to going global, Sleekshop.com prides itself on having a foundation of stellar yet personalized service and a fun, family culture. To this day, Sleekshop.com stands as a proud family-owned business based on Andrew's founding principal of "continually innovating and creating better experiences for not only [its] customers, but [its] employees, vendors, and the entire beauty industry."</p>
                <p>Our dynamic customer-centric team loves hearing from our customers, and always welcomes feedback. So whether you have some suggestions or comments, say hello to us on:</p>
                <p style="display: flex;"><a title="Sleekshop on Pinterest" href="http://pinterest.com/sleekhair/" target="_blank"><img style="padding: 0; margin: 0 10px 5px 10px;" title="Sleekshop on Pinterest" src="https://cdn11.bigcommerce.com/s-hmhnh4h9/content/site-support-imgs/who-we-are/icons/pinterest-icon.jpg" alt="Sleekshop on Pinterest" width="39" height="39" align="absmiddle" border="0"></a> <a title="Sleekshop on instagram" href="http://instagram.com/sleekhair" target="_blank"><img style="padding: 0; margin: 0 10px 5px 10px;" title="Sleekshop on instagram" src="https://cdn11.bigcommerce.com/s-hmhnh4h9/content/site-support-imgs/who-we-are/icons/insta-icon.jpg" alt="Sleekshop on instagram" width="39" height="39" align="absmiddle" border="0"></a> <a title="Sleekshop on facebook" href="https://www.facebook.com/sleekhair" target="_blank"><img style="padding: 0; margin: 0 10px 5px 10px;" title="Sleekshop on facebook" src="https://cdn11.bigcommerce.com/s-hmhnh4h9/content/site-support-imgs/who-we-are/icons/fb-icon.jpg" alt="Sleekshop on facebook" width="39" height="39" align="absmiddle" border="0"></a> <a title="Sleekshop on tumblr" href="http://sleekhair.tumblr.com/"><img style="padding: 0; margin: 0 10px 5px 10px;" title="Sleekshop on tumblr" src="https://cdn11.bigcommerce.com/s-hmhnh4h9/content/site-support-imgs/who-we-are/icons/tumblr-icon.jpg" alt="Sleekshop on tumblr" width="39" height="39" align="absmiddle" border="0"></a> <a title="Sleekshop on twitter" href="https://twitter.com/SleekShopCom" target="_blank"><img style="padding: 0; margin: 0 10px 5px 10px;" title="Sleekshop on twitter" src="https://cdn11.bigcommerce.com/s-hmhnh4h9/content/site-support-imgs/who-we-are/icons/twitter-icon.jpg" alt="Sleekshop on twitter" width="39" height="39" align="absmiddle" border="0"></a></p>
                </div>
                </div>
                <div class="about-team-row1">
                <div class="about-team-title">&nbsp;</div>
                <table class="team-datail-pt1" border="0" cellspacing="0" cellpadding="0" align="left">
                <tbody>
                <tr>
                <td align="left" valign="middle" width="15%"><img title="Andrew NGO" src="https://cdn11.bigcommerce.com/s-hmhnh4h9/content/site-support-imgs/who-we-are/Andrew-Ngo.jpg" alt="Andrew NGO"></td>
                <td class="team-name" align="center" valign="middle" width="15%">
                <h2 style=" font-size: 25px;">ANDREW NGO</h2>
                <span>Founder &amp; CEO</span></td>
                <td class="team-description" align="left">
                <p>Andrew started Sleekshop in 2002 when he was just a high school junior and grew the company while he was majoring in Economics at the University of California, Irvine. As Chief Executive Officer, he oversees the company's financials, marketing, sales, and inventory, which boasts over 16,000 unique beauty products. He takes pride in seeing his many hours of hard work pay off but also in developing what he calls Sleek Culture. "I love seeing the company grow day by day. I love seeing how I can support my employees and help them grow as well." Away from his desk, he enjoys basketball, snowboarding, reading about business and technology, and craft beer.</p>
                <p><strong>Family Factoid:</strong> Only boy in the family and youngest of three.</p>
                <p><strong>Favorite Website Beside Sleekshop.com:</strong> Reddit for trending topics—"you can read about technology, business, science, world events, or funny articles about people's cats"</p>
                <p><strong>Must-Have Beauty Product:</strong> TIGI Bed Head for Men Matte Separation Wax</p>
                <p><strong>Playing on his iPod:</strong> Cut Copy</p>
                </td>
                </tr>
                <tr>
                <td colspan="3">&nbsp;</td>
                </tr>
                <tr>
                <td colspan="3">&nbsp;</td>
                </tr>
                <tr>
                <td align="left" valign="middle" width="15%"><img title="Joan NGO" src="https://cdn11.bigcommerce.com/s-hmhnh4h9/content/site-support-imgs/who-we-are/Joan-Ngo.jpg" alt="Joan NGO"></td>
                <td class="team-name" align="center" valign="middle" width="15%">
                <h2 style=" font-size: 25px;">JOAN NGO</h2>
                <span>COO</span></td>
                <td class="team-description" align="left">
                <p>As Chief Operating Officer since June 2011, Joan is responsible for developing strategy and policies as well as coordinating marketing campaigns and customer loyalty programs. With a background in nonprofit management, international development, and social leadership, she was instrumental in creating an employee-centered company culture deeply dedicated to delighting customers. "I make sure our employees are well supported and happy so they can in turn keep our customers happy." This UCLA alumnus is dedicated to tribal belly dancing, holistic healing, world travel and humanitarian outreach in the developing world, particularly Paraguay and China.</p>
                <p><strong>Family Factoid:</strong> She is the oldest of three kids.</p>
                <p><strong>Favorite Website Beside Sleekshop.com:</strong> Inc.com, Harvard Business Review, Etsy.com—she supports small local vendors here and abroad whenever she can.</p>
                <p><strong>Must-Have Beauty Product:</strong> Carol's Daughter Rosemary Mint Clarifying Shampoo and Conditioner; anything for hair or body by Philip B</p>
                <p><strong>Playing on her Radio:</strong> World beats, Audio Books, TED Talks, Good Food 89.9 FM</p>
                </td>
                </tr>
                <tr>
                <td colspan="3">&nbsp;</td>
                </tr>
                <tr>
                <td colspan="3">&nbsp;</td>
                </tr>
                <tr>
                <td align="left" valign="middle" width="15%"><img title="Hosea" src="https://cdn11.bigcommerce.com/s-hmhnh4h9/content/site-support-imgs/who-we-are/Hosea.jpg" alt="Hosea"></td>
                <td class="team-name" align="center" valign="middle" width="15%">
                <h2 style=" font-size: 25px;">HOSEA</h2>
                <span>Warehouse Manager</span></td>
                <td class="team-description" align="left">
                <p>Hosea became Warehouse Manager in June 2012 with an extensive and<br> diverse background in retail distribution for such companies as Toys"R"Us, <br> Pacific Sunwear, and Crocs. He currently manages all operations within the <br> Sleekshop distribution warehouse, from receiving and inventory to transportation <br> and logistics. Heavily involved in warehouse layout, contract negotiations, <br> and future planning, he highly regards his workplace freedom to create <br> change: "I love a fast-paced environment that challenges and brings out<br> the best in me." In his free time he enjoys weightlifting, golf, and being with<br> his family.</p>
                <p><strong>Favorite Website Beside Sleekshop.com:</strong> Amazon.com</p>
                <p><strong>Must-Have Beauty Product:</strong> Hair Rules and Alterna Caviar shampoos and conditioners.</p>
                <p><strong>Playing on his Radio:</strong> 92.3 HOT FM, 93.1 Jack FM, 104.3 My FM</p>
                <p><strong>Current Aspirations:</strong> Professionally to develop talent within the company and personally to be the "best husband and father on the planet"</p>
                </td>
                </tr>
                <tr>
                <td colspan="3">&nbsp;</td>
                </tr>
                <tr>
                <td colspan="3">&nbsp;</td>
                </tr>
                <tr>
                <td colspan="3">&nbsp;</td>
                </tr>
                <tr>
                <td colspan="3">&nbsp;</td>
                </tr>
                <tr>
                <td align="left" valign="middle" width="15%"><img title="Christina" src="https://cdn11.bigcommerce.com/s-hmhnh4h9/content/site-support-imgs/who-we-are/Christina.jpg" alt="Christina"></td>
                <td class="team-name" align="center" valign="middle" width="15%">
                <h2 style=" font-size: 25px;">CHRISTINA KRASCH</h2>
                <span>Marketing Coordinator</span></td>
                <td class="team-description" align="left">
                <p>Christina joined the Sleekshop team in 2014. She serves as Sleekshops marketing coordinator and embraces the many hats she wears. Christina is an all around beauty guru, with over 10 years of experience working in the beauty industry; she enjoys exploring the vast world the beauty industry offers. “I love learning about new products and why they attract makeup junkies like myself”. Away from her desk Christina enjoys spending quality time with friends and family, and of course trying new makeup.</p>
                <p><strong>Family Factoid:</strong> She has been happily married to her best friend for 7 years.</p>
                <p><strong>Favorite Website Beside Sleekshop.com:</strong> Yelp, it never does her wrong.</p>
                <p><strong>Must-Have Beauty Product:</strong> There isn’t one, she "must have" it all.</p>
                <p><strong>Current Obsession:</strong> Netflix and chill.</p>
                </td>
                </tr>
                <tr>
                <td colspan="3">&nbsp;</td>
                </tr>
                <tr>
                <td colspan="3">&nbsp;</td>
                </tr>
                <tr>
                <td align="left" valign="middle" width="15%"><img title="Khanh" src="https://cdn11.bigcommerce.com/s-hmhnh4h9/content/site-support-imgs/who-we-are/Khanh-new.jpg" alt="Khanh"></td>
                <td class="team-name" align="center" valign="middle" width="15%">
                <h2 style=" font-size: 25px;">KHANH</h2>
                <span>Digital Marketing Strategist</span></td>
                <td class="team-description" align="left">
                <p>Khanh came to Sleekshop in June 2012 after graduating from UCLA with an Economics degree. She serves as Executive Assistant to the Chief Executive Officer and Chief Operating Officer while also supporting other departments' day-to-day operations. She wears her many hats with a smile, "I could not have chosen a better place to develop myself professionally as well as personally." She enjoys working with the dynamic people at Sleekhair, where employees' ideas are not only valued but come to life. She enjoys reading, trying ethnic cuisines, and a good chat with friends.</p>
                <p><strong>Family Factoid:</strong> She's the only girl in her family</p>
                <p><strong>Favorite Website Beside Sleekshop.com:</strong> Yahoo! News and Wendy's Lookbook</p>
                <p><strong>Must-Have Beauty Product:</strong> Lipstick—any color she wears matches her mood!</p>
                <p><strong>Playing on her Radio:</strong> Rock jams compliments of 98.7 FM</p>
                <p><strong>Current Obsession:</strong> Macarons and passion fruit cake from Whole Foods</p>
                </td>
                </tr>
                </tbody>
                </table>
                </div>
                </div>
                </div>

                </main>`
};
module.exports = page;

/***/ }),

/***/ 5370:
/***/ ((module) => {

// import image01 from "assets/images/"
const page = {
  id: 133,
  channel_id: 1,
  name: 'ammonia-vs-no-ammonia',
  is_visible: true,
  sort_order: 41,
  body: `<main class="page ammonia-vs-no-ammonia_parent">
        <div class="ammonia px-4">
  <div class="d-sticky-link-ammonia">
    <ul class="sticky-link">
      <li>
        <a href="#Ammonia01" class="pink active" 
          ><img src="	https://cdn11.bigcommerce.com/s-hmhnh4h9/product_images/uploaded_images/mobile-icon-01.png" alt=""
        /></a>
      </li>
      <li>
        <a href="#Ammonia02" >01</a>
      </li>
      <li>
        <a href="#Ammonia03">02</a>
      </li>
      <li>
        <a href="#Ammonia04">03</a>
      </li>
      <li>
        <a href="#Ammonia05">04</a>
      </li>
      <li>
        <a href="#Ammonia06" class="black"
          ><img src="https://cdn11.bigcommerce.com/s-hmhnh4h9/product_images/uploaded_images/mobile-icon-02.png" alt=""
        /></a>
      </li>
    </ul>
  </div>
  <div class="d-main-left-ammonia">
    <!-- section 1 -->
    <div id="Ammonia01">&nbsp;</div>
    <div class="d-left-ammonia">
      <div class="m-img m-b-10"><img src="https://cdn11.bigcommerce.com/s-hmhnh4h9/product_images/uploaded_images/mobile-img-01.jpg" alt="" /></div>
      <div class="d-text-1 m-b-50">
        <div class="ammonia-title-1">ammonia vs. no ammonia</div>
        <div class="ammonia-title-2">
          We are all paying more attention to what's in our beauty products.
        </div>
        <div class="ammonia-text max-w-504">
          With the rise in popularity of clean beauty, we are looking more closely at those
          ingredient labels and getting rid of products that contain things that may be harmful to
          our skin, hair and health.
        </div>
        <div class="ammonia-title-3 max-w-504">
          When it comes to hair color, you may keep hearing words like "ammonia" or "ammonia-free"
          and wonder if you should be choosing one over other.
        </div>
        <div class="ammonia-text max-w-504">
          You want to make sure you're using a safe hair color, as well as getting the results that
          you want for your hair.
        </div>
      </div>
    </div>
    <div class="d-right-ammonia">
      <div class="m-b-50 d-sec-1-img"><img src="https://cdn11.bigcommerce.com/s-hmhnh4h9/product_images/uploaded_images/desktop-img-01.jpg" alt="" /></div>
    </div>
    <div class="clearfix"></div>
    <!-- section 1 -->

    <!-- section 2 -->
    <div id="Ammonia02">&nbsp;</div>
    <div class="d-left-ammonia">
      <div class="m-b-50 d-sec-2-img"><img src="https://cdn11.bigcommerce.com/s-hmhnh4h9/product_images/uploaded_images/desktop-img-02.jpg" alt="" /></div>
    </div>
    <div class="d-right-ammonia">
      <div class="m-img m-b-50"><img src="https://cdn11.bigcommerce.com/s-hmhnh4h9/product_images/uploaded_images/mobile-img-02.jpg" alt="" /></div>
      <div class="d-text-2 m-b-50">
        <div class="ammonia-title-1">First things first</div>
        <div class="ammonia-title-2">
          When trying to understand the difference between ammonia-based hair color and ammonia-free
          hair color, it's important to understand why ammonia is there in the first place.
        </div>
        <div class="ammonia-title-3">
          The first and most important thing is that Ammonia is used in permanent hair color!
        </div>
        <div class="ammonia-text">
          Ammonia is an alkaline chemical which causes the PH of our hair to rise while it is being
          colored. This allows for the color to lift the cuticle (think of the cuticle like a shell
          that protects the rest of your hair strand) and deposit your hair color into the hair's
          cortex (the cortex is where hair's pigment is found). Without the ammonia, the color would
          not be able to deposit the pigment deep enough into the hair strand for it to last. The
          color would instead lay on the outside of the hair's cuticle where it would soon rinse off
          and therefore it would not be permanent.
        </div>
      </div>
    </div>
    <div class="clearfix"></div>
    <!-- section 2 -->

    <!-- section 3 -->
    <div id="Ammonia03">&nbsp;</div>
    <div class="d-left-ammonia">
      <div class="d-text-3 m-b-50">
        <div class="m-img m-b-10"><img src="https://cdn11.bigcommerce.com/s-hmhnh4h9/product_images/uploaded_images/mobile-img-03.jpg" alt="" /></div>
        <div class="ammonia-title-1">IF IT'S NOT AMMONIA THAN WHAT IT IS?</div>
        <div class="ammonia-title-2 max-w-504">
          This is where things get a bit tricky! There are two types of ammonia - free color.
        </div>

        <div class="ammonia-text max-w-504">
          The first one is semi or demi permanent hair color which uses a low developer or no
          developer at all to deposit hair color. This type of color does not penetrate your hair
          strand and cannot lighten your hair. Instead it lays on the outside of the hair and rinses
          out gradually.
        </div>
        <div class="ammonia-text max-w-504">
          <strong>There is also permanent ammonia-free hair color.</strong> Keep in mind,
          ammonia-free does not mean chemical-free or all natural. This hair color still needs an
          alkalizing chemical to be able to permanently color your hair. So instead of using
          ammonia, it uses chemicals that work very similarly to ammonia, monoethanolamine (MEA) or
          aminomethylpropanol (AMP). These chemicals also lift the cuticle and deposit color into
          the hair's cortex.
        </div>
      </div>
    </div>
    <div class="d-right-ammonia">
      <div class="m-b-50 d-sec-3-img"><img src="https://cdn11.bigcommerce.com/s-hmhnh4h9/product_images/uploaded_images/desktop-img-03.jpg" alt="" /></div>
    </div>
    <div class="clearfix"></div>
    <!-- section 3 -->

    <!-- section 4 -->
    <div id="Ammonia04">&nbsp;</div>
    <div class="d-left-ammonia">
      <div class="m-b-50 d-sec-4-img"><img src="https://cdn11.bigcommerce.com/s-hmhnh4h9/product_images/uploaded_images/desktop-img-04.jpg" alt="" /></div>
    </div>
    <div class="d-right-ammonia">
      <div class="d-text-4 m-b-50">
        <div class="m-img m-b-10"><img src="https://cdn11.bigcommerce.com/s-hmhnh4h9/product_images/uploaded_images/mobile-img-04.jpg" alt="" /></div>
        <div class="ammonia-title-1">NOW THAT WE UNDERSTAND HOW THEY WORK;</div>
        <div class="ammonia-title-2">Let's look at the Pros & Cons</div>

        <div class="ammonia-text">
          We'll start with ammonia-based hair color. Ammonia-based hair color has been used for
          years and most likely started getting a bad rap because of its strong smell. However,
          ammonia-based hair color has been proven very safe and there is no research to suggest it
          causes cancers or hormone disruption.
        </div>
        <div class="ammonia-text">
          Ammonia is a smaller molecule which makes it very effective and efficient (also what
          causes the strong smell). Ammonia gives solid results especially for things such as gray
          coverage and vibrant or long-lasting color. Also because of the smaller molecule it rinses
          out of the hair quicker which prevents damage and keeps hair healthier.
        </div>
        <div class="ammonia-text">
          Some people do have a sensitivity to ammonia and in that case an ammonia-based hair color
          would not be a good choice. It's always recommended to do a patch test before using any
          kind of hair color to make sure you won't have a reaction!
        </div>
      </div>
    </div>
    <div class="clearfix"></div>
    <!-- section 4 -->

    <!-- section 5 -->
    <div id="Ammonia05">&nbsp;</div>  
    <div class="m-b-50 d-sec-5-img"><img src="https://cdn11.bigcommerce.com/s-hmhnh4h9/product_images/uploaded_images/desktop-img-05.jpg" alt="" /></div>

    <div class="d-left-ammonia">
      <div class="m-img m-b-10"><img src="https://cdn11.bigcommerce.com/s-hmhnh4h9/product_images/uploaded_images/mobile-img-05.jpg" alt="" /></div>
      <div class="d-text-5a m-b-50">
        <div class="ammonia-title-1">Now for the ammonia- free color.</div>
        <div class="ammonia-title-2 max-w-504">
          Ammonia- free makes it sound like a safer alternative to traditional permanent
          ammonia-based color but because MEA and AMP are a newer addition to hair color there is
          not as much research on their long-term effects.
        </div>
      </div>
    </div>
    <div class="d-right-ammonia">
      <div class="d-text-5b m-b-50">
        <div class="ammonia-text">
          MEA and AMP are a larger molecule and although they color hair in much the same way, it
          has been noted that because of this they don't cover grays as effectively or have the same
          staying power as ammonia based. A benefit of the larger molecule is that it has a much
          milder smell.
        </div>
        <div class="ammonia-text">
          MEA and AMP do give a great option for people who have a sensitivity to ammonia. It should
          also be said that demi and semi-permanent hair color options should be your go-to if you
          do not want to cover grays or go lighter (i.e. you want to stay the same color or go
          darker). This will be your most gentle option as it does not permanently color your hair.
        </div>
      </div>
      <div id="Ammonia06">&nbsp;</div>
      <div class="m-img m-b-50"><img src="https://cdn11.bigcommerce.com/s-hmhnh4h9/product_images/uploaded_images/mobile-img-06.jpg" alt="" /></div>
    </div>
    <div class="clearfix"></div>

    <div class="m-b-50 d-sec-6-img">
      <img src="https://cdn11.bigcommerce.com/s-hmhnh4h9/product_images/uploaded_images/desktop-img-06.jpg" alt="" />
    </div>
    <!-- section 5 -->
  </div>
  <div class="clearfix"></div>
  <div class="m-sticky-link-ammonia"></div>
</div>

<div class="footer-sticky sticky-link">
  <ul>
    <li>
      <a href="#Ammonia01" href="javascript:void(0);" class="pink active"
        ><img src="https://cdn11.bigcommerce.com/s-hmhnh4h9/product_images/uploaded_images/destop-icon-01.png" alt=""
      /></a>
    </li>
    <li>
      <a href="#Ammonia02" href="javascript:void(0);">01</a>
    </li>
    <li>
      <a href="#Ammonia03" href="javascript:void(0);">02</a>
    </li>
    <li>
      <a href="#Ammonia04" href="javascript:void(0);">03</a>
    </li>
    <li>
      <a href="#Ammonia05" href="javascript:void(0);">04</a>
    </li>
    <li>
      <a href="#Ammonia06" href="javascript:void(0);" class="black"
        ><img src="https://cdn11.bigcommerce.com/s-hmhnh4h9/product_images/uploaded_images/destop-icon-02.png" alt=""
      /></a>
    </li>
  </ul>
</div>

                </main>`
};
module.exports = page;

/***/ }),

/***/ 7661:
/***/ ((module) => {

const page = {
  id: 4,
  name: 'contact-us',
  is_visible: true,
  sort_order: 41,
  body: `<main class="page">
    <div class="contact-bannerouter">
        <a href="/customer-service.html"
           class="error-banner-img"
           title="error">
            <img class="lazyload"
                 data-sizes="auto"
                 src="https://cdn11.bigcommerce.com/s-hmhnh4h9/product_images/uploaded_images/customer-service-page-a02.png?t=1594200558&_ga=2.196486053.882085373.1594111989-2120057080.1585724489"
                 title="faq"
                 alt="error">
        </a>
    </div>
    <div class="container">
        <div class="getintouchouter">
            <h2>Let's Get in Touch</h2>
            <div class="getintouchinner">
                <div class="sendemail">
                    <div class="sendemailimg">
                        <a href="#"
                           class="email-img"
                           title="error">
                            <img class="lazyload firstImg"
                                 data-sizes="auto"
                                 src="https://cdn11.bigcommerce.com/s-hmhnh4h9/product_images/uploaded_images/eailupdateimg.png"
                                 title="error"
                                 alt="error">
                        </a>
                    </div>
                    <div class="sendemail-text">
                        <p>Send us and email</p>
                        <a href="mailto:info@sleekshop.com"
                           title="ContactUs">info@sleekshop.com</a>
                        <span>*Please allow 1 business </br>day for response</span>
                    </div>
                </div>

                <div class="sendemail">
                    <div class="sendemailimg">
                        <a href="#"
                           class="email-img"
                           title="error">
                            <img class="lazyload secondImg"
                                 data-sizes="auto"
                                 src="https://cdn11.bigcommerce.com/s-hmhnh4h9/product_images/uploaded_images/ringupdateimg.png"
                                 title="error"
                                 alt="error">
                        </a>
                    </div>
                    <div class="sendemail-text">
                        <p>Give us a ring</p>
                        <a href="tel:1-800-921-4813">1-800-921-4813</a>
                        <span>*If line is busy, please leave a voicemail.</br>
                            We will call you back :)</span>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="contact-bannerouter">
        <a href="#"
           class="error-banner-img"
           title="error">
            <img class="lazyload"
                 data-sizes="auto"
                 src="https://cdn11.bigcommerce.com/s-hmhnh4h9/product_images/uploaded_images/contactcurbside.png"
                 title="faq"
                 alt="error">
        </a>
    </div>


    <div class="container">
        <main class="page">
            <!--     <h1 class="page-heading">Contact Us</h1> -->


            <div id="contact-us-page"
                 class="page-content page-content--centered">
                <p>
                </p>
                <form data-contact-form
                      class="form ContactFormDiv"
                      action="/"
                      method="post">


                    <input type="hidden"
                           name="page_id"
                           id="page_id"
                           value="4">
                    <div class="form-row form-row--half">
                        <div class="form-field">
                            <!-- <label class="form-label" for="contact_fullname">Full Name</label> -->
                            <input class="form-input conFormInput"
                                   type="text"
                                   id="contact_fullname"
                                   placeholder="FULL NAME"
                                   name="contact_fullname"
                                   value="">
                        </div>

                        <div class="form-field">
                            <!-- <label class="form-label" for="contact_phone">Phone Number</label> -->
                            <input class="form-input conFormInput"
                                   type="text"
                                   id="contact_phone"
                                   placeholder="PHONE"
                                   name="contact_phone"
                                   value="">
                        </div>

                        <div class="form-field">
                            <!-- <label class="form-label" for="contact_email">Email Address -->
                            <small>Required</small>
                            </label>
                            <input class="form-input conFormInput"
                                   type="text"
                                   id="contact_email"
                                   placeholder="EMAIL"
                                   name="contact_email"
                                   value="">
                        </div>

                        <div class="form-field">
                            <!--<label class="form-label" for="contact_orderno">Order Number</label> -->
                            <input class="form-input conFormInput"
                                   type="text"
                                   id="contact_orderno"
                                   placeholder="COMPANY"
                                   name="contact_orderno">
                        </div>


                    </div>

                    <div class="form-row form-row--full">
                        <div class="form-field">
                            <!-- <label class="form-label" for="contact_question">Comments/Questions
                      <small>Required</small>
                  </label> -->
                            <textarea name="contact_question"
                                      id="contact_question"
                                      placeholder="COMMENTS/QUESTIONS*"
                                      rows="5"
                                      cols="50"
                                      class="form-input conFormInput"></textarea>
                        </div>



                        <div class="form-actions">
                            <input class="button button--primary SubmitBtn"
                                   type="submit"
                                   value="Submit Form">
                        </div>
                </form>
            </div>
        </main>


    </div>


    <div id="modal"
         class="modal"
         data-reveal
         data-prevent-quick-search-close>
        <a href="#"
           class="modal-close"
           aria-label="Close"
           role="button">
            <span aria-hidden="true">&#215;</span>
        </a>
        <div class="modal-content"></div>
        <div class="loadingOverlay"></div>
    </div>
</main>`
};
module.exports = page;

/***/ }),

/***/ 9852:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ Pages),
  "getStaticPaths": () => (/* binding */ getStaticPaths),
  "getStaticProps": () => (/* binding */ getStaticProps)
});

// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(9297);
// EXTERNAL MODULE: ./lib/api/commerce.ts + 17 modules
var commerce = __webpack_require__(1862);
// EXTERNAL MODULE: ./components/ui/Text/Text.tsx
var Text = __webpack_require__(2361);
// EXTERNAL MODULE: ./components/common/Layout/Layout.tsx + 36 modules
var Layout = __webpack_require__(6428);
// EXTERNAL MODULE: ./lib/get-slug.ts
var get_slug = __webpack_require__(7619);
;// CONCATENATED MODULE: ./lib/usage-warns.ts
/**
 * The utils here are used to help developers use the example
 */
function missingLocaleInPages() {
  const invalidPaths = [];

  const log = () => {
    if (invalidPaths.length) {
      const single = invalidPaths.length === 1;
      const pages = single ? 'page' : 'pages';
      console.log(`The ${pages} "${invalidPaths.join(', ')}" ${single ? 'does' : 'do'} not include a locale, or the locale is not supported. When using i18n, web pages from
BigCommerce are expected to have a locale or they will be ignored.\n
Please update the ${pages} to include the default locale or make the ${pages} invisible by
unchecking the "Navigation Menu" option in the settings of ${single ? 'the' : 'each'} web page\n`);
    }
  };

  return [invalidPaths, log];
}
// EXTERNAL MODULE: external "next/router"
var router_ = __webpack_require__(6731);
// EXTERNAL MODULE: ./components/common/DummyPages/about_us.js
var about_us = __webpack_require__(1460);
var about_us_default = /*#__PURE__*/__webpack_require__.n(about_us);
// EXTERNAL MODULE: ./components/common/DummyPages/contact_us.js
var contact_us = __webpack_require__(7661);
var contact_us_default = /*#__PURE__*/__webpack_require__.n(contact_us);
// EXTERNAL MODULE: ./components/common/DummyPages/ammonia_vs.js
var ammonia_vs = __webpack_require__(5370);
var ammonia_vs_default = /*#__PURE__*/__webpack_require__.n(ammonia_vs);
;// CONCATENATED MODULE: external "jquery"
const external_jquery_namespaceObject = require("jquery");
var external_jquery_default = /*#__PURE__*/__webpack_require__.n(external_jquery_namespaceObject);
;// CONCATENATED MODULE: ./components/common/Footer/dynamicScript.js


const dynamicScript = () => {
  external_jquery_default()(function () {
    function onScroll(event) {
      var scrollPos = external_jquery_default()(document).scrollTop();
      external_jquery_default()('.sticky-link a').each(function () {
        //alert("test");
        var currLink = external_jquery_default()(this);
        var refElement = external_jquery_default()(currLink.attr('href'));

        if (refElement.position().top <= scrollPos && refElement.position().top + refElement.height() > scrollPos) {
          external_jquery_default()('.sticky-link ul li a').removeClass('active');
          currLink.addClass('active');
        } else {
          currLink.removeClass('active');
        }
      });
    }

    external_jquery_default()(document).on('scroll', onScroll); //smoothscroll

    external_jquery_default()('.sticky-link a[href^="#"]').on('click', function (e) {
      //  e.preventDefault();
      external_jquery_default()(document).off('scroll');
      external_jquery_default()('.sticky-link a').each(function () {
        external_jquery_default()(this).removeClass('active');
      });
      external_jquery_default()(this).addClass('active');
      var target = this.hash,
          menu = target;
      $target = external_jquery_default()(target);
      external_jquery_default()('html, body').stop().animate({
        scrollTop: $target.offset().top - 50
      }, 500, 'swing', function () {
        window.location.hash = target;
        external_jquery_default()(document).on('scroll', onScroll);
      });
    });
  });
};

/* harmony default export */ const Footer_dynamicScript = (dynamicScript);
// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(5282);
;// CONCATENATED MODULE: ./pages/[...pages].tsx












async function getStaticProps({
  preview,
  params,
  locale,
  locales
}) {
  const config = {
    locale,
    locales
  }; // console.log('config ', config, preview, params)

  const pagesPromise = commerce/* default.getAllPages */.Z.getAllPages({
    config,
    preview
  });
  const siteInfoPromise = commerce/* default.getSiteInfo */.Z.getSiteInfo({
    config,
    preview
  });
  const {
    pages
  } = await pagesPromise;
  const {
    categories
  } = await siteInfoPromise;
  const path = params === null || params === void 0 ? void 0 : params.pages.join('/');
  let s1 = `${path}`;
  let p1 = s1.split('/');
  let p2 = p1[p1.length - 1].replace('.html', '');
  const slug = `${p2}`; // const slug1 = `pages/${path}`

  const pageItem = pages.find(p => p.url ? changePath(p.url) === slug : false);
  const data = pageItem && (await commerce/* default.getPage */.Z.getPage({
    variables: {
      id: pageItem.id
    },
    config,
    preview
  }));
  let page = (data === null || data === void 0 ? void 0 : data.page) && (data === null || data === void 0 ? void 0 : data.page.body.length) > 50 && (data === null || data === void 0 ? void 0 : data.page) || slug === 'about-us' && (about_us_default()) || slug === 'contact-us' && (contact_us_default()) || slug === 'ammonia-vs-no-ammonia' && (ammonia_vs_default()); // console.log('slug SleekShop => ', slug, data, path, '\n')

  if (!page) {
    // We throw to make sure this fails at build time as this is never expected to happen
    throw new Error(`Page with slug '${slug}' not found`);
  }

  return {
    props: {
      pages,
      page,
      categories
    },
    revalidate: 60 * 60 // Every hour

  };
}
async function getStaticPaths({
  locales
}) {
  const config = {
    locales
  };
  const {
    pages
  } = await commerce/* default.getAllPages */.Z.getAllPages({
    config
  });
  const [invalidPaths, log] = missingLocaleInPages();
  const paths = pages.map(page => page.url.replace('.html', '')).filter(url => {
    if (!url || !locales) return url; // If there are locales, only include the pages that include one of the available locales

    if (locales.includes((0,get_slug/* default */.Z)(url).split('/')[0])) return url;
    invalidPaths.push(url);
  });
  log();
  return {
    paths,
    fallback: 'blocking'
  };
}
function Pages({
  page
}) {
  const router = (0,router_.useRouter)();
  (0,external_react_.useEffect)(() => {
    Footer_dynamicScript();
  }, []);
  return router.isFallback ? /*#__PURE__*/jsx_runtime_.jsx("h1", {
    children: "Loading..."
  }) // TODO (BC) Add Skeleton Views
  : /*#__PURE__*/jsx_runtime_.jsx("div", {
    className: "py-20",
    children: (page === null || page === void 0 ? void 0 : page.body) && /*#__PURE__*/jsx_runtime_.jsx(Text/* default */.Z, {
      html: page.body
    })
  });
}

function changePath(path) {
  let s1 = path;
  let s2 = s1.split('/');
  let s3 = s2[s2.length - 1].replace('.html', ''); // console.log(s3 + ' - ' + path)

  return s3;
}

Pages.Layout = Layout/* default */.Z;

/***/ }),

/***/ 2937:
/***/ ((module) => {

"use strict";
module.exports = require("@vercel/fetch");

/***/ }),

/***/ 8023:
/***/ ((module) => {

"use strict";
module.exports = require("body-scroll-lock");

/***/ }),

/***/ 4058:
/***/ ((module) => {

"use strict";
module.exports = require("classnames");

/***/ }),

/***/ 506:
/***/ ((module) => {

"use strict";
module.exports = require("email-validator");

/***/ }),

/***/ 2740:
/***/ ((module) => {

"use strict";
module.exports = require("immutability-helper");

/***/ }),

/***/ 6155:
/***/ ((module) => {

"use strict";
module.exports = require("js-cookie");

/***/ }),

/***/ 5371:
/***/ ((module) => {

"use strict";
module.exports = require("lodash.debounce");

/***/ }),

/***/ 1602:
/***/ ((module) => {

"use strict";
module.exports = require("lodash.throttle");

/***/ }),

/***/ 2517:
/***/ ((module) => {

"use strict";
module.exports = require("next-themes");

/***/ }),

/***/ 9325:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/server/denormalize-page-path.js");

/***/ }),

/***/ 822:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/server/image-config.js");

/***/ }),

/***/ 6695:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/head.js");

/***/ }),

/***/ 8300:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/i18n/detect-domain-locale.js");

/***/ }),

/***/ 5378:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/i18n/normalize-locale-path.js");

/***/ }),

/***/ 2307:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/loadable.js");

/***/ }),

/***/ 7162:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/mitt.js");

/***/ }),

/***/ 8773:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router-context.js");

/***/ }),

/***/ 2248:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/get-asset-path-from-route.js");

/***/ }),

/***/ 9372:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/is-dynamic.js");

/***/ }),

/***/ 665:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/parse-relative-url.js");

/***/ }),

/***/ 2747:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/querystring.js");

/***/ }),

/***/ 654:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/resolve-rewrites.js");

/***/ }),

/***/ 333:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/route-matcher.js");

/***/ }),

/***/ 3456:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/route-regex.js");

/***/ }),

/***/ 556:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/to-base-64.js");

/***/ }),

/***/ 7620:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/utils.js");

/***/ }),

/***/ 6731:
/***/ ((module) => {

"use strict";
module.exports = require("next/router");

/***/ }),

/***/ 8689:
/***/ ((module) => {

"use strict";
module.exports = require("next/script");

/***/ }),

/***/ 9297:
/***/ ((module) => {

"use strict";
module.exports = require("react");

/***/ }),

/***/ 123:
/***/ ((module) => {

"use strict";
module.exports = require("react-merge-refs");

/***/ }),

/***/ 5282:
/***/ ((module) => {

"use strict";
module.exports = require("react/jsx-runtime");

/***/ }),

/***/ 7749:
/***/ ((module) => {

"use strict";
module.exports = require("swr");

/***/ }),

/***/ 8047:
/***/ ((module) => {

"use strict";
module.exports = require("tabbable");

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [157,370,862,79,428], () => (__webpack_exec__(9852)));
module.exports = __webpack_exports__;

})();