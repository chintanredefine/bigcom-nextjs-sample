(() => {
var exports = {};
exports.id = 993;
exports.ids = [993];
exports.modules = {

/***/ 5366:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ Home),
  "getStaticProps": () => (/* binding */ getStaticProps)
});

// EXTERNAL MODULE: ./lib/api/commerce.ts + 17 modules
var commerce = __webpack_require__(1862);
// EXTERNAL MODULE: ./components/common/Layout/Layout.tsx + 36 modules
var Layout = __webpack_require__(6428);
// EXTERNAL MODULE: ./components/product/ProductCard/ProductCard.tsx + 1 modules
var ProductCard = __webpack_require__(353);
// EXTERNAL MODULE: external "classnames"
var external_classnames_ = __webpack_require__(4058);
var external_classnames_default = /*#__PURE__*/__webpack_require__.n(external_classnames_);
// EXTERNAL MODULE: ./components/ui/Grid/Grid.module.css
var Grid_module = __webpack_require__(5246);
var Grid_module_default = /*#__PURE__*/__webpack_require__.n(Grid_module);
// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(5282);
;// CONCATENATED MODULE: ./components/ui/Grid/Grid.tsx




const Grid = ({
  className,
  layout = 'A',
  children,
  variant = 'default'
}) => {
  const rootClassName = external_classnames_default()((Grid_module_default()).root, {
    [(Grid_module_default()).layoutA]: layout === 'A',
    [(Grid_module_default()).layoutB]: layout === 'B',
    [(Grid_module_default()).layoutC]: layout === 'C',
    [(Grid_module_default()).layoutD]: layout === 'D',
    [(Grid_module_default()).layoutNormal]: layout === 'normal',
    [(Grid_module_default()).default]: variant === 'default',
    [(Grid_module_default()).filled]: variant === 'filled'
  }, className);
  return /*#__PURE__*/jsx_runtime_.jsx("div", {
    className: rootClassName,
    children: children
  });
};

/* harmony default export */ const Grid_Grid = (Grid);
// EXTERNAL MODULE: ./components/ui/Marquee/Marquee.module.css
var Marquee_module = __webpack_require__(7896);
var Marquee_module_default = /*#__PURE__*/__webpack_require__.n(Marquee_module);
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(9297);
;// CONCATENATED MODULE: external "react-fast-marquee"
const external_react_fast_marquee_namespaceObject = require("react-fast-marquee");
var external_react_fast_marquee_default = /*#__PURE__*/__webpack_require__.n(external_react_fast_marquee_namespaceObject);
;// CONCATENATED MODULE: ./components/ui/Marquee/Marquee.tsx
function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) { symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); } keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }







const Marquee = ({
  className = '',
  children,
  variant = 'primary'
}) => {
  const rootClassName = external_classnames_default()((Marquee_module_default()).root, {
    [(Marquee_module_default()).primary]: variant === 'primary',
    [(Marquee_module_default()).secondary]: variant === 'secondary'
  }, className);
  return /*#__PURE__*/jsx_runtime_.jsx((external_react_fast_marquee_default()), {
    gradient: false,
    className: rootClassName,
    children: external_react_.Children.map(children, child => _objectSpread(_objectSpread({}, child), {}, {
      props: _objectSpread(_objectSpread({}, child.props), {}, {
        className: external_classnames_default()(child.props.className, `${variant}`)
      })
    }))
  });
};

/* harmony default export */ const Marquee_Marquee = (Marquee);
// EXTERNAL MODULE: ./components/ui/Container/Container.tsx
var Container = __webpack_require__(9698);
// EXTERNAL MODULE: ./components/icons/ArrowRight.tsx + 1 modules
var ArrowRight = __webpack_require__(1742);
// EXTERNAL MODULE: ./components/ui/Hero/Hero.module.css
var Hero_module = __webpack_require__(2338);
var Hero_module_default = /*#__PURE__*/__webpack_require__.n(Hero_module);
// EXTERNAL MODULE: ./node_modules/next/link.js
var next_link = __webpack_require__(1664);
;// CONCATENATED MODULE: ./components/ui/Hero/Hero.tsx








const Hero = ({
  headline,
  description
}) => {
  return /*#__PURE__*/jsx_runtime_.jsx("div", {
    className: "bg-accent-9 border-b border-t border-accent-2",
    children: /*#__PURE__*/jsx_runtime_.jsx(Container/* default */.Z, {
      children: /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
        className: (Hero_module_default()).root,
        children: [/*#__PURE__*/jsx_runtime_.jsx("h2", {
          className: (Hero_module_default()).title,
          children: headline
        }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
          className: (Hero_module_default()).description,
          children: [/*#__PURE__*/jsx_runtime_.jsx("p", {
            children: description
          }), /*#__PURE__*/jsx_runtime_.jsx(next_link.default, {
            href: "/",
            children: /*#__PURE__*/(0,jsx_runtime_.jsxs)("a", {
              className: "flex items-center text-accent-0 pt-3 font-bold hover:underline cursor-pointer w-max-content",
              children: ["Read it here", /*#__PURE__*/jsx_runtime_.jsx(ArrowRight/* default */.Z, {
                width: "20",
                heigh: "20",
                className: "ml-1"
              })]
            })
          })]
        })]
      })
    })
  });
};

/* harmony default export */ const Hero_Hero = (Hero);
;// CONCATENATED MODULE: ./pages/index-old.tsx
function index_old_ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) { symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); } keys.push.apply(keys, symbols); } return keys; }

function index_old_objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { index_old_ownKeys(Object(source), true).forEach(function (key) { index_old_defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { index_old_ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function index_old_defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }




 // import HomeAllProductsGrid from '@components/common/HomeAllProductsGrid'




async function getStaticProps({
  preview,
  locale,
  locales
}) {
  const config = {
    locale,
    locales
  };
  const productsPromise = commerce/* default.getAllProducts */.Z.getAllProducts(index_old_objectSpread({
    variables: {
      first: 20
    },
    config,
    preview
  }, {
    featured: true
  }));
  const pagesPromise = commerce/* default.getAllPages */.Z.getAllPages({
    config,
    preview
  });
  const siteInfoPromise = commerce/* default.getSiteInfo */.Z.getSiteInfo({
    config,
    preview
  });
  const {
    products
  } = await productsPromise;
  const {
    pages
  } = await pagesPromise;
  const {
    categories,
    brands
  } = await siteInfoPromise;
  return {
    props: {
      products,
      categories,
      brands,
      pages
    },
    revalidate: 60
  };
}
function Home({
  products
}) {
  return /*#__PURE__*/(0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
    children: [/*#__PURE__*/jsx_runtime_.jsx(Grid_Grid, {
      variant: "filled",
      children: products.slice(0, 10).map((product, i) => /*#__PURE__*/jsx_runtime_.jsx(ProductCard/* default */.Z, {
        product: product,
        imgProps: {
          width: i === 0 ? 1080 : 540,
          height: i === 0 ? 1080 : 540
        }
      }, product.id))
    }), /*#__PURE__*/jsx_runtime_.jsx(Marquee_Marquee, {
      variant: "secondary",
      children: products.slice(11, 20).map((product, i) => /*#__PURE__*/jsx_runtime_.jsx(ProductCard/* default */.Z, {
        product: product,
        variant: "slim"
      }, product.id))
    }), /*#__PURE__*/jsx_runtime_.jsx(Hero_Hero, {
      headline: "Headline Here",
      description: "This is the details section under main headline section. You can add the text over here. Souffl\xE9 bonbon caramels jelly beans."
    }), /*#__PURE__*/jsx_runtime_.jsx(Grid_Grid, {
      layout: "B",
      variant: "filled",
      children: products.slice(0, 3).map((product, i) => /*#__PURE__*/jsx_runtime_.jsx(ProductCard/* default */.Z, {
        product: product,
        imgProps: {
          width: i === 0 ? 1080 : 540,
          height: i === 0 ? 1080 : 540
        }
      }, product.id))
    }), /*#__PURE__*/jsx_runtime_.jsx(Marquee_Marquee, {
      children: products.slice(5).map((product, i) => /*#__PURE__*/jsx_runtime_.jsx(ProductCard/* default */.Z, {
        product: product,
        variant: "slim"
      }, product.id))
    })]
  });
}
Home.Layout = Layout/* default */.Z;

/***/ }),

/***/ 5246:
/***/ ((module) => {

// Exports
module.exports = {
	"root": "Grid_root__2GDws",
	"default": "Grid_default__1XpxR",
	"layoutNormal": "Grid_layoutNormal__1sG6i",
	"layoutA": "Grid_layoutA__2eEzQ",
	"filled": "Grid_filled__2x5Xm",
	"layoutB": "Grid_layoutB__Y_1PI",
	"layoutC": "Grid_layoutC__KQkhG",
	"layoutD": "Grid_layoutD__1H1uq"
};


/***/ }),

/***/ 2338:
/***/ ((module) => {

// Exports
module.exports = {
	"root": "Hero_root__2AaFC",
	"title": "Hero_title__3bHA2",
	"description": "Hero_description__3WfaD"
};


/***/ }),

/***/ 7896:
/***/ ((module) => {

// Exports
module.exports = {
	"root": "Marquee_root__1YWF9",
	"primary": "Marquee_primary__3-opW",
	"secondary": "Marquee_secondary__1u8Gk"
};


/***/ }),

/***/ 2937:
/***/ ((module) => {

"use strict";
module.exports = require("@vercel/fetch");

/***/ }),

/***/ 8023:
/***/ ((module) => {

"use strict";
module.exports = require("body-scroll-lock");

/***/ }),

/***/ 4058:
/***/ ((module) => {

"use strict";
module.exports = require("classnames");

/***/ }),

/***/ 506:
/***/ ((module) => {

"use strict";
module.exports = require("email-validator");

/***/ }),

/***/ 2740:
/***/ ((module) => {

"use strict";
module.exports = require("immutability-helper");

/***/ }),

/***/ 6155:
/***/ ((module) => {

"use strict";
module.exports = require("js-cookie");

/***/ }),

/***/ 5371:
/***/ ((module) => {

"use strict";
module.exports = require("lodash.debounce");

/***/ }),

/***/ 1602:
/***/ ((module) => {

"use strict";
module.exports = require("lodash.throttle");

/***/ }),

/***/ 2517:
/***/ ((module) => {

"use strict";
module.exports = require("next-themes");

/***/ }),

/***/ 9325:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/server/denormalize-page-path.js");

/***/ }),

/***/ 822:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/server/image-config.js");

/***/ }),

/***/ 6695:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/head.js");

/***/ }),

/***/ 8300:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/i18n/detect-domain-locale.js");

/***/ }),

/***/ 5378:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/i18n/normalize-locale-path.js");

/***/ }),

/***/ 2307:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/loadable.js");

/***/ }),

/***/ 7162:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/mitt.js");

/***/ }),

/***/ 8773:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router-context.js");

/***/ }),

/***/ 2248:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/get-asset-path-from-route.js");

/***/ }),

/***/ 9372:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/is-dynamic.js");

/***/ }),

/***/ 665:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/parse-relative-url.js");

/***/ }),

/***/ 2747:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/querystring.js");

/***/ }),

/***/ 654:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/resolve-rewrites.js");

/***/ }),

/***/ 333:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/route-matcher.js");

/***/ }),

/***/ 3456:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/route-regex.js");

/***/ }),

/***/ 556:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/to-base-64.js");

/***/ }),

/***/ 7620:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/utils.js");

/***/ }),

/***/ 6731:
/***/ ((module) => {

"use strict";
module.exports = require("next/router");

/***/ }),

/***/ 8689:
/***/ ((module) => {

"use strict";
module.exports = require("next/script");

/***/ }),

/***/ 9297:
/***/ ((module) => {

"use strict";
module.exports = require("react");

/***/ }),

/***/ 123:
/***/ ((module) => {

"use strict";
module.exports = require("react-merge-refs");

/***/ }),

/***/ 5282:
/***/ ((module) => {

"use strict";
module.exports = require("react/jsx-runtime");

/***/ }),

/***/ 7749:
/***/ ((module) => {

"use strict";
module.exports = require("swr");

/***/ }),

/***/ 8047:
/***/ ((module) => {

"use strict";
module.exports = require("tabbable");

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [157,370,862,79,428,909,644,353,742], () => (__webpack_exec__(5366)));
module.exports = __webpack_exports__;

})();