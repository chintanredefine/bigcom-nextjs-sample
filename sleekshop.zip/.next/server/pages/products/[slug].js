(() => {
var exports = {};
exports.id = 905;
exports.ids = [905];
exports.modules = {

/***/ 3010:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ Slug),
  "getStaticPaths": () => (/* binding */ getStaticPaths),
  "getStaticProps": () => (/* binding */ getStaticProps)
});

// EXTERNAL MODULE: external "next/router"
var router_ = __webpack_require__(6731);
// EXTERNAL MODULE: ./lib/api/commerce.ts + 17 modules
var commerce = __webpack_require__(1862);
// EXTERNAL MODULE: ./components/common/Layout/Layout.tsx + 36 modules
var Layout = __webpack_require__(6428);
// EXTERNAL MODULE: external "classnames"
var external_classnames_ = __webpack_require__(4058);
var external_classnames_default = /*#__PURE__*/__webpack_require__.n(external_classnames_);
// EXTERNAL MODULE: ./node_modules/next/image.js
var next_image = __webpack_require__(5675);
// EXTERNAL MODULE: external "next-seo"
var external_next_seo_ = __webpack_require__(2364);
// EXTERNAL MODULE: ./components/product/ProductView/ProductView.module.css
var ProductView_module = __webpack_require__(6734);
var ProductView_module_default = /*#__PURE__*/__webpack_require__.n(ProductView_module);
// EXTERNAL MODULE: ./framework/commerce/product/use-price.tsx
var use_price = __webpack_require__(5420);
// EXTERNAL MODULE: ./components/product/ProductSlider/ProductSlider.tsx + 3 modules
var ProductSlider = __webpack_require__(7052);
// EXTERNAL MODULE: ./components/ui/Container/Container.tsx
var Container = __webpack_require__(9698);
// EXTERNAL MODULE: ./components/ui/Text/Text.tsx
var Text = __webpack_require__(2361);
// EXTERNAL MODULE: ./components/product/ProductSidebar/ProductSidebar.module.css
var ProductSidebar_module = __webpack_require__(284);
var ProductSidebar_module_default = /*#__PURE__*/__webpack_require__.n(ProductSidebar_module);
// EXTERNAL MODULE: ./framework/bigcommerce/cart/use-add-item.tsx + 1 modules
var use_add_item = __webpack_require__(3889);
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(9297);
var external_react_default = /*#__PURE__*/__webpack_require__.n(external_react_);
// EXTERNAL MODULE: ./components/product/Swatch/Swatch.module.css
var Swatch_module = __webpack_require__(2890);
var Swatch_module_default = /*#__PURE__*/__webpack_require__.n(Swatch_module);
// EXTERNAL MODULE: ./components/icons/Check.tsx + 1 modules
var Check = __webpack_require__(6245);
// EXTERNAL MODULE: ./components/ui/Button/Button.tsx
var Button = __webpack_require__(1180);
;// CONCATENATED MODULE: external "lodash.random"
const external_lodash_random_namespaceObject = require("lodash.random");
;// CONCATENATED MODULE: ./lib/colors.ts

function getRandomPairOfColors() {
  const colors = ['#37B679', '#DA3C3C', '#3291FF', '#7928CA', '#79FFE1'];

  const getRandomIdx = () => random(0, colors.length - 1);

  let idx = getRandomIdx();
  let idx2 = getRandomIdx(); // Has to be a different color

  while (idx2 === idx) {
    idx2 = getRandomIdx();
  } // Returns a pair of colors


  return [colors[idx], colors[idx2]];
}

function hexToRgb(hex = '') {
  // @ts-ignore
  const match = hex.toString(16).match(/[a-f0-9]{6}|[a-f0-9]{3}/i);

  if (!match) {
    return [0, 0, 0];
  }

  let colorString = match[0];

  if (match[0].length === 3) {
    colorString = colorString.split('').map(char => {
      return char + char;
    }).join('');
  }

  const integer = parseInt(colorString, 16);
  const r = integer >> 16 & 0xff;
  const g = integer >> 8 & 0xff;
  const b = integer & 0xff;
  return [r, g, b];
}

const colorMap = {
  aliceblue: '#F0F8FF',
  antiquewhite: '#FAEBD7',
  aqua: '#00FFFF',
  aquamarine: '#7FFFD4',
  azure: '#F0FFFF',
  beige: '#F5F5DC',
  bisque: '#FFE4C4',
  black: '#000000',
  blanchedalmond: '#FFEBCD',
  blue: '#0000FF',
  blueviolet: '#8A2BE2',
  brown: '#A52A2A',
  burlywood: '#DEB887',
  burgandy: '#800020',
  burgundy: '#800020',
  cadetblue: '#5F9EA0',
  chartreuse: '#7FFF00',
  chocolate: '#D2691E',
  coral: '#FF7F50',
  cornflowerblue: '#6495ED',
  cornsilk: '#FFF8DC',
  crimson: '#DC143C',
  cyan: '#00FFFF',
  darkblue: '#00008B',
  darkcyan: '#008B8B',
  darkgoldenrod: '#B8860B',
  darkgray: '#A9A9A9',
  darkgreen: '#006400',
  darkgrey: '#A9A9A9',
  darkkhaki: '#BDB76B',
  darkmagenta: '#8B008B',
  darkolivegreen: '#556B2F',
  darkorange: '#FF8C00',
  darkorchid: '#9932CC',
  darkred: '#8B0000',
  darksalmon: '#E9967A',
  darkseagreen: '#8FBC8F',
  darkslateblue: '#483D8B',
  darkslategray: '#2F4F4F',
  darkslategrey: '#2F4F4F',
  darkturquoise: '#00CED1',
  darkviolet: '#9400D3',
  deeppink: '#FF1493',
  deepskyblue: '#00BFFF',
  dimgray: '#696969',
  dimgrey: '#696969',
  dodgerblue: '#1E90FF',
  firebrick: '#B22222',
  floralwhite: '#FFFAF0',
  forestgreen: '#228B22',
  fuchsia: '#FF00FF',
  gainsboro: '#DCDCDC',
  ghostwhite: '#F8F8FF',
  gold: '#FFD700',
  goldenrod: '#DAA520',
  gray: '#808080',
  green: '#008000',
  greenyellow: '#ADFF2F',
  grey: '#808080',
  honeydew: '#F0FFF0',
  hotpink: '#FF69B4',
  indianred: '#CD5C5C',
  indigo: '#4B0082',
  ivory: '#FFFFF0',
  khaki: '#F0E68C',
  lavender: '#E6E6FA',
  lavenderblush: '#FFF0F5',
  lawngreen: '#7CFC00',
  lemonchiffon: '#FFFACD',
  lightblue: '#ADD8E6',
  lightcoral: '#F08080',
  lightcyan: '#E0FFFF',
  lightgoldenrodyellow: '#FAFAD2',
  lightgray: '#D3D3D3',
  lightgreen: '#90EE90',
  lightgrey: '#D3D3D3',
  lightpink: '#FFB6C1',
  lightsalmon: '#FFA07A',
  lightseagreen: '#20B2AA',
  lightskyblue: '#87CEFA',
  lightslategray: '#778899',
  lightslategrey: '#778899',
  lightsteelblue: '#B0C4DE',
  lightyellow: '#FFFFE0',
  lime: '#00FF00',
  limegreen: '#32CD32',
  linen: '#FAF0E6',
  magenta: '#FF00FF',
  maroon: '#800000',
  mediumaquamarine: '#66CDAA',
  mediumblue: '#0000CD',
  mediumorchid: '#BA55D3',
  mediumpurple: '#9370DB',
  mediumseagreen: '#3CB371',
  mediumslateblue: '#7B68EE',
  mediumspringgreen: '#00FA9A',
  mediumturquoise: '#48D1CC',
  mediumvioletred: '#C71585',
  midnightblue: '#191970',
  mintcream: '#F5FFFA',
  mistyrose: '#FFE4E1',
  moccasin: '#FFE4B5',
  navajowhite: '#FFDEAD',
  navy: '#000080',
  oldlace: '#FDF5E6',
  olive: '#808000',
  olivedrab: '#6B8E23',
  orange: '#FFA500',
  orangered: '#FF4500',
  orchid: '#DA70D6',
  palegoldenrod: '#EEE8AA',
  palegreen: '#98FB98',
  paleturquoise: '#AFEEEE',
  palevioletred: '#DB7093',
  papayawhip: '#FFEFD5',
  peachpuff: '#FFDAB9',
  peru: '#CD853F',
  pink: '#FFC0CB',
  plum: '#DDA0DD',
  powderblue: '#B0E0E6',
  purple: '#800080',
  rebeccapurple: '#663399',
  red: '#FF0000',
  rosybrown: '#BC8F8F',
  royalblue: '#4169E1',
  saddlebrown: '#8B4513',
  salmon: '#FA8072',
  sandybrown: '#F4A460',
  seagreen: '#2E8B57',
  seashell: '#FFF5EE',
  sienna: '#A0522D',
  silver: '#C0C0C0',
  skyblue: '#87CEEB',
  slateblue: '#6A5ACD',
  slategray: '#708090',
  slategrey: '#708090',
  spacegrey: '#65737e',
  spacegray: '#65737e',
  snow: '#FFFAFA',
  springgreen: '#00FF7F',
  steelblue: '#4682B4',
  tan: '#D2B48C',
  teal: '#008080',
  thistle: '#D8BFD8',
  tomato: '#FF6347',
  turquoise: '#40E0D0',
  violet: '#EE82EE',
  wheat: '#F5DEB3',
  white: '#FFFFFF',
  whitesmoke: '#F5F5F5',
  yellow: '#FFFF00',
  yellowgreen: '#9ACD32'
};
function isDark(color = '') {
  color = color.toLowerCase(); // Equation from http://24ways.org/2010/calculating-color-contrast

  let rgb = colorMap[color] ? hexToRgb(colorMap[color]) : hexToRgb(color);
  const res = (rgb[0] * 299 + rgb[1] * 587 + rgb[2] * 114) / 1000;
  return res < 128;
}
// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(5282);
;// CONCATENATED MODULE: ./components/product/Swatch/Swatch.tsx
const _excluded = ["active", "className", "color", "image", "label", "variant", "id"];

function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) { symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); } keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

function _objectWithoutProperties(source, excluded) { if (source == null) return {}; var target = _objectWithoutPropertiesLoose(source, excluded); var key, i; if (Object.getOwnPropertySymbols) { var sourceSymbolKeys = Object.getOwnPropertySymbols(source); for (i = 0; i < sourceSymbolKeys.length; i++) { key = sourceSymbolKeys[i]; if (excluded.indexOf(key) >= 0) continue; if (!Object.prototype.propertyIsEnumerable.call(source, key)) continue; target[key] = source[key]; } } return target; }

function _objectWithoutPropertiesLoose(source, excluded) { if (source == null) return {}; var target = {}; var sourceKeys = Object.keys(source); var key, i; for (i = 0; i < sourceKeys.length; i++) { key = sourceKeys[i]; if (excluded.indexOf(key) >= 0) continue; target[key] = source[key]; } return target; }









const Swatch = /*#__PURE__*/external_react_default().memo(_ref => {
  var _variant;

  let {
    active,
    className,
    color = '',
    image = '',
    label = null,
    variant = 'size',
    id = 0
  } = _ref,
      props = _objectWithoutProperties(_ref, _excluded);

  variant = (_variant = variant) === null || _variant === void 0 ? void 0 : _variant.toLowerCase();

  if (label) {
    var _label;

    label = (_label = label) === null || _label === void 0 ? void 0 : _label.toLowerCase();
  }

  const swatchClassName = external_classnames_default()((Swatch_module_default()).swatch, {
    [(Swatch_module_default()).color]: color,
    [(Swatch_module_default()).active]: active,
    [(Swatch_module_default()).size]: variant === 'size',
    [(Swatch_module_default()).dark]: color ? isDark(color) : false,
    [(Swatch_module_default()).textLabel]: !color && label && label.length > 3
  }, className);
  return /*#__PURE__*/(0,jsx_runtime_.jsxs)(Button/* default */.Z, _objectSpread(_objectSpread(_objectSpread({
    "aria-label": "Variant Swatch",
    className: swatchClassName
  }, label && color && {
    title: label
  }), {}, {
    style: image ? {
      backgroundImage: `url(${image})`
    } : {}
  }, props), {}, {
    children: [color && active && /*#__PURE__*/jsx_runtime_.jsx("span", {
      children: /*#__PURE__*/jsx_runtime_.jsx(Check/* default */.Z, {})
    }), /*#__PURE__*/jsx_runtime_.jsx("div", {
      className: "variant_label",
      children: !color ? label : null
    }), id > 0 ? /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
      className: "variant_qty",
      children: ["QTY.", id, ' ', /*#__PURE__*/jsx_runtime_.jsx(Check/* default */.Z, {
        className: "inline-block check_icn",
        fontSize: "small"
      })]
    }) : '']
  }));
});
/* harmony default export */ const Swatch_Swatch = (Swatch);
;// CONCATENATED MODULE: external "next/config"
const config_namespaceObject = require("next/config");
var config_default = /*#__PURE__*/__webpack_require__.n(config_namespaceObject);
// EXTERNAL MODULE: ./components/icons/Cross.tsx
var Cross = __webpack_require__(4246);
// EXTERNAL MODULE: ./components/wishlist/WishlistButton/WishlistButton.tsx
var WishlistButton = __webpack_require__(1644);
// EXTERNAL MODULE: ./framework/bigcommerce/cart/use-cart.tsx + 1 modules
var use_cart = __webpack_require__(3958);
;// CONCATENATED MODULE: ./components/product/ProductOptions/ProductOptions.tsx












const {
  publicRuntimeConfig
} = config_default()();
const ProductOptions = /*#__PURE__*/external_react_default().memo(({
  options,
  selectedOptions,
  setSelectedOptions,
  product,
  variants,
  currentVariant,
  skuChange
}) => {
  const {
    data
  } = (0,use_cart/* default */.Z)();
  const cartItems = data ? data.lineItems : [];
  let items = [];

  for (const item of cartItems) {
    items[item.variantId] = item.quantity;
  }

  const addItem = (0,use_add_item/* default */.Z)();
  const {
    0: loading,
    1: setLoading
  } = (0,external_react_.useState)(false);

  const addToCart = async (element, inputSearch, varientQty) => {
    inputSearch = document.getElementById('selected_variant');
    element = document.getElementById('option_cart_btn');
    element.classList.add('cart-checked');
    varientQty = document.getElementById('varient_qty');
    var cartQty = varientQty.value;
    let variant_id = inputSearch.value;
    setLoading(true);

    try {
      await addItem({
        quantity: Number(cartQty),
        productId: String(product.id),
        variantId: String(variant_id ? variant_id : product.variants[0].id)
      });
      setLoading(false);
    } catch (err) {
      setLoading(false);
    }
  };

  const customclass = 'color-swatch';

  function loadOptions(va) {
    let sku = va.sku.toLowerCase();
    skuChange(sku);
  }

  function handleSearch(input, ul, li) {
    var filter, a, i, txtValue;
    input = document.getElementById('shade_search');
    filter = input.value.toUpperCase();
    ul = document.getElementById('alloptions');

    if (filter) {
      ul.classList.add('search_start');
    } else {
      ul.classList.remove('search_start');
    }

    li = ul.getElementsByTagName('button');

    for (i = 0; i < li.length; i++) {
      a = li[i].getElementsByTagName('div')[0];
      txtValue = a.textContent || a.innerText;

      if (txtValue.toUpperCase().indexOf(filter) > -1) {
        li[i].style.display = '';
        li[i].classList.add('filter_result');
      } else {
        li[i].style.display = 'none';
        li[i].classList.remove('filter_result');
      }
    }
  }

  function handleSearchModal(input, ul, li, f, ftype) {
    var filter, a, i, txtValue;
    input = document.getElementById('shade_search_modal');
    filter = input.value.toUpperCase();
    ul = document.getElementById('alloptions_modal');

    if (filter) {
      ul.classList.add('search_start');
    } else {
      ul.classList.remove('search_start');
    }

    f = document.getElementById('filter_type');
    ftype = f.value;

    if (ftype == 'instock') {
      li = ul.getElementsByClassName('color_enabled');
    } else {
      li = ul.getElementsByClassName('color_disabled');
    }

    for (i = 0; i < li.length; i++) {
      a = li[i].getElementsByTagName('div')[0];
      txtValue = a.textContent || a.innerText;

      if (txtValue.toUpperCase().indexOf(filter) > -1) {
        li[i].style.display = '';
        li[i].classList.add('filter_result');
      } else {
        li[i].style.display = 'none';
        li[i].classList.remove('filter_result');
      }
    }
  }

  function filterInStockOptions(element, stockEvent, ul, li, f) {
    var i;
    stockEvent = document.getElementById('out_of_stock_filter');
    stockEvent.classList.remove('active');
    element = document.getElementById('in_stock_filter');
    element.classList.add('active');
    f = document.getElementById('filter_type');
    f.value = 'instock';
    ul = document.getElementById('alloptions_modal');
    li = ul.getElementsByTagName('button');

    for (i = 0; i < li.length; i++) {
      var isDisabled = li[i].classList.contains('color_disabled');

      if (!isDisabled) {
        li[i].style.display = '';
      } else {
        li[i].style.display = 'none';
      }
    }
  }

  function filterOutOfStockOptions(element, stockEvent, ul, li, f) {
    var i;
    stockEvent = document.getElementById('in_stock_filter');
    stockEvent.classList.remove('active');
    element = document.getElementById('out_of_stock_filter');
    element.classList.add('active');
    f = document.getElementById('filter_type');
    f.value = 'outofstock';
    ul = document.getElementById('alloptions_modal');
    li = ul.getElementsByTagName('button');

    for (i = 0; i < li.length; i++) {
      var isDisabled = li[i].classList.contains('color_disabled');

      if (isDisabled) {
        li[i].style.display = '';
      } else {
        li[i].style.display = 'none';
      }
    }
  }

  function viewMoreShow(element, x) {
    x = document.getElementById('all_options_list');
    x.style.display = 'block';
    element = document.getElementById('modal_overlay');
    element.style.display = 'block';
    filterInStockOptions(element, null, null, null, null);
  }

  function viewLessShow(element, x, y) {
    element = document.getElementById('alloptions');
    element.classList.remove('show_all_options');
    x = document.getElementById('view_more');
    x.style.display = 'block';
    y = document.getElementById('view_less');
    y.style.display = 'none';
  }

  function changeToList(element) {
    element = document.getElementById('options_list');
    element.classList.remove('grid');
    element.classList.add('list');
  }

  function changeToGid(element) {
    element = document.getElementById('options_list');
    element.classList.remove('list');
    element.classList.add('grid');
  }

  function changeToListModal(element, x, y) {
    element = document.getElementById('all_options_list');
    element.classList.remove('grid');
    element.classList.add('list');
    x = document.getElementById('modal_grid_btn');
    x.classList.remove('active');
    y = document.getElementById('modal_list_btn');
    y.classList.add('active');
  }

  function changeToGridModal(element, x, y) {
    element = document.getElementById('all_options_list');
    element.classList.remove('list');
    element.classList.add('grid');
    x = document.getElementById('modal_grid_btn');
    x.classList.add('active');
    y = document.getElementById('modal_list_btn');
    y.classList.remove('active');
  }

  function modalClose(element, x, y, z) {
    element = document.getElementById('all_options_list');
    element.style.display = 'none';
    element.classList.remove('modal_option_fix');
    x = document.getElementById('modal_overlay');
    x.style.display = 'none';
    y = document.getElementById('selected_color_options');
    y.style.display = 'none';
    z = document.getElementById('disabled_color_options');
    z.style.display = 'none';
  }

  function pickColor(va, x, y, cimg, element, z, inputSearch, catbtn) {
    let sku = va.sku.toLowerCase();
    let colorTitle = va.option_values ? va.option_values[0].label : '';
    inputSearch = document.getElementById('selected_variant');
    inputSearch.value = va.id;
    catbtn = document.getElementById('option_cart_btn');
    catbtn.classList.remove('cart-checked');
    z = document.getElementById('all_options_list');
    z.classList.add('modal_option_fix');
    let cid = va.option_values ? va.option_values[0].id : '';
    let colorimg = va.image_url;

    if (va.inventory_level > 0) {
      x = document.getElementById('selected_color_title');
      x.innerText = colorTitle;
      y = document.getElementById('selected_color_sku');
      y.innerText = 'SKU: ' + sku;
      cimg = document.getElementById('selected_color_img');
      cimg.src = colorimg;
      element = document.getElementById('selected_color_options');
      element.style.display = 'block';
    } else {
      x = document.getElementById('disabled_color_title');
      x.innerText = colorTitle;
      cimg = document.getElementById('disabled_color_img');
      cimg.src = colorimg;
      element = document.getElementById('disabled_color_options');
      element.style.display = 'block';
    }
  }

  var minVal = 1,
      maxVal = 20; // Set Max and Min values

  function increaseQty(element) {
    element = document.getElementById('varient_qty');
    var qtyVal = element.value;

    if (qtyVal < maxVal) {
      qtyVal++;
    }

    element.value = qtyVal;
  }

  function decreaseQty(element) {
    element = document.getElementById('varient_qty');
    var qtyVal = element.value;

    if (qtyVal > 1) {
      qtyVal--;
    }

    element.value = qtyVal;
  }

  const totalVariants = variants.data ? variants.data.length : 0;
  return /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
    className: "product-options",
    children: [/*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
      className: "pb-6 grid",
      id: "options_list",
      children: [/*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
        className: "flex justify-between",
        children: [/*#__PURE__*/(0,jsx_runtime_.jsxs)("h2", {
          className: "uppercase font-medium text-sm tracking-wide",
          children: ["Color", /*#__PURE__*/jsx_runtime_.jsx("span", {
            className: "option-title",
            children: currentVariant.option_values ? currentVariant.option_values[0].label : ''
          })]
        }), /*#__PURE__*/jsx_runtime_.jsx("span", {
          id: "shade_search_block",
          children: /*#__PURE__*/jsx_runtime_.jsx("input", {
            type: "text",
            id: "shade_search",
            placeholder: "Shade Search",
            onKeyUp: event => {
              handleSearch(event, null, null);
            }
          })
        }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
          className: "mobile_options",
          children: [/*#__PURE__*/jsx_runtime_.jsx("span", {
            className: "grid_btn",
            onClick: event => {
              changeToGid(event);
            },
            children: "Grid"
          }), /*#__PURE__*/jsx_runtime_.jsx("span", {
            className: "seperator",
            children: "/"
          }), /*#__PURE__*/jsx_runtime_.jsx("span", {
            className: "list_btn",
            onClick: event => {
              changeToList(event);
            },
            children: "List"
          })]
        })]
      }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
        className: "option-section",
        children: [/*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
          id: "alloptions",
          className: "flex_div flex justify-between flex-wrap flex-row py-4",
          children: [/*#__PURE__*/jsx_runtime_.jsx("input", {
            id: "selected_variant",
            type: "hidden",
            value: currentVariant.id
          }), variants.data.map((v, i) => {
            let pUrl = product.path.replace('.html', '');
            const opt = v.option_values[0];
            const active = selectedOptions[opt.option_display_name.toLowerCase()];
            const swatch = publicRuntimeConfig.COLOR_SWATCH_URL + '/product_images/attribute_value_images/' + opt.id + '.preview.jpg';
            const isDisabled = v.inventory_level == 0 ? ' color_disabled' : ' color_enabled';
            const itemQty = items ? items[v.id] : 0;
            return /*#__PURE__*/jsx_runtime_.jsx(Swatch_Swatch, {
              active: currentVariant.sku == v.sku,
              variant: opt.option_display_name,
              color: v.hexColors ? v.hexColors[0] : '',
              image: swatch ? swatch : '',
              label: opt.label,
              id: itemQty,
              className: customclass + isDisabled,
              onClick: event => {
                loadOptions(v);
              }
            }, `${opt.id}-${i}`);
          }), totalVariants > 17 ? /*#__PURE__*/jsx_runtime_.jsx("div", {
            className: "moreOption expanderButton view-more-section innerOption",
            id: "view_more",
            children: /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
              className: "a-section a-spacing-none expanderBullet",
              onClick: event => {
                viewMoreShow(event, null);
              },
              children: ["View All", /*#__PURE__*/jsx_runtime_.jsx("br", {}), " Shades"]
            })
          }) : '']
        }), totalVariants > 17 ? /*#__PURE__*/jsx_runtime_.jsx("div", {
          className: "moreOption expanderButton view-more-section",
          id: "view_more",
          children: /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
            className: "a-section a-spacing-none expanderBullet",
            onClick: event => {
              viewMoreShow(event, null);
            },
            children: ["View All", /*#__PURE__*/jsx_runtime_.jsx("br", {}), " Shades"]
          })
        }) : '']
      })]
    }, "Options"), /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
      className: "pb-6 grid options_modal",
      id: "all_options_list",
      style: {
        display: 'none'
      },
      children: [/*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
        className: "flex justify-between items-baseline headModal",
        children: [/*#__PURE__*/jsx_runtime_.jsx("h2", {
          className: "uppercase font-medium text-sm tracking-wide",
          children: "Color"
        }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
          className: "filter_middle",
          children: [/*#__PURE__*/jsx_runtime_.jsx("button", {
            className: "in-stock-btn active",
            id: "in_stock_filter",
            "aria-label": "In Stock",
            type: "button",
            onClick: event => {
              filterInStockOptions(event, null, null, null, null);
            },
            children: "In Stock"
          }), /*#__PURE__*/jsx_runtime_.jsx("button", {
            className: "out-of-stock-btn",
            id: "out_of_stock_filter",
            "aria-label": "Out Of Stock",
            type: "button",
            onClick: event => {
              filterOutOfStockOptions(event, null, null, null, null);
            },
            children: "Out Of Stock"
          })]
        }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("span", {
          id: "shade_search_block",
          children: [/*#__PURE__*/jsx_runtime_.jsx("input", {
            type: "hidden",
            id: "filter_type",
            defaultValue: "instock"
          }), /*#__PURE__*/jsx_runtime_.jsx("input", {
            type: "text",
            id: "shade_search_modal",
            placeholder: "Shade Search",
            onKeyUp: event => {
              handleSearchModal(event, null, null, null, null);
            }
          })]
        }), /*#__PURE__*/jsx_runtime_.jsx("span", {
          className: "modal_close_btn cursor-pointer",
          onClick: event => {
            modalClose(event, null, null, null);
          },
          children: /*#__PURE__*/jsx_runtime_.jsx(Cross/* default */.Z, {})
        }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
          className: "mobile_options",
          children: [/*#__PURE__*/jsx_runtime_.jsx("span", {
            className: "grid_btn active",
            id: "modal_grid_btn",
            onClick: event => {
              changeToGridModal(event, null, null);
            },
            children: "Grid"
          }), /*#__PURE__*/jsx_runtime_.jsx("span", {
            className: "seperator",
            children: "/"
          }), /*#__PURE__*/jsx_runtime_.jsx("span", {
            className: "list_btn",
            id: "modal_list_btn",
            onClick: event => {
              changeToListModal(event, null, null);
            },
            children: "List"
          })]
        })]
      }), /*#__PURE__*/jsx_runtime_.jsx("div", {
        className: "option-section",
        children: /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
          id: "alloptions_modal",
          className: "flex_div flex justify-start flex-wrap flex-row py-4",
          children: [/*#__PURE__*/jsx_runtime_.jsx("input", {
            type: "hidden",
            value: currentVariant.id
          }), variants.data.map((v, i) => {
            let pUrl = product.path.replace('.html', '');
            const opt = v.option_values[0];
            const active = selectedOptions[opt.option_display_name.toLowerCase()];
            const swatch = publicRuntimeConfig.COLOR_SWATCH_URL + '/product_images/attribute_value_images/' + opt.id + '.preview.jpg';
            const isDisabled = v.inventory_level == 0 ? ' color_disabled' : ' color_enabled';
            const itemQty = items ? items[v.id] : 0;
            return /*#__PURE__*/jsx_runtime_.jsx(Swatch_Swatch, {
              active: currentVariant.sku == v.sku,
              variant: opt.option_display_name,
              color: v.hexColors ? v.hexColors[0] : '',
              image: swatch ? swatch : '',
              label: opt.label,
              id: itemQty,
              className: customclass + isDisabled,
              onClick: event => {
                pickColor(v, null, null, null, null, null, null, null);
              }
            }, `${opt.id}-${i}`);
          })]
        })
      }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
        className: "selected_color_options",
        id: "selected_color_options",
        style: {
          display: 'none'
        },
        children: [/*#__PURE__*/jsx_runtime_.jsx("h4", {
          children: "Color Selected"
        }), /*#__PURE__*/jsx_runtime_.jsx("span", {
          className: "modal_close_btn cursor-pointer",
          onClick: event => {
            modalClose(event, null, null, null);
          },
          children: /*#__PURE__*/jsx_runtime_.jsx(Cross/* default */.Z, {})
        }), /*#__PURE__*/jsx_runtime_.jsx("div", {
          className: "option-title",
          id: "selected_color_title",
          children: currentVariant.option_values ? currentVariant.option_values[0].label : ''
        }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
          className: "option-sku",
          id: "selected_color_sku",
          children: ["SKU: ", currentVariant.sku]
        }), /*#__PURE__*/jsx_runtime_.jsx("img", {
          className: "option-img",
          src: currentVariant.image_url,
          id: "selected_color_img"
        }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
          className: "add_to_cart",
          children: [/*#__PURE__*/jsx_runtime_.jsx("div", {
            className: "wishlist",
            children:  true && /*#__PURE__*/jsx_runtime_.jsx(WishlistButton/* default */.Z, {
              className: external_classnames_default()((ProductSidebar_module_default()).wishlistButton, 'wishBtn'),
              productId: product.id,
              variant: product.variants[0],
              "aria-label": "Add to Wishlist"
            })
          }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
            className: "option-price",
            id: "selected_color_price",
            children: ["$ ", currentVariant.price]
          }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
            className: "d-block h-9 qtyInput",
            children: [/*#__PURE__*/jsx_runtime_.jsx("label", {
              className: "form-label form-label--alternate",
              htmlFor: "varient_qty",
              children: "Qty"
            }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
              className: "qty_section",
              children: [/*#__PURE__*/jsx_runtime_.jsx("button", {
                type: "button",
                className: "Quantity_actions__wWpcD qtyLeft",
                onClick: event => {
                  decreaseQty(event);
                },
                children: /*#__PURE__*/jsx_runtime_.jsx("svg", {
                  width: "18",
                  height: "18",
                  viewBox: "0 0 24 24",
                  fill: "none",
                  children: /*#__PURE__*/jsx_runtime_.jsx("path", {
                    d: "M5 12H19",
                    stroke: "currentColor",
                    strokeWidth: "1.5",
                    strokeLinecap: "round",
                    strokeLinejoin: "round"
                  })
                })
              }), /*#__PURE__*/jsx_runtime_.jsx("label", {
                className: "w-full border-accent-2 border qtyField",
                children: /*#__PURE__*/jsx_runtime_.jsx("input", {
                  className: "Quantity_input__3q7WP qtyValue",
                  id: "varient_qty",
                  type: "text",
                  max: "6",
                  min: "0",
                  defaultValue: "1"
                })
              }), /*#__PURE__*/jsx_runtime_.jsx("button", {
                type: "button",
                className: "Quantity_actions__wWpcD qtyRight",
                onClick: event => {
                  increaseQty(event);
                },
                children: /*#__PURE__*/(0,jsx_runtime_.jsxs)("svg", {
                  width: "18",
                  height: "18",
                  viewBox: "0 0 24 24",
                  fill: "none",
                  children: [/*#__PURE__*/jsx_runtime_.jsx("path", {
                    d: "M12 5V19",
                    stroke: "currentColor",
                    strokeWidth: "1.5",
                    strokeLinecap: "round",
                    strokeLinejoin: "round"
                  }), /*#__PURE__*/jsx_runtime_.jsx("path", {
                    d: "M5 12H19",
                    stroke: "currentColor",
                    strokeWidth: "1.5",
                    strokeLinecap: "round",
                    strokeLinejoin: "round"
                  })]
                })
              })]
            })]
          }), /*#__PURE__*/jsx_runtime_.jsx("div", {
            className: "action to_cart",
            id: "option_cart_btn",
            children:  true && /*#__PURE__*/jsx_runtime_.jsx(Button/* default */.Z, {
              "aria-label": "Add to Bag",
              type: "button",
              className: (ProductSidebar_module_default()).button,
              onClick: event => {
                addToCart(event, null, null);
              },
              loading: loading,
              disabled: (currentVariant === null || currentVariant === void 0 ? void 0 : currentVariant.availableForSale) === false,
              children: (currentVariant === null || currentVariant === void 0 ? void 0 : currentVariant.availableForSale) === false ? 'Not Available' : 'ADD TO BAG'
            })
          })]
        })]
      }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
        className: "selected_color_options out_of_stock_modal",
        id: "disabled_color_options",
        style: {
          display: 'none'
        },
        children: [/*#__PURE__*/jsx_runtime_.jsx("h4", {
          children: "Be Notified"
        }), /*#__PURE__*/jsx_runtime_.jsx("span", {
          className: "modal_close_btn cursor-pointer",
          onClick: event => {
            modalClose(event, null, null, null);
          },
          children: /*#__PURE__*/jsx_runtime_.jsx(Cross/* default */.Z, {})
        }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
          className: "name_img",
          children: [/*#__PURE__*/jsx_runtime_.jsx("div", {
            className: "option-title",
            id: "disabled_color_title",
            children: currentVariant.option_values ? currentVariant.option_values[0].label : ''
          }), /*#__PURE__*/jsx_runtime_.jsx("img", {
            className: "option-img",
            src: currentVariant.image_url,
            id: "disabled_color_img"
          })]
        }), /*#__PURE__*/jsx_runtime_.jsx("div", {
          className: "add_to_cart",
          children: /*#__PURE__*/jsx_runtime_.jsx("div", {
            className: "wishlist",
            children:  true && /*#__PURE__*/jsx_runtime_.jsx(WishlistButton/* default */.Z, {
              className: external_classnames_default()((ProductSidebar_module_default()).wishlistButton, 'wishBtn'),
              productId: product.id,
              variant: product.variants[0],
              "aria-label": "Add to Wishlist"
            })
          })
        }), /*#__PURE__*/jsx_runtime_.jsx("div", {
          className: "notify-section",
          children: /*#__PURE__*/(0,jsx_runtime_.jsxs)("form", {
            className: "notify-form",
            children: [/*#__PURE__*/jsx_runtime_.jsx("input", {
              type: "text",
              placeholder: "Youremail@mail.com",
              className: "form-input"
            }), /*#__PURE__*/jsx_runtime_.jsx("button", {
              type: "submit",
              placeholder: "Youremail@mail.com",
              className: "form-input",
              children: "Notify Me When Available"
            }), /*#__PURE__*/jsx_runtime_.jsx("p", {
              children: "Be notified when this Item is back in stock"
            })]
          })
        })]
      })]
    }, "Options")]
  });
});
/* harmony default export */ const ProductOptions_ProductOptions = (ProductOptions);
// EXTERNAL MODULE: ./components/ui/context.tsx
var context = __webpack_require__(7079);
;// CONCATENATED MODULE: ./components/product/helpers.ts
function helpers_ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) { symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); } keys.push.apply(keys, symbols); } return keys; }

function helpers_objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { helpers_ownKeys(Object(source), true).forEach(function (key) { helpers_defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { helpers_ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function helpers_defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

function getProductVariant(product, opts) {
  const variant = product.variants.find(variant => {
    return Object.entries(opts).every(([key, value]) => variant.options.find(option => {
      if (option.__typename === 'MultipleChoiceOption' && option.displayName.toLowerCase() === key.toLowerCase()) {
        return option.values.find(v => v.label.toLowerCase() === value);
      }
    }));
  });
  return variant;
}
function selectDefaultOptionFromProduct(product, updater) {
  var _product$variants$0$o;

  // Selects the default option
  (_product$variants$0$o = product.variants[0].options) === null || _product$variants$0$o === void 0 ? void 0 : _product$variants$0$o.forEach(v => {
    updater(choices => helpers_objectSpread(helpers_objectSpread({}, choices), {}, {
      [v.displayName.toLowerCase()]: v.values[0].label.toLowerCase()
    }));
  });
}
;// CONCATENATED MODULE: ./components/product/ProductSidebar/ProductSidebar.tsx












const ProductSidebar = ({
  product,
  className,
  variants,
  currentVariant,
  skuChange,
  reviews
}) => {
  const addItem = (0,use_add_item/* default */.Z)();
  const {
    openSidebar
  } = (0,context/* useUI */.l8)();
  const {
    0: loading,
    1: setLoading
  } = (0,external_react_.useState)(false);
  const {
    0: selectedOptions,
    1: setSelectedOptions
  } = (0,external_react_.useState)({});
  (0,external_react_.useEffect)(() => {
    selectDefaultOptionFromProduct(product, setSelectedOptions);
  }, []);
  const variant = getProductVariant(product, selectedOptions);

  const addToCart = async (inputSearch, itemQty) => {
    inputSearch = document.getElementById('selected_variant');
    let variant_id = inputSearch.value;
    itemQty = document.getElementById('qty');
    let qty = itemQty.value;
    setLoading(true);

    try {
      await addItem({
        quantity: Number(qty),
        productId: String(product.id),
        variantId: String(variant_id ? variant_id : product.variants[0].id)
      });
      openSidebar();
      setLoading(false);
    } catch (err) {
      setLoading(false);
    }
  };

  const {
    price
  } = (0,use_price/* default */.ZP)({
    amount: product.price.value,
    baseAmount: product.price.retailPrice,
    currencyCode: product.price.currencyCode
  });
  var minVal = 1,
      maxVal = 20; // Set Max and Min values

  function increaseQty(element) {
    element = document.getElementById('qty');
    var qtyVal = element.value;

    if (qtyVal < maxVal) {
      qtyVal++;
    }

    element.value = qtyVal;
  }

  function decreaseQty(element) {
    element = document.getElementById('qty');
    var qtyVal = element.value;

    if (qtyVal > 1) {
      qtyVal--;
    }

    element.value = qtyVal;
  }

  const productSku = currentVariant.sku.toLowerCase();
  return /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
    className: className,
    children: [/*#__PURE__*/(0,jsx_runtime_.jsxs)("h1", {
      className: "productView-title",
      children: [product.name, " -", ' ', /*#__PURE__*/jsx_runtime_.jsx("span", {
        className: "product_option_title",
        children: currentVariant.option_values ? currentVariant.option_values[0].label : ''
      })]
    }), /*#__PURE__*/jsx_runtime_.jsx("div", {
      className: "flex flex-row items-center reviews-section",
      children: /*#__PURE__*/jsx_runtime_.jsx(Text/* default */.Z, {
        className: "product-reviews-top",
        html: reviews.topContent || reviews.topContent
      })
    }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
      className: "product-sku",
      children: ["SKU: ", productSku]
    }), /*#__PURE__*/jsx_runtime_.jsx("div", {
      className: "product-price",
      children: `${price}`
    }), /*#__PURE__*/jsx_runtime_.jsx(ProductOptions_ProductOptions, {
      options: product.options,
      selectedOptions: selectedOptions,
      setSelectedOptions: setSelectedOptions,
      product: product,
      variants: variants,
      currentVariant: currentVariant,
      skuChange: skuChange
    }), /*#__PURE__*/jsx_runtime_.jsx("div", {
      className: "mobile_price",
      children: /*#__PURE__*/jsx_runtime_.jsx("div", {
        className: "product-price",
        children: `${price}`
      })
    }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
      className: "add_to_cart",
      children: [/*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
        className: "d-block h-9 qtyInput",
        children: [/*#__PURE__*/jsx_runtime_.jsx("label", {
          className: "form-label form-label--alternate",
          htmlFor: "qty",
          children: "Quantity"
        }), /*#__PURE__*/jsx_runtime_.jsx("button", {
          type: "button",
          className: "Quantity_actions__wWpcD qtyLeft",
          onClick: event => {
            decreaseQty(event);
          },
          children: /*#__PURE__*/jsx_runtime_.jsx("svg", {
            width: "18",
            height: "18",
            viewBox: "0 0 24 24",
            fill: "none",
            children: /*#__PURE__*/jsx_runtime_.jsx("path", {
              d: "M5 12H19",
              stroke: "currentColor",
              strokeWidth: "1.5",
              strokeLinecap: "round",
              strokeLinejoin: "round"
            })
          })
        }), /*#__PURE__*/jsx_runtime_.jsx("label", {
          className: "w-full border-accent-2 border qtyField",
          children: /*#__PURE__*/jsx_runtime_.jsx("input", {
            className: "Quantity_input__3q7WP qtyValue",
            id: "qty",
            type: "text",
            max: "6",
            min: "0",
            defaultValue: "1"
          })
        }), /*#__PURE__*/jsx_runtime_.jsx("button", {
          type: "button",
          className: "Quantity_actions__wWpcD qtyRight",
          onClick: event => {
            increaseQty(event);
          },
          children: /*#__PURE__*/(0,jsx_runtime_.jsxs)("svg", {
            width: "18",
            height: "18",
            viewBox: "0 0 24 24",
            fill: "none",
            children: [/*#__PURE__*/jsx_runtime_.jsx("path", {
              d: "M12 5V19",
              stroke: "currentColor",
              strokeWidth: "1.5",
              strokeLinecap: "round",
              strokeLinejoin: "round"
            }), /*#__PURE__*/jsx_runtime_.jsx("path", {
              d: "M5 12H19",
              stroke: "currentColor",
              strokeWidth: "1.5",
              strokeLinecap: "round",
              strokeLinejoin: "round"
            })]
          })
        })]
      }), /*#__PURE__*/jsx_runtime_.jsx("div", {
        className: "wishlist",
        children:  true && /*#__PURE__*/jsx_runtime_.jsx(WishlistButton/* default */.Z, {
          className: external_classnames_default()((ProductSidebar_module_default()).wishlistButton, 'wishBtn'),
          productId: product.id,
          variant: product.variants[0],
          "aria-label": "Add to Wishlist"
        })
      }), /*#__PURE__*/jsx_runtime_.jsx("div", {
        className: "action to_cart",
        children:  true && /*#__PURE__*/jsx_runtime_.jsx(Button/* default */.Z, {
          "aria-label": "Add to Bag",
          type: "button",
          className: (ProductSidebar_module_default()).button,
          onClick: event => {
            addToCart(event, null);
          },
          loading: loading,
          disabled: (variant === null || variant === void 0 ? void 0 : variant.availableForSale) === false,
          children: (variant === null || variant === void 0 ? void 0 : variant.availableForSale) === false ? 'Not Available' : 'ADD TO BAG'
        })
      })]
    })]
  });
};

/* harmony default export */ const ProductSidebar_ProductSidebar = (ProductSidebar);
;// CONCATENATED MODULE: external "react-tabs"
const external_react_tabs_namespaceObject = require("react-tabs");
;// CONCATENATED MODULE: external "react-multi-carousel"
const external_react_multi_carousel_namespaceObject = require("react-multi-carousel");
var external_react_multi_carousel_default = /*#__PURE__*/__webpack_require__.n(external_react_multi_carousel_namespaceObject);
// EXTERNAL MODULE: ./node_modules/next/link.js
var next_link = __webpack_require__(1664);
;// CONCATENATED MODULE: ./components/product/ProductView/ProductView.tsx

















const {
  publicRuntimeConfig: ProductView_publicRuntimeConfig
} = config_default()();

const ProductView = ({
  product,
  relatedProducts,
  variants,
  currentVariant,
  skuChange,
  reviews,
  ratings
}) => {
  var _product$images$;

  // console.log(reviews)
  const productSku = currentVariant.data ? currentVariant.data[0].sku : '';
  const currentSwatchId = currentVariant.data ? currentVariant.data[0].option_values[0].id : '';
  const currentSwatchLabel = currentVariant.data ? currentVariant.data[0].option_values[0].label : '';
  const currentSwatchImg = ProductView_publicRuntimeConfig.COLOR_SWATCH_URL + "/product_images/attribute_value_images/" + currentSwatchId + ".preview.jpg";
  const {
    SOCIALANNEX_TEMPLATE_ID
  } = process.env;
  const productImage = product.images[0] ? product.images[0].url : '';
  const responsive = {
    superLargeDesktop: {
      // the naming can be any, depends on you.
      breakpoint: {
        max: 4000,
        min: 3000
      },
      items: 4
    },
    desktop: {
      breakpoint: {
        max: 3000,
        min: 1024
      },
      items: 4
    },
    tablet: {
      breakpoint: {
        max: 1024,
        min: 767
      },
      items: 2
    },
    mobile: {
      breakpoint: {
        max: 767,
        min: 0
      },
      items: 1.5
    }
  };

  function getPrice(product) {
    const {
      price
    } = (0,use_price/* default */.ZP)({
      amount: product.price.value,
      baseAmount: product.price.retailPrice,
      currencyCode: product.price.currencyCode
    });
    return price;
  }

  return /*#__PURE__*/(0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
    children: [/*#__PURE__*/(0,jsx_runtime_.jsxs)(Container/* default */.Z, {
      className: "max-w_none w_full container_page PDPView",
      clean: true,
      children: [/*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
        className: "productInfo mobile_view",
        children: [/*#__PURE__*/jsx_runtime_.jsx("h1", {
          className: "productView-title",
          children: product.name
        }), /*#__PURE__*/jsx_runtime_.jsx("div", {
          className: "flex flex-row items-left reviews-section",
          children: /*#__PURE__*/jsx_runtime_.jsx(Text/* default */.Z, {
            className: "product-reviews-top top-review-custom w-full",
            html: reviews.topContent || reviews.topContent
          })
        }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
          className: "product-sku",
          children: ["SKU: ", productSku]
        })]
      }), currentVariant && variants ? /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
        className: external_classnames_default()((ProductView_module_default()).root, 'fit PDPcontainer'),
        children: [/*#__PURE__*/jsx_runtime_.jsx("div", {
          className: external_classnames_default()((ProductView_module_default()).main, 'fit productIMG'),
          children: /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
            className: external_classnames_default()((ProductView_module_default()).sliderContainer, 'bgColor'),
            children: [/*#__PURE__*/jsx_runtime_.jsx(ProductSlider/* default */.Z, {
              viewCount: 5,
              children: product.images.map((image, i) => /*#__PURE__*/jsx_runtime_.jsx("div", {
                className: (ProductView_module_default()).imageContainer,
                children: /*#__PURE__*/jsx_runtime_.jsx(next_image.default, {
                  className: (ProductView_module_default()).img,
                  src: image.url,
                  alt: image.alt || 'Product Image',
                  width: 292,
                  height: 609,
                  priority: i === 0,
                  quality: "100"
                })
              }, currentVariant.data[0].image_url))
            }, product.id), /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
              className: "selected_swatch_details",
              children: [/*#__PURE__*/jsx_runtime_.jsx("div", {
                className: "selected_swatch_label",
                children: currentSwatchLabel
              }), /*#__PURE__*/jsx_runtime_.jsx("img", {
                className: "selected_swatch_thumb",
                src: currentSwatchImg
              })]
            })]
          })
        }), /*#__PURE__*/jsx_runtime_.jsx(ProductSidebar_ProductSidebar, {
          product: product,
          className: external_classnames_default()((ProductView_module_default()).sidebar, 'productInfo fit'),
          variants: variants,
          currentVariant: currentVariant.data[0],
          skuChange: skuChange,
          reviews: reviews
        })]
      }) : "", /*#__PURE__*/jsx_runtime_.jsx("div", {
        className: "mt-2 TabsSection",
        children: /*#__PURE__*/(0,jsx_runtime_.jsxs)(external_react_tabs_namespaceObject.Tabs, {
          children: [/*#__PURE__*/(0,jsx_runtime_.jsxs)(external_react_tabs_namespaceObject.TabList, {
            children: [/*#__PURE__*/jsx_runtime_.jsx(external_react_tabs_namespaceObject.Tab, {
              children: "Description"
            }), /*#__PURE__*/jsx_runtime_.jsx(external_react_tabs_namespaceObject.Tab, {
              children: "Feature & Details"
            }), /*#__PURE__*/jsx_runtime_.jsx(external_react_tabs_namespaceObject.Tab, {
              children: "Shipping & Returns"
            })]
          }), /*#__PURE__*/jsx_runtime_.jsx(external_react_tabs_namespaceObject.TabPanel, {
            children: /*#__PURE__*/jsx_runtime_.jsx(Text/* default */.Z, {
              className: "pb-4 break-words w-full max-w-xl",
              html: product.descriptionHtml || product.description
            })
          }), /*#__PURE__*/jsx_runtime_.jsx(external_react_tabs_namespaceObject.TabPanel, {
            children: /*#__PURE__*/jsx_runtime_.jsx("p", {
              children: "Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum."
            })
          }), /*#__PURE__*/jsx_runtime_.jsx(external_react_tabs_namespaceObject.TabPanel, {
            children: /*#__PURE__*/jsx_runtime_.jsx("p", {
              children: "Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum."
            })
          })]
        })
      }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("section", {
        className: "py-12 px-6 mb-10 BoughtSection",
        children: [/*#__PURE__*/jsx_runtime_.jsx(Text/* default */.Z, {
          variant: "sectionHeading",
          children: "Bought also Bought"
        }), /*#__PURE__*/jsx_runtime_.jsx((external_react_multi_carousel_default()), {
          responsive: responsive,
          arrows: true,
          showDots: true,
          infinite: true,
          children: relatedProducts.map(p => {
            var _p$images$;

            return /*#__PURE__*/jsx_runtime_.jsx(next_link.default, {
              href: `/${p.slug ? p.slug.replace('.html', '') : p.slug}`,
              children: /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
                className: "animated fadeIn ItemPro",
                children: [/*#__PURE__*/jsx_runtime_.jsx("img", {
                  src: (_p$images$ = p.images[0]) === null || _p$images$ === void 0 ? void 0 : _p$images$.url
                }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
                  className: "produtDetails",
                  children: [/*#__PURE__*/jsx_runtime_.jsx("h5", {
                    children: p.name
                  }), /*#__PURE__*/jsx_runtime_.jsx("p", {
                    children: getPrice(p)
                  })]
                })]
              }, p.path)
            });
          })
        })]
      }), reviews ? /*#__PURE__*/jsx_runtime_.jsx("section", {
        className: "py-12 px-6 mb-10 ReviewsSection",
        children: /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
          className: "review_bottom",
          children: [/*#__PURE__*/jsx_runtime_.jsx("h2", {
            className: "Text_sectionHeading__2H2XC",
            children: "Reviews"
          }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
            className: "product_reviews",
            children: [/*#__PURE__*/(0,jsx_runtime_.jsxs)("h3", {
              children: ["All Comments (", reviews.total, ")"]
            }), reviews.results.map((preview, i) => {
              let date = new Date(preview.review.dateCreated);
              let reviewDate = `${date.getDate()} - ${date.getMonth()} - ${date.getFullYear()}`;
              return /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
                className: "review-item",
                children: [/*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
                  className: "review-details",
                  children: [/*#__PURE__*/jsx_runtime_.jsx("div", {
                    className: "customer-name",
                    children: preview.customer ? /*#__PURE__*/(0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
                      children: [preview.customer.profileImageUrl ? /*#__PURE__*/jsx_runtime_.jsx("img", {
                        src: preview.customer.profileImageUrl
                      }) : /*#__PURE__*/jsx_runtime_.jsx("img", {
                        src: "/user.jpg"
                      }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("p", {
                        children: [preview.customer.name ? preview.customer.name : preview.customer.firstName + ' ' + preview.customer.lastName, /*#__PURE__*/jsx_runtime_.jsx("span", {
                          className: "review-date",
                          children: reviewDate
                        })]
                      })]
                    }) : /*#__PURE__*/(0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
                      children: [/*#__PURE__*/jsx_runtime_.jsx("img", {
                        src: "/user.jpg"
                      }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("p", {
                        children: [preview.review.email, /*#__PURE__*/jsx_runtime_.jsx("span", {
                          className: "review-date",
                          children: reviewDate
                        })]
                      })]
                    })
                  }), /*#__PURE__*/jsx_runtime_.jsx("div", {
                    className: "review-ratings",
                    children: preview.review.rating > 0 ? /*#__PURE__*/jsx_runtime_.jsx("img", {
                      src: '/' + preview.review.rating + 'star.png'
                    }) : ''
                  })]
                }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
                  className: "review-body",
                  children: [/*#__PURE__*/jsx_runtime_.jsx("h4", {
                    children: preview.review.title
                  }), /*#__PURE__*/jsx_runtime_.jsx(Text/* default */.Z, {
                    className: "break-words w-full max-w-xl",
                    html: preview.review ? preview.review.body : ''
                  })]
                })]
              }, i);
            })]
          })]
        })
      }) : '']
    }), /*#__PURE__*/jsx_runtime_.jsx(external_next_seo_.NextSeo, {
      title: product.name,
      description: product.description,
      openGraph: {
        type: 'website',
        title: product.name,
        description: product.description,
        images: [{
          url: (_product$images$ = product.images[0]) === null || _product$images$ === void 0 ? void 0 : _product$images$.url,
          width: 800,
          height: 600,
          alt: product.name
        }]
      }
    })]
  });
};

/* harmony default export */ const ProductView_ProductView = (ProductView);
;// CONCATENATED MODULE: ./pages/products/[slug].tsx







const {
  publicRuntimeConfig: _slug_publicRuntimeConfig
} = config_default()();
async function getStaticProps({
  params,
  locale,
  locales,
  preview
}) {
  const config = {
    locale,
    locales
  };
  const pagesPromise = commerce/* default.getAllPages */.Z.getAllPages({
    config,
    preview
  });
  const siteInfoPromise = commerce/* default.getSiteInfo */.Z.getSiteInfo({
    config,
    preview
  });
  let slg = 'products/' + params.slug + '.html';
  const productPromise = commerce/* default.getProduct */.Z.getProduct({
    variables: {
      slug: slg
    },
    config,
    preview
  });
  const allProductsPromise = commerce/* default.getAllProducts */.Z.getAllProducts({
    variables: {
      first: 4
    },
    config,
    preview
  });
  const {
    pages
  } = await pagesPromise;
  const {
    categories
  } = await siteInfoPromise;
  const {
    product
  } = await productPromise;
  const {
    products: relatedProducts
  } = await allProductsPromise;

  if (!product) {
    throw new Error(`Product with slug '${params.slug}' not found`);
  }

  return {
    props: {
      pages,
      product,
      relatedProducts,
      categories
    },
    revalidate: 200
  };
}
async function getStaticPaths({
  locales
}) {
  const {
    products
  } = await commerce/* default.getAllProductPaths */.Z.getAllProductPaths();
  return {
    paths: locales ? locales.reduce((arr, locale) => {
      // Add a product path for every locale
      products.forEach(product => {
        let p = product.path.replace('.html', '');
        arr.push(`/${locale}${p}`);
      });
      return arr;
    }, []) : products.map(product => product.path.replace('.html', '')),
    fallback: 'blocking'
  };
}
function Slug({
  product,
  relatedProducts
}) {
  const router = (0,router_.useRouter)();
  const {
    0: sku,
    1: setSku
  } = (0,external_react_.useState)('');
  const {
    0: result,
    1: setResult
  } = (0,external_react_.useState)('');
  const {
    0: variants,
    1: setVariants
  } = (0,external_react_.useState)('');
  const {
    0: reviews,
    1: setReviews
  } = (0,external_react_.useState)('');
  const {
    0: ratings,
    1: setRatings
  } = (0,external_react_.useState)('');
  (0,external_react_.useEffect)(() => {
    if (!sku) {
      let skusearch = window.location.search;
      let psku = skusearch.replace("?sku=", "");
      setSku(psku);
    }

    let pid = product ? product.id : '';

    if (pid) {
      fetch(`${_slug_publicRuntimeConfig.BASE_URL}/api/catalog/variants?id=${pid}`).then(response => response.json()).then(response => setVariants(response)).catch(error => setVariants(error));

      if (sku) {
        fetch(`${_slug_publicRuntimeConfig.BASE_URL}/api/catalog/variant?id=${pid}&sku=${sku}`).then(response => response.json()).then(response => setResult(response)).catch(error => setResult(error));
      } else {
        fetch(`${_slug_publicRuntimeConfig.BASE_URL}/api/catalog/variants?id=${pid}`).then(response => response.json()).then(response => setResult(response)).catch(error => setResult(error));
      }

      fetch(`${_slug_publicRuntimeConfig.BASE_URL}/api/catalog/getReviews?id=${pid}`).then(response => response.json()).then(response => setReviews(response)).catch(error => setReviews(error));
      let pUrl = product ? product.path : '';

      if (pUrl && sku) {
        pUrl = pUrl.replace('.html', '');
        router.push(`${pUrl}?sku=${sku}`);
      }
    }
  }, [sku]);

  const skuChange = testSku => {
    setSku(testSku);
  };

  return router.isFallback ? /*#__PURE__*/jsx_runtime_.jsx("h1", {
    children: "Loading..."
  }) : /*#__PURE__*/jsx_runtime_.jsx(ProductView_ProductView, {
    product: product,
    relatedProducts: relatedProducts,
    variants: variants,
    currentVariant: result,
    skuChange: skuChange,
    reviews: reviews,
    ratings: ratings
  });
}
Slug.Layout = Layout/* default */.Z;

/***/ }),

/***/ 284:
/***/ ((module) => {

// Exports
module.exports = {
	"root": "ProductSidebar_root__qga5M",
	"main": "ProductSidebar_main__3Oyy6",
	"header": "ProductSidebar_header__HcNs9",
	"name": "ProductSidebar_name__yE98f",
	"price": "ProductSidebar_price__2Q6Tt",
	"sidebar": "ProductSidebar_sidebar__3rUk1",
	"sliderContainer": "ProductSidebar_sliderContainer__1W70l",
	"imageContainer": "ProductSidebar_imageContainer__27yCh",
	"img": "ProductSidebar_img__g0H1P",
	"button": "ProductSidebar_button__1qC_d",
	"wishlistButton": "ProductSidebar_wishlistButton__AbXX1",
	"relatedProductsGrid": "ProductSidebar_relatedProductsGrid__3LJ2R"
};


/***/ }),

/***/ 6734:
/***/ ((module) => {

// Exports
module.exports = {
	"root": "ProductView_root__3DwjX",
	"main": "ProductView_main__37Daz",
	"sidebar": "ProductView_sidebar__17Whl",
	"sliderContainer": "ProductView_sliderContainer__3uuKd",
	"imageContainer": "ProductView_imageContainer__2j3w1",
	"img": "ProductView_img__2zrit",
	"button": "ProductView_button__37IG8",
	"wishlistButton": "ProductView_wishlistButton__3m9wF",
	"relatedProductsGrid": "ProductView_relatedProductsGrid__2nvyp"
};


/***/ }),

/***/ 2890:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

// Imports
var ___CSS_LOADER_ICSS_IMPORT_0___ = __webpack_require__(8583);
// Exports
module.exports = {
	"swatch": "Swatch_swatch__1aJ-S " + ___CSS_LOADER_ICSS_IMPORT_0___["root"] + "",
	"color": "Swatch_color__11JL4",
	"dark": "Swatch_dark__38MqR",
	"active": "Swatch_active__1tGtw",
	"textLabel": "Swatch_textLabel__3g_3F"
};


/***/ }),

/***/ 2937:
/***/ ((module) => {

"use strict";
module.exports = require("@vercel/fetch");

/***/ }),

/***/ 8023:
/***/ ((module) => {

"use strict";
module.exports = require("body-scroll-lock");

/***/ }),

/***/ 4058:
/***/ ((module) => {

"use strict";
module.exports = require("classnames");

/***/ }),

/***/ 506:
/***/ ((module) => {

"use strict";
module.exports = require("email-validator");

/***/ }),

/***/ 2740:
/***/ ((module) => {

"use strict";
module.exports = require("immutability-helper");

/***/ }),

/***/ 6155:
/***/ ((module) => {

"use strict";
module.exports = require("js-cookie");

/***/ }),

/***/ 1471:
/***/ ((module) => {

"use strict";
module.exports = require("keen-slider/react");

/***/ }),

/***/ 5371:
/***/ ((module) => {

"use strict";
module.exports = require("lodash.debounce");

/***/ }),

/***/ 1602:
/***/ ((module) => {

"use strict";
module.exports = require("lodash.throttle");

/***/ }),

/***/ 2364:
/***/ ((module) => {

"use strict";
module.exports = require("next-seo");

/***/ }),

/***/ 2517:
/***/ ((module) => {

"use strict";
module.exports = require("next-themes");

/***/ }),

/***/ 9325:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/server/denormalize-page-path.js");

/***/ }),

/***/ 822:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/server/image-config.js");

/***/ }),

/***/ 6695:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/head.js");

/***/ }),

/***/ 8300:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/i18n/detect-domain-locale.js");

/***/ }),

/***/ 5378:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/i18n/normalize-locale-path.js");

/***/ }),

/***/ 2307:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/loadable.js");

/***/ }),

/***/ 7162:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/mitt.js");

/***/ }),

/***/ 8773:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router-context.js");

/***/ }),

/***/ 2248:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/get-asset-path-from-route.js");

/***/ }),

/***/ 9372:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/is-dynamic.js");

/***/ }),

/***/ 665:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/parse-relative-url.js");

/***/ }),

/***/ 2747:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/querystring.js");

/***/ }),

/***/ 654:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/resolve-rewrites.js");

/***/ }),

/***/ 333:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/route-matcher.js");

/***/ }),

/***/ 3456:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/route-regex.js");

/***/ }),

/***/ 556:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/to-base-64.js");

/***/ }),

/***/ 7620:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/utils.js");

/***/ }),

/***/ 6731:
/***/ ((module) => {

"use strict";
module.exports = require("next/router");

/***/ }),

/***/ 8689:
/***/ ((module) => {

"use strict";
module.exports = require("next/script");

/***/ }),

/***/ 9297:
/***/ ((module) => {

"use strict";
module.exports = require("react");

/***/ }),

/***/ 123:
/***/ ((module) => {

"use strict";
module.exports = require("react-merge-refs");

/***/ }),

/***/ 5282:
/***/ ((module) => {

"use strict";
module.exports = require("react/jsx-runtime");

/***/ }),

/***/ 7749:
/***/ ((module) => {

"use strict";
module.exports = require("swr");

/***/ }),

/***/ 8047:
/***/ ((module) => {

"use strict";
module.exports = require("tabbable");

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [157,370,862,79,428,909,644,742,52], () => (__webpack_exec__(3010)));
module.exports = __webpack_exports__;

})();