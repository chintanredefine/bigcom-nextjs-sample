exports.id = 353;
exports.ids = [353];
exports.modules = {

/***/ 353:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "Z": () => (/* binding */ ProductCard_ProductCard)
});

// EXTERNAL MODULE: external "classnames"
var external_classnames_ = __webpack_require__(4058);
var external_classnames_default = /*#__PURE__*/__webpack_require__.n(external_classnames_);
// EXTERNAL MODULE: ./node_modules/next/link.js
var next_link = __webpack_require__(1664);
// EXTERNAL MODULE: ./components/product/ProductCard/ProductCard.module.css
var ProductCard_module = __webpack_require__(9759);
var ProductCard_module_default = /*#__PURE__*/__webpack_require__.n(ProductCard_module);
// EXTERNAL MODULE: ./node_modules/next/image.js
var next_image = __webpack_require__(5675);
// EXTERNAL MODULE: ./components/wishlist/WishlistButton/WishlistButton.tsx
var WishlistButton = __webpack_require__(1644);
// EXTERNAL MODULE: ./framework/commerce/product/use-price.tsx
var use_price = __webpack_require__(5420);
// EXTERNAL MODULE: ./components/product/ProductTag/ProductTag.module.css
var ProductTag_module = __webpack_require__(5947);
var ProductTag_module_default = /*#__PURE__*/__webpack_require__.n(ProductTag_module);
// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(5282);
;// CONCATENATED MODULE: ./components/product/ProductTag/ProductTag.tsx





const ProductTag = ({
  name,
  price,
  className = '',
  fontSize = 32
}) => {
  return /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
    className: external_classnames_default()((ProductTag_module_default()).root, className),
    children: [/*#__PURE__*/jsx_runtime_.jsx("h3", {
      className: (ProductTag_module_default()).name,
      children: /*#__PURE__*/jsx_runtime_.jsx("span", {
        className: external_classnames_default()({
          [(ProductTag_module_default()).fontsizing]: fontSize < 32
        }),
        style: {
          fontSize: `${fontSize}px`,
          lineHeight: `${fontSize}px`
        },
        children: name
      })
    }), /*#__PURE__*/jsx_runtime_.jsx("div", {
      className: (ProductTag_module_default()).price,
      children: price
    })]
  });
};

/* harmony default export */ const ProductTag_ProductTag = (ProductTag);
;// CONCATENATED MODULE: ./components/product/ProductCard/ProductCard.tsx
const _excluded = ["product", "imgProps", "className", "noNameTag", "variant"];

function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) { symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); } keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

function _objectWithoutProperties(source, excluded) { if (source == null) return {}; var target = _objectWithoutPropertiesLoose(source, excluded); var key, i; if (Object.getOwnPropertySymbols) { var sourceSymbolKeys = Object.getOwnPropertySymbols(source); for (i = 0; i < sourceSymbolKeys.length; i++) { key = sourceSymbolKeys[i]; if (excluded.indexOf(key) >= 0) continue; if (!Object.prototype.propertyIsEnumerable.call(source, key)) continue; target[key] = source[key]; } } return target; }

function _objectWithoutPropertiesLoose(source, excluded) { if (source == null) return {}; var target = {}; var sourceKeys = Object.keys(source); var key, i; for (i = 0; i < sourceKeys.length; i++) { key = sourceKeys[i]; if (excluded.indexOf(key) >= 0) continue; target[key] = source[key]; } return target; }











const placeholderImg = '/product-img-placeholder.svg';

const ProductCard = _ref => {
  var _product$images$, _product$price, _product$price2, _product$images$2;

  let {
    product,
    imgProps,
    className,
    noNameTag = false,
    variant = 'default'
  } = _ref,
      props = _objectWithoutProperties(_ref, _excluded);

  const {
    price
  } = (0,use_price/* default */.ZP)({
    amount: product.price.value,
    baseAmount: product.price.retailPrice,
    currencyCode: product.price.currencyCode
  });
  const rootClassName = external_classnames_default()((ProductCard_module_default()).root, {
    [(ProductCard_module_default()).slim]: variant === 'slim',
    [(ProductCard_module_default()).simple]: variant === 'simple'
  }, className);
  return /*#__PURE__*/jsx_runtime_.jsx(next_link.default, _objectSpread(_objectSpread({
    href: `/${product.slug ? product.slug.replace('.html', '') : product.slug}`
  }, props), {}, {
    children: /*#__PURE__*/(0,jsx_runtime_.jsxs)("a", {
      className: external_classnames_default()(rootClassName, 'related_product'),
      children: [variant === 'slim' && /*#__PURE__*/(0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
        children: [/*#__PURE__*/jsx_runtime_.jsx("div", {
          className: (ProductCard_module_default()).header,
          children: /*#__PURE__*/jsx_runtime_.jsx("span", {
            children: product.name
          })
        }), (product === null || product === void 0 ? void 0 : product.images) && /*#__PURE__*/jsx_runtime_.jsx(next_image.default, _objectSpread({
          quality: "85",
          src: ((_product$images$ = product.images[0]) === null || _product$images$ === void 0 ? void 0 : _product$images$.url) || placeholderImg,
          alt: product.name || 'Product Image',
          height: 320,
          width: 320,
          layout: "fixed"
        }, imgProps))]
      }), variant === 'simple' && /*#__PURE__*/(0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
        children: [ true && /*#__PURE__*/jsx_runtime_.jsx(WishlistButton/* default */.Z, {
          className: (ProductCard_module_default()).wishlistButton,
          productId: product.id,
          variant: product.variants[0]
        }), !noNameTag && /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
          className: (ProductCard_module_default()).header,
          children: [/*#__PURE__*/jsx_runtime_.jsx("h3", {
            className: (ProductCard_module_default()).name,
            children: /*#__PURE__*/jsx_runtime_.jsx("span", {
              children: product.name
            })
          }), /*#__PURE__*/jsx_runtime_.jsx("div", {
            className: (ProductCard_module_default()).price,
            children: `${price} ${(_product$price = product.price) === null || _product$price === void 0 ? void 0 : _product$price.currencyCode}`
          })]
        }), /*#__PURE__*/jsx_runtime_.jsx("div", {
          className: (ProductCard_module_default()).imageContainer,
          children: (product === null || product === void 0 ? void 0 : product.images) && /*#__PURE__*/jsx_runtime_.jsx(next_image.default, _objectSpread({
            alt: product.name || 'Product Image',
            className: (ProductCard_module_default()).productImage,
            src: product.images[0].url || placeholderImg,
            height: 540,
            width: 540,
            quality: "85",
            layout: "responsive"
          }, imgProps))
        })]
      }), variant === 'default' && /*#__PURE__*/(0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
        children: [ true && /*#__PURE__*/jsx_runtime_.jsx(WishlistButton/* default */.Z, {
          className: (ProductCard_module_default()).wishlistButton,
          productId: product.id,
          variant: product.variants[0]
        }), /*#__PURE__*/jsx_runtime_.jsx(ProductTag_ProductTag, {
          name: product.name,
          price: `${price} ${(_product$price2 = product.price) === null || _product$price2 === void 0 ? void 0 : _product$price2.currencyCode}`
        }), /*#__PURE__*/jsx_runtime_.jsx("div", {
          className: (ProductCard_module_default()).imageContainer,
          children: (product === null || product === void 0 ? void 0 : product.images) && /*#__PURE__*/jsx_runtime_.jsx(next_image.default, _objectSpread({
            alt: product.name || 'Product Image',
            className: (ProductCard_module_default()).productImage,
            src: ((_product$images$2 = product.images[0]) === null || _product$images$2 === void 0 ? void 0 : _product$images$2.url) || placeholderImg,
            height: 540,
            width: 540,
            quality: "85",
            layout: "responsive"
          }, imgProps))
        })]
      })]
    })
  }));
};

/* harmony default export */ const ProductCard_ProductCard = (ProductCard);

/***/ }),

/***/ 9759:
/***/ ((module) => {

// Exports
module.exports = {
	"root": "ProductCard_root__2we6k",
	"productImage": "ProductCard_productImage__2DvT0",
	"header": "ProductCard_header__1RX2E",
	"name": "ProductCard_name__3Mulz",
	"price": "ProductCard_price__1Pa1I",
	"wishlistButton": "ProductCard_wishlistButton__2M9lM",
	"imageContainer": "ProductCard_imageContainer__bPqUi",
	"simple": "ProductCard_simple__thMup",
	"slim": "ProductCard_slim__2eJvH",
	"related_product": "ProductCard_related_product__1E7qP"
};


/***/ }),

/***/ 5947:
/***/ ((module) => {

// Exports
module.exports = {
	"root": "ProductTag_root__BOTxu",
	"name": "ProductTag_name__2G8VD",
	"fontsizing": "ProductTag_fontsizing__zCI1h",
	"price": "ProductTag_price__1V8pj"
};


/***/ })

};
;