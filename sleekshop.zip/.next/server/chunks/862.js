"use strict";
exports.id = 862;
exports.ids = [862];
exports.modules = {

/***/ 4264:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "zd": () => (/* binding */ BigcommerceApiError),
/* harmony export */   "Ye": () => (/* binding */ BigcommerceNetworkError)
/* harmony export */ });
/* unused harmony export BigcommerceGraphQLError */
function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

// Used for GraphQL errors
class BigcommerceGraphQLError extends Error {}
class BigcommerceApiError extends Error {
  constructor(msg, res, data) {
    super(msg);

    _defineProperty(this, "status", void 0);

    _defineProperty(this, "res", void 0);

    _defineProperty(this, "data", void 0);

    this.name = 'BigcommerceApiError';
    this.status = res.status;
    this.res = res;
    this.data = data;
  }

}
class BigcommerceNetworkError extends Error {
  constructor(msg) {
    super(msg);
    this.name = 'BigcommerceNetworkError';
  }

}

/***/ }),

/***/ 7258:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {


// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "Id": () => (/* binding */ normalizeCart),
  "Zh": () => (/* binding */ normalizeCategory),
  "ze": () => (/* binding */ normalizePage),
  "Op": () => (/* binding */ normalizeProduct)
});

// EXTERNAL MODULE: external "immutability-helper"
var external_immutability_helper_ = __webpack_require__(2740);
;// CONCATENATED MODULE: ./framework/bigcommerce/lib/immutability.ts

const c = new external_immutability_helper_.Context();
c.extend('$auto', function (value, object) {
  return object ? c.update(object, value) : c.update({}, value);
});
c.extend('$autoArray', function (value, object) {
  return object ? c.update(object, value) : c.update([], value);
});
/* harmony default export */ const immutability = (c.update);
;// CONCATENATED MODULE: ./framework/bigcommerce/lib/get-slug.ts
// Remove trailing and leading slash, usually included in nodes
// returned by the BigCommerce API
const getSlug = path => path.replace(/^\/|\/$/g, '');

/* harmony default export */ const get_slug = (getSlug);
;// CONCATENATED MODULE: ./framework/bigcommerce/lib/normalize.ts
const _excluded = ["entityId", "values"],
      _excluded2 = ["urlOriginal", "altText"],
      _excluded3 = ["entityId", "productOptions"];

function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) { symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); } keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

function _objectWithoutProperties(source, excluded) { if (source == null) return {}; var target = _objectWithoutPropertiesLoose(source, excluded); var key, i; if (Object.getOwnPropertySymbols) { var sourceSymbolKeys = Object.getOwnPropertySymbols(source); for (i = 0; i < sourceSymbolKeys.length; i++) { key = sourceSymbolKeys[i]; if (excluded.indexOf(key) >= 0) continue; if (!Object.prototype.propertyIsEnumerable.call(source, key)) continue; target[key] = source[key]; } } return target; }

function _objectWithoutPropertiesLoose(source, excluded) { if (source == null) return {}; var target = {}; var sourceKeys = Object.keys(source); var key, i; for (i = 0; i < sourceKeys.length; i++) { key = sourceKeys[i]; if (excluded.indexOf(key) >= 0) continue; target[key] = source[key]; } return target; }




function normalizeProductOption(productOption) {
  const {
    node: {
      entityId,
      values: {
        edges = []
      } = {}
    }
  } = productOption,
        rest = _objectWithoutProperties(productOption.node, _excluded);

  return _objectSpread({
    id: entityId,
    values: edges === null || edges === void 0 ? void 0 : edges.map(({
      node
    }) => node)
  }, rest);
}

function normalizeProduct(productNode) {
  const {
    entityId: id,
    productOptions,
    prices,
    path,
    id: _,
    options: _0
  } = productNode;
  return immutability(productNode, {
    id: {
      $set: String(id)
    },
    images: {
      $apply: ({
        edges
      }) => edges === null || edges === void 0 ? void 0 : edges.map(_ref => {
        let {
          node: {
            urlOriginal,
            altText
          }
        } = _ref,
            rest = _objectWithoutProperties(_ref.node, _excluded2);

        return _objectSpread({
          url: urlOriginal,
          alt: altText
        }, rest);
      })
    },
    variants: {
      $apply: ({
        edges
      }) => edges === null || edges === void 0 ? void 0 : edges.map(_ref2 => {
        let {
          node: {
            entityId,
            productOptions
          }
        } = _ref2,
            rest = _objectWithoutProperties(_ref2.node, _excluded3);

        return _objectSpread({
          id: entityId,
          options: productOptions !== null && productOptions !== void 0 && productOptions.edges ? productOptions.edges.map(normalizeProductOption) : []
        }, rest);
      })
    },
    options: {
      $set: productOptions.edges ? productOptions === null || productOptions === void 0 ? void 0 : productOptions.edges.map(normalizeProductOption) : []
    },
    brand: {
      $apply: brand => brand !== null && brand !== void 0 && brand.entityId ? brand === null || brand === void 0 ? void 0 : brand.entityId : null
    },
    slug: {
      $set: path === null || path === void 0 ? void 0 : path.replace(/^\/+|\/+$/g, '')
    },
    price: {
      $set: {
        value: prices === null || prices === void 0 ? void 0 : prices.price.value,
        currencyCode: prices === null || prices === void 0 ? void 0 : prices.price.currencyCode
      }
    },
    $unset: ['entityId']
  });
}
function normalizePage(page) {
  return {
    id: String(page.id),
    name: page.name,
    is_visible: page.is_visible,
    sort_order: page.sort_order,
    body: page.body
  };
}
function normalizeCart(data) {
  var _data$discounts;

  return {
    id: data.id,
    customerId: String(data.customer_id),
    email: data.email,
    createdAt: data.created_time,
    currency: data.currency,
    taxesIncluded: data.tax_included,
    lineItems: [...data.line_items.physical_items.map(normalizeLineItem), ...data.line_items.digital_items.map(normalizeLineItem)],
    lineItemsSubtotalPrice: data.base_amount,
    subtotalPrice: data.base_amount + data.discount_amount,
    totalPrice: data.cart_amount,
    discounts: (_data$discounts = data.discounts) === null || _data$discounts === void 0 ? void 0 : _data$discounts.map(discount => ({
      value: discount.discounted_amount
    }))
  };
}

function normalizeLineItem(item) {
  return {
    id: item.id,
    variantId: String(item.variant_id),
    productId: String(item.product_id),
    name: item.name,
    quantity: item.quantity,
    variant: {
      id: String(item.variant_id),
      sku: item.sku,
      name: item.name,
      image: {
        url: item.image_url
      },
      requiresShipping: item.is_require_shipping,
      price: item.sale_price,
      listPrice: item.list_price
    },
    path: item.url.split('/')[3],
    discounts: item.discounts.map(discount => ({
      value: discount.discounted_amount
    }))
  };
}

function normalizeCategory(category) {
  return {
    id: `${category.entityId}`,
    name: category.name,
    slug: get_slug(category.path),
    path: category.path
  };
}

/***/ }),

/***/ 9520:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {


// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "dg": () => (/* binding */ createEndpoint),
  "Db": () => (/* binding */ getCommerceApi)
});

// UNUSED EXPORTS: CommerceAPICore, getEndpoint

;// CONCATENATED MODULE: ./framework/commerce/api/operations.ts
const noop = () => {
  throw new Error('Not implemented');
};

const OPERATIONS = ['login', 'getAllPages', 'getPage', 'getSiteInfo', 'getCustomerWishlist', 'getAllProductPaths', 'getAllProducts', 'getProduct'];
const defaultOperations = OPERATIONS.reduce((ops, k) => {
  ops[k] = noop;
  return ops;
}, {});
;// CONCATENATED MODULE: ./framework/commerce/api/index.ts
function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) { symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); } keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }


class CommerceAPICore {
  constructor(provider) {
    this.provider = provider;
  }

  getConfig(userConfig = {}) {
    return Object.entries(userConfig).reduce((cfg, [key, value]) => Object.assign(cfg, {
      [key]: value
    }), _objectSpread({}, this.provider.config));
  }

  setConfig(newConfig) {
    Object.assign(this.provider.config, newConfig);
  }

}
function getCommerceApi(customProvider) {
  const commerce = Object.assign(new CommerceAPICore(customProvider), defaultOperations);
  const ops = customProvider.operations;
  OPERATIONS.forEach(k => {
    const op = ops[k];

    if (op) {
      commerce[k] = op({
        commerce
      });
    }
  });
  return commerce;
}
function getEndpoint(commerce, context) {
  const cfg = commerce.getConfig(context.config);
  return function apiHandler(req, res) {
    var _context$options;

    return context.handler({
      req,
      res,
      commerce,
      config: cfg,
      handlers: context.handlers,
      options: (_context$options = context.options) !== null && _context$options !== void 0 ? _context$options : {}
    });
  };
}
const createEndpoint = endpoint => (commerce, context) => {
  return getEndpoint(commerce, _objectSpread(_objectSpread({}, endpoint), context));
};

/***/ }),

/***/ 1862:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {


// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "Z": () => (/* binding */ commerce)
});

// EXTERNAL MODULE: ./framework/commerce/api/index.ts + 1 modules
var api = __webpack_require__(9520);
// EXTERNAL MODULE: ./framework/commerce/utils/errors.ts
var errors = __webpack_require__(6370);
// EXTERNAL MODULE: external "@vercel/fetch"
var fetch_ = __webpack_require__(2937);
var fetch_default = /*#__PURE__*/__webpack_require__.n(fetch_);
;// CONCATENATED MODULE: ./framework/bigcommerce/api/utils/fetch.ts

/* harmony default export */ const fetch = (fetch_default()());
;// CONCATENATED MODULE: ./framework/bigcommerce/api/utils/fetch-graphql-api.ts
function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) { symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); } keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }




const fetchGraphqlApi = getConfig => async (query, {
  variables,
  preview
} = {}, fetchOptions) => {
  // log.warn(query)
  const config = getConfig();
  const res = await fetch(config.commerceUrl + (preview ? '/preview' : ''), _objectSpread(_objectSpread({}, fetchOptions), {}, {
    method: 'POST',
    headers: _objectSpread(_objectSpread({
      Authorization: `Bearer ${config.apiToken}`
    }, fetchOptions === null || fetchOptions === void 0 ? void 0 : fetchOptions.headers), {}, {
      'Content-Type': 'application/json'
    }),
    body: JSON.stringify({
      query,
      variables
    })
  }));
  const json = await res.json();

  if (json.errors) {
    var _json$errors;

    throw new errors/* FetcherError */.T4({
      errors: (_json$errors = json.errors) !== null && _json$errors !== void 0 ? _json$errors : [{
        message: 'Failed to fetch Bigcommerce API'
      }],
      status: res.status
    });
  }

  return {
    data: json.data,
    res
  };
};

/* harmony default export */ const fetch_graphql_api = (fetchGraphqlApi);
// EXTERNAL MODULE: ./framework/bigcommerce/api/utils/errors.ts
var utils_errors = __webpack_require__(4264);
;// CONCATENATED MODULE: ./framework/bigcommerce/api/utils/fetch-store-api.ts
function fetch_store_api_ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) { symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); } keys.push.apply(keys, symbols); } return keys; }

function fetch_store_api_objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { fetch_store_api_ownKeys(Object(source), true).forEach(function (key) { fetch_store_api_defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { fetch_store_api_ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function fetch_store_api_defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }




const fetchStoreApi = getConfig => async (endpoint, options) => {
  const config = getConfig();
  let res;

  try {
    res = await fetch(config.storeApiUrl + endpoint, fetch_store_api_objectSpread(fetch_store_api_objectSpread({}, options), {}, {
      headers: fetch_store_api_objectSpread(fetch_store_api_objectSpread({}, options === null || options === void 0 ? void 0 : options.headers), {}, {
        'Content-Type': 'application/json',
        'X-Auth-Token': config.storeApiToken,
        'X-Auth-Client': config.storeApiClientId
      })
    }));
  } catch (error) {
    throw new utils_errors/* BigcommerceNetworkError */.Ye(`Fetch to Bigcommerce failed: ${error.message}`);
  }

  const contentType = res.headers.get('Content-Type');
  const isJSON = contentType === null || contentType === void 0 ? void 0 : contentType.includes('application/json');

  if (!res.ok) {
    const data = isJSON ? await res.json() : await getTextOrNull(res);
    const headers = getRawHeaders(res);
    const msg = `Big Commerce API error (${res.status}) \nHeaders: ${JSON.stringify(headers, null, 2)}\n${typeof data === 'string' ? data : JSON.stringify(data, null, 2)}`;
    throw new utils_errors/* BigcommerceApiError */.zd(msg, res, data);
  }

  if (res.status !== 204 && !isJSON) {
    throw new utils_errors/* BigcommerceApiError */.zd(`Fetch to Bigcommerce API failed, expected JSON content but found: ${contentType}`, res);
  } // If something was removed, the response will be empty


  return res.status === 204 ? null : await res.json();
};

/* harmony default export */ const fetch_store_api = (fetchStoreApi);

function getRawHeaders(res) {
  const headers = {};
  res.headers.forEach((value, key) => {
    headers[key] = value;
  });
  return headers;
}

function getTextOrNull(res) {
  try {
    return res.text();
  } catch (err) {
    return null;
  }
}
;// CONCATENATED MODULE: ./framework/bigcommerce/api/utils/concat-cookie.ts
function concatHeader(prev, val) {
  if (!val) return prev;
  if (!prev) return val;
  if (Array.isArray(prev)) return prev.concat(String(val));
  prev = String(prev);
  if (Array.isArray(val)) return [prev].concat(val);
  return [prev, String(val)];
}
;// CONCATENATED MODULE: ./framework/bigcommerce/api/operations/login.ts

const loginMutation =
/* GraphQL */
`
  mutation login($email: String!, $password: String!) {
    login(email: $email, password: $password) {
      result
    }
  }
`;
function loginOperation({
  commerce
}) {
  async function login({
    query = loginMutation,
    variables,
    res: response,
    config
  }) {
    var _data$login;

    config = commerce.getConfig(config);
    const {
      data,
      res
    } = await config.fetch(query, {
      variables
    }); // Bigcommerce returns a Set-Cookie header with the auth cookie

    let cookie = res.headers.get('Set-Cookie');

    if (cookie && typeof cookie === 'string') {
      // In development, don't set a secure cookie or the browser will ignore it
      if (false) {}

      response.setHeader('Set-Cookie', concatHeader(response.getHeader('Set-Cookie'), cookie));
    }

    return {
      result: (_data$login = data.login) === null || _data$login === void 0 ? void 0 : _data$login.result
    };
  }

  return login;
}
;// CONCATENATED MODULE: ./framework/bigcommerce/api/operations/get-all-pages.ts
function getAllPagesOperation({
  commerce
}) {
  async function getAllPages({
    config,
    preview
  } = {}) {
    var _ref;

    const cfg = commerce.getConfig(config); // RecursivePartial forces the method to check for every prop in the data, which is
    // required in case there's a custom `url`

    const {
      data
    } = await cfg.storeApiFetch('/v3/content/pages');
    const pages = (_ref = data) !== null && _ref !== void 0 ? _ref : [];
    return {
      pages: preview ? pages : pages.filter(p => p.is_visible)
    };
  }

  return getAllPages;
}
// EXTERNAL MODULE: ./framework/bigcommerce/lib/normalize.ts + 2 modules
var normalize = __webpack_require__(7258);
;// CONCATENATED MODULE: ./framework/bigcommerce/api/operations/get-page.ts

function getPageOperation({
  commerce
}) {
  async function getPage({
    url,
    variables,
    config,
    preview
  }) {
    const cfg = commerce.getConfig(config);
    console.log("variables.id ", variables.id); // RecursivePartial forces the method to check for every prop in the data, which is
    // required in case there's a custom `url`

    const {
      data
    } = await cfg.storeApiFetch(url || `/v3/content/pages?id=${variables.id}&include=body`);
    const firstPage = data === null || data === void 0 ? void 0 : data[0];
    const page = firstPage;

    if (preview || page !== null && page !== void 0 && page.is_visible) {
      return {
        page: (0,normalize/* normalizePage */.ze)(page)
      };
    }

    return {};
  }

  return getPage;
}
;// CONCATENATED MODULE: ./framework/bigcommerce/api/utils/filter-edges.ts
function filterEdges(edges) {
  var _edges$filter;

  return (_edges$filter = edges === null || edges === void 0 ? void 0 : edges.filter(edge => !!edge)) !== null && _edges$filter !== void 0 ? _edges$filter : [];
}
;// CONCATENATED MODULE: ./framework/bigcommerce/api/fragments/category-tree.ts
const categoryTreeItemFragment =
/* GraphQL */
`
  fragment categoryTreeItem on CategoryTreeItem {
    entityId
    name
    path
    description
    productCount
  }
`;
;// CONCATENATED MODULE: ./framework/bigcommerce/api/operations/get-site-info.ts


 // Get 3 levels of categories

const getSiteInfoQuery =
/* GraphQL */
`
  query getSiteInfo {
    site {
      categoryTree {
        ...categoryTreeItem
        children {
          ...categoryTreeItem
          children {
            ...categoryTreeItem
          }
        }
      }
      brands {
        pageInfo {
          startCursor
          endCursor
        }
        edges {
          cursor
          node {
            entityId
            name
            defaultImage {
              urlOriginal
              altText
            }
            pageTitle
            metaDesc
            metaKeywords
            searchKeywords
            path
          }
        }
      }
    }
  }
  ${categoryTreeItemFragment}
`;
function getSiteInfoOperation({
  commerce
}) {
  async function getSiteInfo({
    query = getSiteInfoQuery,
    config
  } = {}) {
    var _data$site, _data$site$brands;

    const cfg = commerce.getConfig(config);
    const {
      data
    } = await cfg.fetch(query);
    const categories = data.site.categoryTree.map(normalize/* normalizeCategory */.Zh);
    const brands = (_data$site = data.site) === null || _data$site === void 0 ? void 0 : (_data$site$brands = _data$site.brands) === null || _data$site$brands === void 0 ? void 0 : _data$site$brands.edges;
    return {
      categories: categories !== null && categories !== void 0 ? categories : [],
      brands: filterEdges(brands)
    };
  }

  return getSiteInfo;
}
;// CONCATENATED MODULE: ./framework/bigcommerce/api/operations/get-customer-wishlist.ts
function getCustomerWishlistOperation({
  commerce
}) {
  async function getCustomerWishlist({
    config,
    variables,
    includeProducts
  }) {
    var _wishlist$items;

    config = commerce.getConfig(config);
    const {
      data = []
    } = await config.storeApiFetch(`/v3/wishlists?customer_id=${variables.customerId}`);
    const wishlist = data[0];

    if (includeProducts && wishlist !== null && wishlist !== void 0 && (_wishlist$items = wishlist.items) !== null && _wishlist$items !== void 0 && _wishlist$items.length) {
      var _wishlist$items2;

      const ids = (_wishlist$items2 = wishlist.items) === null || _wishlist$items2 === void 0 ? void 0 : _wishlist$items2.map(item => item !== null && item !== void 0 && item.product_id ? String(item === null || item === void 0 ? void 0 : item.product_id) : null).filter(id => !!id);

      if (ids !== null && ids !== void 0 && ids.length) {
        const graphqlData = await commerce.getAllProducts({
          variables: {
            first: 50,
            ids
          },
          config
        }); // Put the products in an object that we can use to get them by id

        const productsById = graphqlData.products.reduce((prods, p) => {
          prods[Number(p.id)] = p;
          return prods;
        }, {}); // Populate the wishlist items with the graphql products

        wishlist.items.forEach(item => {
          const product = item && productsById[item.product_id];

          if (item && product) {
            // @ts-ignore Fix this type when the wishlist type is properly defined
            item.product = product;
          }
        });
      }
    }

    return {
      wishlist: wishlist
    };
  }

  return getCustomerWishlist;
}
;// CONCATENATED MODULE: ./framework/bigcommerce/api/operations/get-all-product-paths.ts

const getAllProductPathsQuery =
/* GraphQL */
`
  query getAllProductPaths($first: Int = 100) {
    site {
      products(first: $first) {
        edges {
          node {
            path
          }
        }
      }
    }
  }
`;
function getAllProductPathsOperation({
  commerce
}) {
  async function getAllProductPaths({
    query = getAllProductPathsQuery,
    variables,
    config
  } = {}) {
    var _data$site, _data$site$products;

    config = commerce.getConfig(config); // RecursivePartial forces the method to check for every prop in the data, which is
    // required in case there's a custom `query`

    const {
      data
    } = await config.fetch(query, {
      variables
    });
    const products = (_data$site = data.site) === null || _data$site === void 0 ? void 0 : (_data$site$products = _data$site.products) === null || _data$site$products === void 0 ? void 0 : _data$site$products.edges;
    return {
      products: filterEdges(products).map(({
        node
      }) => node)
    };
  }

  return getAllProductPaths;
}
;// CONCATENATED MODULE: ./framework/bigcommerce/api/utils/set-product-locale-meta.ts
function setProductLocaleMeta(node) {
  var _node$localeMeta;

  if ((_node$localeMeta = node.localeMeta) !== null && _node$localeMeta !== void 0 && _node$localeMeta.edges) {
    node.localeMeta.edges = node.localeMeta.edges.filter(edge => {
      var _edge$node;

      const {
        key,
        value
      } = (_edge$node = edge === null || edge === void 0 ? void 0 : edge.node) !== null && _edge$node !== void 0 ? _edge$node : {};

      if (key && key in node) {
        ;
        node[key] = value;
        return false;
      }

      return true;
    });

    if (!node.localeMeta.edges.length) {
      delete node.localeMeta;
    }
  }
}
;// CONCATENATED MODULE: ./framework/bigcommerce/api/fragments/product.ts
const productPrices =
/* GraphQL */
`
  fragment productPrices on Prices {
    price {
      value
      currencyCode
    }
    salePrice {
      value
      currencyCode
    }
    retailPrice {
      value
      currencyCode
    }
  }
`;
const swatchOptionFragment =
/* GraphQL */
`
  fragment swatchOption on SwatchOptionValue {
    isDefault
    hexColors
  }
`;
const multipleChoiceOptionFragment =
/* GraphQL */
`
  fragment multipleChoiceOption on MultipleChoiceOption {
    values {
      edges {
        node {
          label
          ...swatchOption
        }
      }
    }
  }

  ${swatchOptionFragment}
`;
const productInfoFragment =
/* GraphQL */
`
  fragment productInfo on Product {
    entityId
    name
    path
    brand {
      entityId
    }
    description
    prices {
      ...productPrices
    }
    images {
      edges {
        node {
          urlOriginal
          altText
          isDefault
        }
      }
    }
    variants {
      edges {
        node {
          entityId
          defaultImage {
            urlOriginal
            altText
            isDefault
          }
        }
      }
    }
    productOptions {
      edges {
        node {
          __typename
          entityId
          displayName
          ...multipleChoiceOption
        }
      }
    }
    localeMeta: metafields(namespace: $locale, keys: ["name", "description"])
      @include(if: $hasLocale) {
      edges {
        node {
          key
          value
        }
      }
    }
  }

  ${productPrices}
  ${multipleChoiceOptionFragment}
`;
const productConnectionFragment =
/* GraphQL */
`
  fragment productConnnection on ProductConnection {
    pageInfo {
      startCursor
      endCursor
    }
    edges {
      cursor
      node {
        ...productInfo
      }
    }
  }

  ${productInfoFragment}
`;
;// CONCATENATED MODULE: ./framework/bigcommerce/api/operations/get-all-products.ts




const getAllProductsQuery =
/* GraphQL */
`
  query getAllProducts(
    $hasLocale: Boolean = false
    $locale: String = "null"
    $entityIds: [Int!]
    $first: Int = 10
    $products: Boolean = false
    $featuredProducts: Boolean = false
    $bestSellingProducts: Boolean = false
    $newestProducts: Boolean = false
  ) {
    site {
      products(first: $first, entityIds: $entityIds) @include(if: $products) {
        ...productConnnection
      }
      featuredProducts(first: $first) @include(if: $featuredProducts) {
        ...productConnnection
      }
      bestSellingProducts(first: $first) @include(if: $bestSellingProducts) {
        ...productConnnection
      }
      newestProducts(first: $first) @include(if: $newestProducts) {
        ...productConnnection
      }
    }
  }

  ${productConnectionFragment}
`;

function getProductsType(relevance) {
  switch (relevance) {
    case 'featured':
      return 'featuredProducts';

    case 'best_selling':
      return 'bestSellingProducts';

    case 'newest':
      return 'newestProducts';

    default:
      return 'products';
  }
}

function getAllProductsOperation({
  commerce
}) {
  async function getAllProducts({
    query = getAllProductsQuery,
    variables: vars = {},
    config: cfg
  } = {}) {
    var _data$site, _data$site$field;

    const config = commerce.getConfig(cfg);
    const {
      locale
    } = config;
    const field = getProductsType(vars.relevance);
    const variables = {
      locale,
      hasLocale: !!locale
    };
    variables[field] = true;
    if (vars.first) variables.first = vars.first;
    if (vars.ids) variables.entityIds = vars.ids.map(id => Number(id)); // RecursivePartial forces the method to check for every prop in the data, which is
    // required in case there's a custom `query`

    const {
      data
    } = await config.fetch(query, {
      variables
    });
    const edges = (_data$site = data.site) === null || _data$site === void 0 ? void 0 : (_data$site$field = _data$site[field]) === null || _data$site$field === void 0 ? void 0 : _data$site$field.edges;
    const products = filterEdges(edges);

    if (locale && config.applyLocale) {
      products.forEach(product => {
        if (product.node) setProductLocaleMeta(product.node);
      });
    }

    return {
      products: products.map(({
        node
      }) => (0,normalize/* normalizeProduct */.Op)(node))
    };
  }

  return getAllProducts;
}
;// CONCATENATED MODULE: ./framework/bigcommerce/api/operations/get-product.ts
const _excluded = ["slug"];

function _objectWithoutProperties(source, excluded) { if (source == null) return {}; var target = _objectWithoutPropertiesLoose(source, excluded); var key, i; if (Object.getOwnPropertySymbols) { var sourceSymbolKeys = Object.getOwnPropertySymbols(source); for (i = 0; i < sourceSymbolKeys.length; i++) { key = sourceSymbolKeys[i]; if (excluded.indexOf(key) >= 0) continue; if (!Object.prototype.propertyIsEnumerable.call(source, key)) continue; target[key] = source[key]; } } return target; }

function _objectWithoutPropertiesLoose(source, excluded) { if (source == null) return {}; var target = {}; var sourceKeys = Object.keys(source); var key, i; for (i = 0; i < sourceKeys.length; i++) { key = sourceKeys[i]; if (excluded.indexOf(key) >= 0) continue; target[key] = source[key]; } return target; }




const getProductQuery =
/* GraphQL */
`
  query getProduct(
    $hasLocale: Boolean = false
    $locale: String = "null"
    $path: String!
  ) {
    site {
      route(path: $path) {
        node {
          __typename
          ... on Product {
            ...productInfo
            variants {
              edges {
                node {
                  entityId
                  defaultImage {
                    urlOriginal
                    altText
                    isDefault
                  }
                  prices {
                    ...productPrices
                  }
                  inventory {
                    aggregated {
                      availableToSell
                      warningLevel
                    }
                    isInStock
                  }
                  productOptions {
                    edges {
                      node {
                        __typename
                        entityId
                        displayName
                        ...multipleChoiceOption
                      }
                    }
                  }
                }
              }
            }
          }
        }
      }
    }
  }

  ${productInfoFragment}
`; // TODO: See if this type is useful for defining the Product type
// export type ProductNode = Extract<
//   GetProductQuery['site']['route']['node'],
//   { __typename: 'Product' }
// >

function get_product_getAllProductPathsOperation({
  commerce
}) {
  async function getProduct(_ref) {
    var _data$site, _data$site$route;

    let {
      query = getProductQuery,
      variables: {
        slug
      },
      config: cfg
    } = _ref,
        vars = _objectWithoutProperties(_ref.variables, _excluded);

    const config = commerce.getConfig(cfg);
    const {
      locale
    } = config;
    const variables = {
      locale,
      hasLocale: !!locale,
      path: slug ? `/${slug}/` : vars.path
    };
    const {
      data
    } = await config.fetch(query, {
      variables
    });
    const product = (_data$site = data.site) === null || _data$site === void 0 ? void 0 : (_data$site$route = _data$site.route) === null || _data$site$route === void 0 ? void 0 : _data$site$route.node;

    if ((product === null || product === void 0 ? void 0 : product.__typename) === 'Product') {
      if (locale && config.applyLocale) {
        setProductLocaleMeta(product);
      }

      return {
        product: (0,normalize/* normalizeProduct */.Op)(product)
      };
    }

    return {};
  }

  return getProduct;
}
;// CONCATENATED MODULE: ./framework/bigcommerce/api/index.ts
var _process$env$BIGCOMME;












const API_URL = process.env.BIGCOMMERCE_STOREFRONT_API_URL;
const API_TOKEN = process.env.BIGCOMMERCE_STOREFRONT_API_TOKEN;
const STORE_API_URL = process.env.BIGCOMMERCE_STORE_API_URL;
const STORE_API_TOKEN = process.env.BIGCOMMERCE_STORE_API_TOKEN;
const STORE_API_CLIENT_ID = process.env.BIGCOMMERCE_STORE_API_CLIENT_ID;
const STORE_CHANNEL_ID = process.env.BIGCOMMERCE_CHANNEL_ID;
const STORE_URL = process.env.BIGCOMMERCE_STORE_URL;
const CLIENT_SECRET = process.env.BIGCOMMERCE_STORE_API_CLIENT_SECRET;
const STOREFRONT_HASH = process.env.BIGCOMMERCE_STORE_API_STORE_HASH;

if (!API_URL) {
  throw new Error(`The environment variable BIGCOMMERCE_STOREFRONT_API_URL is missing and it's required to access your store`);
}

if (!API_TOKEN) {
  throw new Error(`The environment variable BIGCOMMERCE_STOREFRONT_API_TOKEN is missing and it's required to access your store`);
}

if (!(STORE_API_URL && STORE_API_TOKEN && STORE_API_CLIENT_ID)) {
  throw new Error(`The environment variables BIGCOMMERCE_STORE_API_URL, BIGCOMMERCE_STORE_API_TOKEN, BIGCOMMERCE_STORE_API_CLIENT_ID have to be set in order to access the REST API of your store`);
}

const ONE_DAY = 60 * 60 * 24;
const config = {
  commerceUrl: API_URL,
  apiToken: API_TOKEN,
  customerCookie: 'SHOP_TOKEN',
  cartCookie: (_process$env$BIGCOMME = process.env.BIGCOMMERCE_CART_COOKIE) !== null && _process$env$BIGCOMME !== void 0 ? _process$env$BIGCOMME : 'bc_cartId',
  cartCookieMaxAge: ONE_DAY * 30,
  fetch: fetch_graphql_api(() => getCommerceApi().getConfig()),
  applyLocale: true,
  // REST API only
  storeApiUrl: STORE_API_URL,
  storeApiToken: STORE_API_TOKEN,
  storeApiClientId: STORE_API_CLIENT_ID,
  storeChannelId: STORE_CHANNEL_ID,
  storeUrl: STORE_URL,
  storeApiClientSecret: CLIENT_SECRET,
  storeHash: STOREFRONT_HASH,
  storeApiFetch: fetch_store_api(() => getCommerceApi().getConfig())
};
const operations = {
  login: loginOperation,
  getAllPages: getAllPagesOperation,
  getPage: getPageOperation,
  getSiteInfo: getSiteInfoOperation,
  getCustomerWishlist: getCustomerWishlistOperation,
  getAllProductPaths: getAllProductPathsOperation,
  getAllProducts: getAllProductsOperation,
  getProduct: get_product_getAllProductPathsOperation
};
const provider = {
  config,
  operations
};
function getCommerceApi(customProvider = provider) {
  return (0,api/* getCommerceApi */.Db)(customProvider);
}
;// CONCATENATED MODULE: ./lib/api/commerce.ts

/* harmony default export */ const commerce = (getCommerceApi());

/***/ })

};
;