exports.id = 644;
exports.ids = [644];
exports.modules = {

/***/ 1644:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(9297);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(4058);
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(classnames__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _components_ui__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(7079);
/* harmony import */ var _components_icons__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(8909);
/* harmony import */ var _framework_wishlist_use_add_item__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(1237);
/* harmony import */ var _framework_customer_use_customer__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(7951);
/* harmony import */ var _framework_wishlist_use_wishlist__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(2056);
/* harmony import */ var _framework_wishlist_use_remove_item__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(5295);
/* harmony import */ var _WishlistButton_module_css__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(8655);
/* harmony import */ var _WishlistButton_module_css__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(_WishlistButton_module_css__WEBPACK_IMPORTED_MODULE_8__);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(5282);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__);
const _excluded = ["productId", "variant", "className"];

function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) { symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); } keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

function _objectWithoutProperties(source, excluded) { if (source == null) return {}; var target = _objectWithoutPropertiesLoose(source, excluded); var key, i; if (Object.getOwnPropertySymbols) { var sourceSymbolKeys = Object.getOwnPropertySymbols(source); for (i = 0; i < sourceSymbolKeys.length; i++) { key = sourceSymbolKeys[i]; if (excluded.indexOf(key) >= 0) continue; if (!Object.prototype.propertyIsEnumerable.call(source, key)) continue; target[key] = source[key]; } } return target; }

function _objectWithoutPropertiesLoose(source, excluded) { if (source == null) return {}; var target = {}; var sourceKeys = Object.keys(source); var key, i; for (i = 0; i < sourceKeys.length; i++) { key = sourceKeys[i]; if (excluded.indexOf(key) >= 0) continue; target[key] = source[key]; } return target; }












const WishlistButton = _ref => {
  var _data$items;

  let {
    productId,
    variant,
    className
  } = _ref,
      props = _objectWithoutProperties(_ref, _excluded);

  const {
    data
  } = (0,_framework_wishlist_use_wishlist__WEBPACK_IMPORTED_MODULE_3__/* .default */ .Z)();
  const addItem = (0,_framework_wishlist_use_add_item__WEBPACK_IMPORTED_MODULE_4__/* .default */ .Z)();
  const removeItem = (0,_framework_wishlist_use_remove_item__WEBPACK_IMPORTED_MODULE_5__/* .default */ .Z)();
  const {
    data: customer
  } = (0,_framework_customer_use_customer__WEBPACK_IMPORTED_MODULE_6__/* .default */ .Z)();
  const {
    openModal,
    setModalView
  } = (0,_components_ui__WEBPACK_IMPORTED_MODULE_7__/* .useUI */ .l8)();
  const {
    0: loading,
    1: setLoading
  } = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(false); // @ts-ignore Wishlist is not always enabled

  const itemInWishlist = data === null || data === void 0 ? void 0 : (_data$items = data.items) === null || _data$items === void 0 ? void 0 : _data$items.find( // @ts-ignore Wishlist is not always enabled
  item => item.product_id === Number(productId) && item.variant_id === Number(variant.id));

  const handleWishlistChange = async e => {
    e.preventDefault();
    if (loading) return; // A login is required before adding an item to the wishlist

    if (!customer) {
      setModalView('LOGIN_VIEW');
      return openModal();
    }

    setLoading(true);

    try {
      if (itemInWishlist) {
        await removeItem({
          id: itemInWishlist.id
        });
      } else {
        await addItem({
          productId,
          variantId: variant === null || variant === void 0 ? void 0 : variant.id
        });
      }

      setLoading(false);
    } catch (err) {
      setLoading(false);
    }
  };

  return /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsx("button", _objectSpread(_objectSpread({
    "aria-label": "Add to wishlist",
    className: classnames__WEBPACK_IMPORTED_MODULE_1___default()((_WishlistButton_module_css__WEBPACK_IMPORTED_MODULE_8___default().root), className),
    onClick: handleWishlistChange
  }, props), {}, {
    children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsx(_components_icons__WEBPACK_IMPORTED_MODULE_9__/* .default */ .Z, {
      className: classnames__WEBPACK_IMPORTED_MODULE_1___default()((_WishlistButton_module_css__WEBPACK_IMPORTED_MODULE_8___default().icon), {
        [(_WishlistButton_module_css__WEBPACK_IMPORTED_MODULE_8___default().loading)]: loading,
        [(_WishlistButton_module_css__WEBPACK_IMPORTED_MODULE_8___default().inWishlist)]: itemInWishlist
      })
    })
  }));
};

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (WishlistButton);

/***/ }),

/***/ 8655:
/***/ ((module) => {

// Exports
module.exports = {
	"root": "WishlistButton_root__1LnSA",
	"icon": "WishlistButton_icon__30qku",
	"loading": "WishlistButton_loading__3NiRl",
	"inWishlist": "WishlistButton_inWishlist__1qKZc"
};


/***/ })

};
;