"use strict";
exports.id = 742;
exports.ids = [742];
exports.modules = {

/***/ 1742:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {


// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "Z": () => (/* binding */ icons_ArrowRight)
});

// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(9297);
;// CONCATENATED MODULE: ./assets/sleekshop-new-svg/arrow-right.svg
var _path;

function _extends() { _extends = Object.assign || function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; }; return _extends.apply(this, arguments); }



var SvgArrowRight = function SvgArrowRight(props) {
  return /*#__PURE__*/external_react_.createElement("svg", _extends({
    width: 14,
    height: 24,
    fill: "none",
    xmlns: "http://www.w3.org/2000/svg"
  }, props), _path || (_path = /*#__PURE__*/external_react_.createElement("path", {
    d: "M1.969.281.53 1.72 10.812 12 .533 22.281l1.437 1.438 11-11 .687-.719-.687-.719-11-11Z",
    fill: "#50585E"
  })));
};

/* harmony default export */ const arrow_right = (SvgArrowRight);
// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(5282);
;// CONCATENATED MODULE: ./components/icons/ArrowRight.tsx



const ArrowRight = _ref => {
  let props = Object.assign({}, _ref);
  return (
    /*#__PURE__*/
    // <Image
    //   src="https://cdn6.bigcommerce.com/s-hmhnh4h9/product_images/uploaded_images/arrow-r.png"
    //   width="27"
    //   height="47"
    // ></Image>
    jsx_runtime_.jsx(arrow_right, {})
  );
};

/* harmony default export */ const icons_ArrowRight = (ArrowRight);

/***/ })

};
;