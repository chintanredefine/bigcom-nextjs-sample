exports.id = 428;
exports.ids = [428];
exports.modules = {

/***/ 3372:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(9297);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
var _path, _path2;

function _extends() { _extends = Object.assign || function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; }; return _extends.apply(this, arguments); }



var SvgAddressesIcon = function SvgAddressesIcon(props) {
  return /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("svg", _extends({
    width: 24,
    height: 24,
    fill: "none",
    xmlns: "http://www.w3.org/2000/svg"
  }, props), _path || (_path = /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    d: "M12 2C8.13 2 5 5.13 5 9c0 5.25 7 13 7 13s7-7.75 7-13c0-3.87-3.13-7-7-7ZM7 9c0-2.76 2.24-5 5-5s5 2.24 5 5c0 2.88-2.88 7.19-5 9.88C9.92 16.21 7 11.85 7 9Z",
    fill: "#637381"
  })), _path2 || (_path2 = /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    d: "M12 11.5a2.5 2.5 0 1 0 0-5 2.5 2.5 0 0 0 0 5Z",
    fill: "#323232"
  })));
};

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (SvgAddressesIcon);

/***/ }),

/***/ 6258:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(9297);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
var _path;

function _extends() { _extends = Object.assign || function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; }; return _extends.apply(this, arguments); }



var SvgCart = function SvgCart(props) {
  return /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("svg", _extends({
    width: 18,
    height: 20,
    fill: "none",
    xmlns: "http://www.w3.org/2000/svg"
  }, props), _path || (_path = /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    d: "M9 .25c-.672 0-1.297.172-1.875.516a3.723 3.723 0 0 0-1.383 1.359A3.735 3.735 0 0 0 5.25 4v.75H1.547l-.047.703L.703 19.75h16.594L16.5 5.453l-.047-.703H12.75V4c0-.672-.172-1.297-.516-1.875a3.552 3.552 0 0 0-1.359-1.36A3.604 3.604 0 0 0 9 .25Zm0 1.5a2.17 2.17 0 0 1 1.594.656c.437.438.656.969.656 1.594v.75h-4.5V4c0-.625.219-1.156.656-1.594A2.17 2.17 0 0 1 9 1.75Zm-6.047 4.5H5.25V8.5h1.5V6.25h4.5V8.5h1.5V6.25h2.297l.656 12H2.297l.656-12Z",
    fill: "#50585E"
  })));
};

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (SvgCart);

/***/ }),

/***/ 6921:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "Z": () => (/* binding */ CartItem_CartItem)
});

// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(9297);
// EXTERNAL MODULE: external "classnames"
var external_classnames_ = __webpack_require__(4058);
var external_classnames_default = /*#__PURE__*/__webpack_require__.n(external_classnames_);
// EXTERNAL MODULE: ./node_modules/next/image.js
var next_image = __webpack_require__(5675);
// EXTERNAL MODULE: ./node_modules/next/link.js
var next_link = __webpack_require__(1664);
// EXTERNAL MODULE: ./components/cart/CartItem/CartItem.module.css
var CartItem_module = __webpack_require__(1321);
var CartItem_module_default = /*#__PURE__*/__webpack_require__.n(CartItem_module);
// EXTERNAL MODULE: ./components/ui/context.tsx
var context = __webpack_require__(7079);
// EXTERNAL MODULE: ./framework/commerce/product/use-price.tsx
var use_price = __webpack_require__(5420);
// EXTERNAL MODULE: ./framework/bigcommerce/cart/use-update-item.tsx + 1 modules
var use_update_item = __webpack_require__(2655);
// EXTERNAL MODULE: ./framework/bigcommerce/cart/use-remove-item.tsx + 1 modules
var use_remove_item = __webpack_require__(6769);
// EXTERNAL MODULE: ./components/ui/Quantity/Quantity.module.css
var Quantity_module = __webpack_require__(7089);
var Quantity_module_default = /*#__PURE__*/__webpack_require__.n(Quantity_module);
// EXTERNAL MODULE: ./components/icons/Cross.tsx
var Cross = __webpack_require__(4246);
// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(5282);
;// CONCATENATED MODULE: ./components/icons/Minus.tsx
function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) { symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); } keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }



const Minus = _ref => {
  let props = Object.assign({}, _ref);
  return /*#__PURE__*/jsx_runtime_.jsx("svg", _objectSpread(_objectSpread({
    width: "24",
    height: "24",
    viewBox: "0 0 24 24",
    fill: "none"
  }, props), {}, {
    children: /*#__PURE__*/jsx_runtime_.jsx("path", {
      d: "M5 12H19",
      stroke: "currentColor",
      strokeWidth: "1.5",
      strokeLinecap: "round",
      strokeLinejoin: "round"
    })
  }));
};

/* harmony default export */ const icons_Minus = (Minus);
;// CONCATENATED MODULE: ./components/icons/Plus.tsx
function Plus_ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) { symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); } keys.push.apply(keys, symbols); } return keys; }

function Plus_objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { Plus_ownKeys(Object(source), true).forEach(function (key) { Plus_defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { Plus_ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function Plus_defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }




const Plus = _ref => {
  let props = Object.assign({}, _ref);
  return /*#__PURE__*/(0,jsx_runtime_.jsxs)("svg", Plus_objectSpread(Plus_objectSpread({
    width: "24",
    height: "24",
    viewBox: "0 0 24 24",
    fill: "none"
  }, props), {}, {
    children: [/*#__PURE__*/jsx_runtime_.jsx("path", {
      d: "M12 5V19",
      stroke: "currentColor",
      strokeWidth: "1.5",
      strokeLinecap: "round",
      strokeLinejoin: "round"
    }), /*#__PURE__*/jsx_runtime_.jsx("path", {
      d: "M5 12H19",
      stroke: "currentColor",
      strokeWidth: "1.5",
      strokeLinecap: "round",
      strokeLinejoin: "round"
    })]
  }));
};

/* harmony default export */ const icons_Plus = (Plus);
;// CONCATENATED MODULE: ./components/ui/Quantity/Quantity.tsx







const Quantity = ({
  value,
  increase,
  decrease,
  handleChange,
  handleRemove,
  max = 6
}) => {
  return /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
    className: "flex flex-row h-9",
    children: [/*#__PURE__*/jsx_runtime_.jsx("button", {
      className: (Quantity_module_default()).actions,
      onClick: handleRemove,
      children: /*#__PURE__*/jsx_runtime_.jsx(Cross/* default */.Z, {
        width: 20,
        height: 20
      })
    }), /*#__PURE__*/jsx_runtime_.jsx("label", {
      className: "w-full border-accent-2 border ml-2",
      children: /*#__PURE__*/jsx_runtime_.jsx("input", {
        className: (Quantity_module_default()).input,
        onChange: e => Number(e.target.value) < max + 1 ? handleChange(e) : () => {},
        value: value,
        type: "number",
        max: max,
        min: "0",
        readOnly: true
      })
    }), /*#__PURE__*/jsx_runtime_.jsx("button", {
      type: "button",
      onClick: decrease,
      className: (Quantity_module_default()).actions,
      style: {
        marginLeft: '-1px'
      },
      disabled: value <= 1,
      children: /*#__PURE__*/jsx_runtime_.jsx(icons_Minus, {
        width: 18,
        height: 18
      })
    }), /*#__PURE__*/jsx_runtime_.jsx("button", {
      type: "button",
      onClick: increase,
      className: external_classnames_default()((Quantity_module_default()).actions),
      style: {
        marginLeft: '-1px'
      },
      disabled: value < 1 || value >= max,
      children: /*#__PURE__*/jsx_runtime_.jsx(icons_Plus, {
        width: 18,
        height: 18
      })
    })]
  });
};

/* harmony default export */ const Quantity_Quantity = (Quantity);
;// CONCATENATED MODULE: ./components/cart/CartItem/CartItem.tsx
const _excluded = ["item", "variant", "currencyCode"];

function CartItem_ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) { symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); } keys.push.apply(keys, symbols); } return keys; }

function CartItem_objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { CartItem_ownKeys(Object(source), true).forEach(function (key) { CartItem_defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { CartItem_ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function CartItem_defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

function _objectWithoutProperties(source, excluded) { if (source == null) return {}; var target = _objectWithoutPropertiesLoose(source, excluded); var key, i; if (Object.getOwnPropertySymbols) { var sourceSymbolKeys = Object.getOwnPropertySymbols(source); for (i = 0; i < sourceSymbolKeys.length; i++) { key = sourceSymbolKeys[i]; if (excluded.indexOf(key) >= 0) continue; if (!Object.prototype.propertyIsEnumerable.call(source, key)) continue; target[key] = source[key]; } } return target; }

function _objectWithoutPropertiesLoose(source, excluded) { if (source == null) return {}; var target = {}; var sourceKeys = Object.keys(source); var key, i; for (i = 0; i < sourceKeys.length; i++) { key = sourceKeys[i]; if (excluded.indexOf(key) >= 0) continue; target[key] = source[key]; } return target; }














const CartItem = _ref => {
  let {
    item,
    variant = 'default',
    currencyCode
  } = _ref,
      rest = _objectWithoutProperties(_ref, _excluded);

  const {
    closeSidebarIfPresent
  } = (0,context/* useUI */.l8)();
  const {
    0: removing,
    1: setRemoving
  } = (0,external_react_.useState)(false);
  const {
    0: quantity,
    1: setQuantity
  } = (0,external_react_.useState)(item.quantity);
  const removeItem = (0,use_remove_item/* default */.Z)();
  const updateItem = (0,use_update_item/* default */.Z)({
    item
  });
  const {
    price
  } = (0,use_price/* default */.ZP)({
    amount: item.variant.price * item.quantity,
    baseAmount: item.variant.listPrice * item.quantity,
    currencyCode
  });

  const handleChange = async ({
    target: {
      value
    }
  }) => {
    setQuantity(Number(value));
    await updateItem({
      quantity: Number(value)
    });
  };

  const increaseQuantity = async (n = 1) => {
    const val = Number(quantity) + n;
    setQuantity(val);
    await updateItem({
      quantity: val
    });
  };

  const handleRemove = async () => {
    setRemoving(true);

    try {
      await removeItem(item);
    } catch (error) {
      setRemoving(false);
    }
  }; // TODO: Add a type for this


  const options = item.options;
  (0,external_react_.useEffect)(() => {
    // Reset the quantity state if the item quantity changes
    if (item.quantity !== Number(quantity)) {
      setQuantity(item.quantity);
    } // TODO: currently not including quantity in deps is intended, but we should
    // do this differently as it could break easily
    // eslint-disable-next-line react-hooks/exhaustive-deps

  }, [item.quantity]);
  return /*#__PURE__*/(0,jsx_runtime_.jsxs)("li", CartItem_objectSpread(CartItem_objectSpread({
    className: external_classnames_default()((CartItem_module_default()).root, {
      'opacity-50 pointer-events-none': removing
    })
  }, rest), {}, {
    children: [/*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
      className: "flex flex-row space-x-4 py-4",
      children: [/*#__PURE__*/jsx_runtime_.jsx("div", {
        className: "w-16 h-16 bg-violet relative overflow-hidden cursor-pointer z-0",
        children: /*#__PURE__*/jsx_runtime_.jsx(next_link.default, {
          href: `/product/${item.path}`,
          children: /*#__PURE__*/jsx_runtime_.jsx("a", {
            children: /*#__PURE__*/jsx_runtime_.jsx(next_image.default, {
              onClick: () => closeSidebarIfPresent(),
              className: (CartItem_module_default()).productImage,
              width: 150,
              height: 150,
              src: item.variant.image.url,
              alt: item.variant.image.altText,
              unoptimized: true
            })
          })
        })
      }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
        className: "flex-1 flex flex-col text-base",
        children: [/*#__PURE__*/jsx_runtime_.jsx(next_link.default, {
          href: `/product/${item.path}`,
          children: /*#__PURE__*/jsx_runtime_.jsx("a", {
            children: /*#__PURE__*/jsx_runtime_.jsx("span", {
              className: (CartItem_module_default()).productName,
              onClick: () => closeSidebarIfPresent(),
              children: item.name
            })
          })
        }), options && options.length > 0 && /*#__PURE__*/jsx_runtime_.jsx("div", {
          className: "flex items-center pb-1",
          children: options.map((option, i) => /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
            className: "text-sm font-semibold text-accent-7 inline-flex items-center justify-center",
            children: [option.name, option.name === 'Color' ? /*#__PURE__*/jsx_runtime_.jsx("span", {
              className: "mx-2 rounded-full bg-transparent border w-5 h-5 p-1 text-accent-9 inline-flex items-center justify-center overflow-hidden",
              style: {
                backgroundColor: `${option.value}`
              }
            }) : /*#__PURE__*/jsx_runtime_.jsx("span", {
              className: "mx-2 rounded-full bg-transparent border h-5 p-1 text-accent-9 inline-flex items-center justify-center overflow-hidden",
              children: option.value
            }), i === options.length - 1 ? '' : /*#__PURE__*/jsx_runtime_.jsx("span", {
              className: "mr-3"
            })]
          }, `${item.id}-${option.name}`))
        }), variant === 'display' && /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
          className: "text-sm tracking-wider",
          children: [quantity, "x"]
        })]
      }), /*#__PURE__*/jsx_runtime_.jsx("div", {
        className: "flex flex-col justify-between space-y-2 text-sm",
        children: /*#__PURE__*/jsx_runtime_.jsx("span", {
          children: price
        })
      })]
    }), variant === 'default' && /*#__PURE__*/jsx_runtime_.jsx(Quantity_Quantity, {
      value: quantity,
      handleRemove: handleRemove,
      handleChange: handleChange,
      increase: () => increaseQuantity(1),
      decrease: () => increaseQuantity(-1)
    })]
  }));
};

/* harmony default export */ const CartItem_CartItem = (CartItem);

/***/ }),

/***/ 2029:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(4058);
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(classnames__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _components_ui__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(2361);
/* harmony import */ var _components_ui__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(1180);
/* harmony import */ var _PaymentMethodView_module_css__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(1466);
/* harmony import */ var _PaymentMethodView_module_css__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_PaymentMethodView_module_css__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(5282);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__);
 // import AddPaymentMethod from '@framework/paymentmethod/add-paymentmethod'







const PaymentMethodView = () => {
  async function handleSubmit(event) {
    event.preventDefault();
  }

  return /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__.Fragment, {
    children: /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxs)("form", {
      className: "h-full",
      onSubmit: handleSubmit,
      children: [/*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxs)("div", {
        className: "px-4 sm:px-6 flex-1",
        children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__.jsx(_components_ui__WEBPACK_IMPORTED_MODULE_2__/* .default */ .Z, {
          variant: "sectionHeading",
          children: " Payment Method"
        }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxs)("div", {
          children: [/*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxs)("div", {
            className: (_PaymentMethodView_module_css__WEBPACK_IMPORTED_MODULE_3___default().fieldset),
            children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__.jsx("label", {
              className: (_PaymentMethodView_module_css__WEBPACK_IMPORTED_MODULE_3___default().label),
              children: "Cardholder Name"
            }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__.jsx("input", {
              name: "cardHolder",
              className: (_PaymentMethodView_module_css__WEBPACK_IMPORTED_MODULE_3___default().input)
            })]
          }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxs)("div", {
            className: "grid gap-3 grid-flow-row grid-cols-12",
            children: [/*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxs)("div", {
              className: classnames__WEBPACK_IMPORTED_MODULE_0___default()((_PaymentMethodView_module_css__WEBPACK_IMPORTED_MODULE_3___default().fieldset), 'col-span-7'),
              children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__.jsx("label", {
                className: (_PaymentMethodView_module_css__WEBPACK_IMPORTED_MODULE_3___default().label),
                children: "Card Number"
              }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__.jsx("input", {
                name: "cardNumber",
                className: (_PaymentMethodView_module_css__WEBPACK_IMPORTED_MODULE_3___default().input)
              })]
            }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxs)("div", {
              className: classnames__WEBPACK_IMPORTED_MODULE_0___default()((_PaymentMethodView_module_css__WEBPACK_IMPORTED_MODULE_3___default().fieldset), 'col-span-3'),
              children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__.jsx("label", {
                className: (_PaymentMethodView_module_css__WEBPACK_IMPORTED_MODULE_3___default().label),
                children: "Expires"
              }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__.jsx("input", {
                name: "cardExpireDate",
                className: (_PaymentMethodView_module_css__WEBPACK_IMPORTED_MODULE_3___default().input),
                placeholder: "MM/YY"
              })]
            }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxs)("div", {
              className: classnames__WEBPACK_IMPORTED_MODULE_0___default()((_PaymentMethodView_module_css__WEBPACK_IMPORTED_MODULE_3___default().fieldset), 'col-span-2'),
              children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__.jsx("label", {
                className: (_PaymentMethodView_module_css__WEBPACK_IMPORTED_MODULE_3___default().label),
                children: "CVC"
              }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__.jsx("input", {
                name: "cardCvc",
                className: (_PaymentMethodView_module_css__WEBPACK_IMPORTED_MODULE_3___default().input)
              })]
            })]
          }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__.jsx("hr", {
            className: "border-accent-2 my-6"
          }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxs)("div", {
            className: "grid gap-3 grid-flow-row grid-cols-12",
            children: [/*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxs)("div", {
              className: classnames__WEBPACK_IMPORTED_MODULE_0___default()((_PaymentMethodView_module_css__WEBPACK_IMPORTED_MODULE_3___default().fieldset), 'col-span-6'),
              children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__.jsx("label", {
                className: (_PaymentMethodView_module_css__WEBPACK_IMPORTED_MODULE_3___default().label),
                children: "First Name"
              }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__.jsx("input", {
                name: "firstName",
                className: (_PaymentMethodView_module_css__WEBPACK_IMPORTED_MODULE_3___default().input)
              })]
            }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxs)("div", {
              className: classnames__WEBPACK_IMPORTED_MODULE_0___default()((_PaymentMethodView_module_css__WEBPACK_IMPORTED_MODULE_3___default().fieldset), 'col-span-6'),
              children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__.jsx("label", {
                className: (_PaymentMethodView_module_css__WEBPACK_IMPORTED_MODULE_3___default().label),
                children: "Last Name"
              }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__.jsx("input", {
                name: "lastName",
                className: (_PaymentMethodView_module_css__WEBPACK_IMPORTED_MODULE_3___default().input)
              })]
            })]
          }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxs)("div", {
            className: (_PaymentMethodView_module_css__WEBPACK_IMPORTED_MODULE_3___default().fieldset),
            children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__.jsx("label", {
              className: (_PaymentMethodView_module_css__WEBPACK_IMPORTED_MODULE_3___default().label),
              children: "Company (Optional)"
            }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__.jsx("input", {
              name: "company",
              className: (_PaymentMethodView_module_css__WEBPACK_IMPORTED_MODULE_3___default().input)
            })]
          }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxs)("div", {
            className: (_PaymentMethodView_module_css__WEBPACK_IMPORTED_MODULE_3___default().fieldset),
            children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__.jsx("label", {
              className: (_PaymentMethodView_module_css__WEBPACK_IMPORTED_MODULE_3___default().label),
              children: "Street and House Number"
            }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__.jsx("input", {
              name: "streetNumber",
              className: (_PaymentMethodView_module_css__WEBPACK_IMPORTED_MODULE_3___default().input)
            })]
          }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxs)("div", {
            className: (_PaymentMethodView_module_css__WEBPACK_IMPORTED_MODULE_3___default().fieldset),
            children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__.jsx("label", {
              className: (_PaymentMethodView_module_css__WEBPACK_IMPORTED_MODULE_3___default().label),
              children: "Apartment, Suite, Etc. (Optional)"
            }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__.jsx("input", {
              className: (_PaymentMethodView_module_css__WEBPACK_IMPORTED_MODULE_3___default().input),
              name: "apartment"
            })]
          }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxs)("div", {
            className: "grid gap-3 grid-flow-row grid-cols-12",
            children: [/*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxs)("div", {
              className: classnames__WEBPACK_IMPORTED_MODULE_0___default()((_PaymentMethodView_module_css__WEBPACK_IMPORTED_MODULE_3___default().fieldset), 'col-span-6'),
              children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__.jsx("label", {
                className: (_PaymentMethodView_module_css__WEBPACK_IMPORTED_MODULE_3___default().label),
                children: "Postal Code"
              }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__.jsx("input", {
                name: "zipCode",
                className: (_PaymentMethodView_module_css__WEBPACK_IMPORTED_MODULE_3___default().input)
              })]
            }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxs)("div", {
              className: classnames__WEBPACK_IMPORTED_MODULE_0___default()((_PaymentMethodView_module_css__WEBPACK_IMPORTED_MODULE_3___default().fieldset), 'col-span-6'),
              children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__.jsx("label", {
                className: (_PaymentMethodView_module_css__WEBPACK_IMPORTED_MODULE_3___default().label),
                children: "City"
              }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__.jsx("input", {
                name: "city",
                className: (_PaymentMethodView_module_css__WEBPACK_IMPORTED_MODULE_3___default().input)
              })]
            })]
          }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxs)("div", {
            className: (_PaymentMethodView_module_css__WEBPACK_IMPORTED_MODULE_3___default().fieldset),
            children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__.jsx("label", {
              className: (_PaymentMethodView_module_css__WEBPACK_IMPORTED_MODULE_3___default().label),
              children: "Country/Region"
            }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__.jsx("select", {
              name: "country",
              className: (_PaymentMethodView_module_css__WEBPACK_IMPORTED_MODULE_3___default().select),
              children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__.jsx("option", {
                children: "Hong Kong"
              })
            })]
          })]
        })]
      }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__.jsx("div", {
        className: "sticky z-20 bottom-0 w-full right-0 left-0 py-12 bg-accent-0 border-t border-accent-2 px-6",
        children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__.jsx(_components_ui__WEBPACK_IMPORTED_MODULE_4__/* .default */ .Z, {
          type: "submit",
          width: "100%",
          variant: "ghost",
          children: "Continue"
        })
      })]
    })
  });
};

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (PaymentMethodView);

/***/ }),

/***/ 732:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _PaymentWidget_module_css__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(7035);
/* harmony import */ var _PaymentWidget_module_css__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_PaymentWidget_module_css__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _components_icons__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(4021);
/* harmony import */ var _components_icons__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(6245);
/* harmony import */ var _components_icons__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(2760);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5282);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);





const PaymentWidget = ({
  onClick,
  isValid
}) => {
  /* Shipping Address
  Only available with checkout set to true -
  This means that the provider does offer checkout functionality. */
  return /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
    onClick: onClick,
    className: (_PaymentWidget_module_css__WEBPACK_IMPORTED_MODULE_1___default().root),
    children: [/*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
      className: "flex flex-1 items-center",
      children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_icons__WEBPACK_IMPORTED_MODULE_2__/* .default */ .Z, {
        className: "w-5 flex"
      }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
        className: "ml-5 text-sm text-center font-medium",
        children: "Add Payment Method"
      })]
    }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
      children: isValid ? /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_icons__WEBPACK_IMPORTED_MODULE_3__/* .default */ .Z, {}) : /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_icons__WEBPACK_IMPORTED_MODULE_4__/* .default */ .Z, {})
    })]
  });
};

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (PaymentWidget);

/***/ }),

/***/ 6428:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "Z": () => (/* binding */ Layout_Layout)
});

// EXTERNAL MODULE: external "classnames"
var external_classnames_ = __webpack_require__(4058);
var external_classnames_default = /*#__PURE__*/__webpack_require__.n(external_classnames_);
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(9297);
var external_react_default = /*#__PURE__*/__webpack_require__.n(external_react_);
// EXTERNAL MODULE: ./node_modules/next/dynamic.js
var dynamic = __webpack_require__(5152);
// EXTERNAL MODULE: external "next/router"
var router_ = __webpack_require__(6731);
// EXTERNAL MODULE: ./framework/commerce/index.tsx
var commerce = __webpack_require__(5112);
// EXTERNAL MODULE: ./framework/bigcommerce/cart/use-cart.tsx + 1 modules
var use_cart = __webpack_require__(3958);
// EXTERNAL MODULE: ./framework/bigcommerce/cart/use-add-item.tsx + 1 modules
var use_add_item = __webpack_require__(3889);
// EXTERNAL MODULE: ./framework/bigcommerce/cart/use-update-item.tsx + 1 modules
var use_update_item = __webpack_require__(2655);
// EXTERNAL MODULE: ./framework/bigcommerce/cart/use-remove-item.tsx + 1 modules
var use_remove_item = __webpack_require__(6769);
// EXTERNAL MODULE: ./framework/bigcommerce/wishlist/use-wishlist.tsx + 1 modules
var use_wishlist = __webpack_require__(2056);
// EXTERNAL MODULE: ./framework/bigcommerce/wishlist/use-add-item.tsx + 1 modules
var wishlist_use_add_item = __webpack_require__(1237);
// EXTERNAL MODULE: ./framework/bigcommerce/wishlist/use-remove-item.tsx + 1 modules
var wishlist_use_remove_item = __webpack_require__(5295);
// EXTERNAL MODULE: ./framework/commerce/utils/use-hook.ts + 2 modules
var use_hook = __webpack_require__(250);
// EXTERNAL MODULE: ./framework/commerce/utils/default-fetcher.ts
var default_fetcher = __webpack_require__(3449);
;// CONCATENATED MODULE: ./framework/commerce/paymentmethod/get-paymentmethod.tsx
function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) { symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); } keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }



const fetcher = default_fetcher/* SWRFetcher */.DO;

const fn = provider => {
  var _provider$wishlist;

  return (_provider$wishlist = provider.wishlist) === null || _provider$wishlist === void 0 ? void 0 : _provider$wishlist.useWishlist;
};

const getPaymentMethod = (...args) => {
  const hook = (0,use_hook/* useHook */.dV)(fn);
  return (0,use_hook/* useSWRHook */.Lz)(_objectSpread({
    fetcher
  }, hook))(...args);
};

/* harmony default export */ const get_paymentmethod = (getPaymentMethod);
// EXTERNAL MODULE: ./framework/bigcommerce/customer/use-customer.tsx + 1 modules
var use_customer = __webpack_require__(7951);
;// CONCATENATED MODULE: ./framework/bigcommerce/paymentmethod/get-paymentmethod.tsx
function get_paymentmethod_ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) { symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); } keys.push.apply(keys, symbols); } return keys; }

function get_paymentmethod_objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { get_paymentmethod_ownKeys(Object(source), true).forEach(function (key) { get_paymentmethod_defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { get_paymentmethod_ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function get_paymentmethod_defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }




/* harmony default export */ const paymentmethod_get_paymentmethod = (get_paymentmethod);
const handler = {
  fetchOptions: {
    url: '/api/paymentmethod',
    method: 'GET'
  },

  async fetcher({
    input: {
      customerId,
      includeProducts
    },
    options,
    fetch
  }) {
    if (!customerId) return null; // Use a dummy base as we only care about the relative path

    const url = new URL(options.url, 'http://a');
    if (includeProducts) url.searchParams.set('products', '1');
    return fetch({
      url: url.pathname + url.search,
      method: options.method
    });
  },

  useHook: ({
    useData
  }) => input => {
    const {
      data: customer
    } = (0,use_customer/* default */.Z)();
    const response = useData({
      input: [['customerId', customer === null || customer === void 0 ? void 0 : customer.entityId], ['includeProducts', input === null || input === void 0 ? void 0 : input.includeProducts]],
      swrOptions: get_paymentmethod_objectSpread({
        revalidateOnFocus: false
      }, input === null || input === void 0 ? void 0 : input.swrOptions)
    });
    return (0,external_react_.useMemo)(() => Object.create(response, {
      isEmpty: {
        get() {
          var _response$data, _response$data$items;

          return (((_response$data = response.data) === null || _response$data === void 0 ? void 0 : (_response$data$items = _response$data.items) === null || _response$data$items === void 0 ? void 0 : _response$data$items.length) || 0) <= 0;
        },

        enumerable: true
      }
    }), [response]);
  }
};
// EXTERNAL MODULE: ./framework/commerce/utils/errors.ts
var errors = __webpack_require__(6370);
;// CONCATENATED MODULE: ./framework/bigcommerce/paymentmethod/add-paymentmethod.tsx





/* harmony default export */ const add_paymentmethod = ((/* unused pure expression or super */ null && (addPaymentMethod)));
const add_paymentmethod_handler = {
  fetchOptions: {
    url: '/api/addpaymentmethod',
    method: 'POST'
  },
  useHook: ({
    fetch
  }) => () => {
    const {
      data: customer
    } = (0,use_customer/* default */.Z)();
    const {
      revalidate
    } = paymentmethod_get_paymentmethod();
    return (0,external_react_.useCallback)(async function addItem(item) {
      // console.log('payment Method addition process is going on ')
      if (!customer) {
        // A signed customer is required in order to have a wishlist
        throw new errors/* CommerceError */.yG({
          message: 'Signed customer not found'
        });
      } // TODO: add validations before doing the fetch


      const data = await fetch({
        input: {
          item
        }
      });
      await revalidate();
      return data;
    }, [fetch, revalidate, customer]);
  }
};
;// CONCATENATED MODULE: ./framework/bigcommerce/paymentmethod/remove-paymentmethod.tsx





/* harmony default export */ const remove_paymentmethod = ((/* unused pure expression or super */ null && (useRemoveItem)));
const remove_paymentmethod_handler = {
  fetchOptions: {
    url: '/api/wishlist',
    method: 'DELETE'
  },
  useHook: ({
    fetch
  }) => ({
    wishlist
  } = {}) => {
    const {
      data: customer
    } = (0,use_customer/* default */.Z)();
    const {
      revalidate
    } = paymentmethod_get_paymentmethod(wishlist);
    return (0,external_react_.useCallback)(async function removeItem(input) {
      if (!customer) {
        // A signed customer is required in order to have a wishlist
        throw new errors/* CommerceError */.yG({
          message: 'Signed customer not found'
        });
      }

      const data = await fetch({
        input: {
          itemId: String(input.id)
        }
      });
      await revalidate();
      return data;
    }, [fetch, revalidate, customer]);
  }
};
// EXTERNAL MODULE: ./framework/bigcommerce/product/use-search.tsx + 1 modules
var use_search = __webpack_require__(6371);
;// CONCATENATED MODULE: ./framework/commerce/auth/use-login.tsx
function use_login_ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) { symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); } keys.push.apply(keys, symbols); } return keys; }

function use_login_objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { use_login_ownKeys(Object(source), true).forEach(function (key) { use_login_defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { use_login_ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function use_login_defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }



const use_login_fetcher = default_fetcher/* mutationFetcher */.B5;

const use_login_fn = provider => {
  var _provider$auth;

  return (_provider$auth = provider.auth) === null || _provider$auth === void 0 ? void 0 : _provider$auth.useLogin;
};

const useLogin = (...args) => {
  const hook = (0,use_hook/* useHook */.dV)(use_login_fn);
  return (0,use_hook/* useMutationHook */.wf)(use_login_objectSpread({
    fetcher: use_login_fetcher
  }, hook))(...args);
};

/* harmony default export */ const use_login = (useLogin);
;// CONCATENATED MODULE: ./framework/bigcommerce/auth/use-login.tsx
function auth_use_login_ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) { symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); } keys.push.apply(keys, symbols); } return keys; }

function auth_use_login_objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { auth_use_login_ownKeys(Object(source), true).forEach(function (key) { auth_use_login_defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { auth_use_login_ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function auth_use_login_defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }





/* harmony default export */ const auth_use_login = (use_login);
const use_login_handler = {
  fetchOptions: {
    url: '/api/login',
    method: 'POST'
  },

  async fetcher({
    input: {
      email,
      password
    },
    options,
    fetch
  }) {
    if (!(email && password)) {
      throw new errors/* CommerceError */.yG({
        message: 'An email and password are required to login'
      });
    }

    return fetch(auth_use_login_objectSpread(auth_use_login_objectSpread({}, options), {}, {
      body: {
        email,
        password
      }
    }));
  },

  useHook: ({
    fetch
  }) => () => {
    const {
      revalidate
    } = (0,use_customer/* default */.Z)();
    return (0,external_react_.useCallback)(async function login(input) {
      const data = await fetch({
        input
      });
      await revalidate();
      return data;
    }, [fetch, revalidate]);
  }
};
// EXTERNAL MODULE: ./framework/bigcommerce/auth/use-logout.tsx + 1 modules
var use_logout = __webpack_require__(4626);
// EXTERNAL MODULE: ./framework/bigcommerce/auth/use-signup.tsx + 1 modules
var use_signup = __webpack_require__(5301);
;// CONCATENATED MODULE: ./framework/bigcommerce/fetcher.ts


async function getText(res) {
  try {
    return (await res.text()) || res.statusText;
  } catch (error) {
    return res.statusText;
  }
}

async function getError(res) {
  var _res$headers$get;

  if ((_res$headers$get = res.headers.get('Content-Type')) !== null && _res$headers$get !== void 0 && _res$headers$get.includes('application/json')) {
    const data = await res.json();
    return new errors/* FetcherError */.T4({
      errors: data.errors,
      status: res.status
    });
  }

  return new errors/* FetcherError */.T4({
    message: await getText(res),
    status: res.status
  });
}

const fetcher_fetcher = async ({
  url,
  method = 'GET',
  variables,
  body: bodyObj
}) => {
  const hasBody = Boolean(variables || bodyObj);
  const body = hasBody ? JSON.stringify(variables ? {
    variables
  } : bodyObj) : undefined;
  const headers = hasBody ? {
    'Content-Type': 'application/json'
  } : undefined;
  const res = await fetch(url, {
    method,
    body,
    headers
  });

  if (res.ok) {
    const {
      data
    } = await res.json();
    return data;
  }

  throw await getError(res);
};

/* harmony default export */ const bigcommerce_fetcher = (fetcher_fetcher);
;// CONCATENATED MODULE: ./framework/bigcommerce/provider.ts
















const bigcommerceProvider = {
  locale: 'en-us',
  cartCookie: 'bc_cartId',
  fetcher: bigcommerce_fetcher,
  cart: {
    useCart: use_cart/* handler */.y,
    useAddItem: use_add_item/* handler */.y,
    useUpdateItem: use_update_item/* handler */.y,
    useRemoveItem: use_remove_item/* handler */.y
  },
  wishlist: {
    useWishlist: use_wishlist/* handler */.y,
    useAddItem: wishlist_use_add_item/* handler */.y,
    useRemoveItem: wishlist_use_remove_item/* handler */.y
  },
  paymentmethod: {
    getPaymentMethod: handler,
    addPaymentMethod: add_paymentmethod_handler,
    removePaymentMethod: remove_paymentmethod_handler
  },
  customer: {
    useCustomer: use_customer/* handler */.y
  },
  products: {
    useSearch: use_search/* handler */.y
  },
  auth: {
    useLogin: use_login_handler,
    useLogout: use_logout/* handler */.y,
    useSignup: use_signup/* handler */.y
  }
};
;// CONCATENATED MODULE: ./framework/bigcommerce/index.tsx



const CommerceProvider = (0,commerce/* getCommerceProvider */.DX)(bigcommerceProvider);
const useCommerce = () => useCoreCommerce();
// EXTERNAL MODULE: ./components/ui/context.tsx
var context = __webpack_require__(7079);
// EXTERNAL MODULE: ./node_modules/next/link.js
var next_link = __webpack_require__(1664);
// EXTERNAL MODULE: ./components/common/Navbar/Navbar.module.css
var Navbar_module = __webpack_require__(6398);
var Navbar_module_default = /*#__PURE__*/__webpack_require__.n(Navbar_module);
// EXTERNAL MODULE: external "lodash.throttle"
var external_lodash_throttle_ = __webpack_require__(1602);
var external_lodash_throttle_default = /*#__PURE__*/__webpack_require__.n(external_lodash_throttle_);
// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(5282);
;// CONCATENATED MODULE: ./components/common/Navbar/NavbarRoot.tsx






const NavbarRoot = ({
  children
}) => {
  const {
    0: hasScrolled,
    1: setHasScrolled
  } = (0,external_react_.useState)(false);
  (0,external_react_.useEffect)(() => {
    const handleScroll = external_lodash_throttle_default()(() => {
      const offset = 0;
      const {
        scrollTop
      } = document.documentElement;
      const scrolled = scrollTop > offset;

      if (hasScrolled !== scrolled) {
        setHasScrolled(scrolled);
      }
    }, 200);
    document.addEventListener('scroll', handleScroll);
    return () => {
      document.removeEventListener('scroll', handleScroll);
    };
  }, [hasScrolled]);
  return /*#__PURE__*/jsx_runtime_.jsx("div", {
    className: external_classnames_default()((Navbar_module_default()).root, {
      'shadow-magical': hasScrolled
    }),
    children: children
  });
};

/* harmony default export */ const Navbar_NavbarRoot = (NavbarRoot);
// EXTERNAL MODULE: ./components/ui/Container/Container.tsx
var Container = __webpack_require__(9698);
// EXTERNAL MODULE: ./components/ui/Logo/Logo.tsx
var Logo = __webpack_require__(3668);
// EXTERNAL MODULE: ./components/common/Searchbar/Searchbar.module.css
var Searchbar_module = __webpack_require__(2333);
var Searchbar_module_default = /*#__PURE__*/__webpack_require__.n(Searchbar_module);
;// CONCATENATED MODULE: ./components/common/Searchbar/Searchbar.tsx







const Searchbar = ({
  className,
  id = 'search'
}) => {
  const router = (0,router_.useRouter)();
  (0,external_react_.useEffect)(() => {
    router.prefetch('/search');
  }, []);

  const handleKeyUp = e => {
    e.preventDefault();

    if (e.key === 'Enter') {
      const q = e.currentTarget.value;
      router.push({
        pathname: `/search`,
        query: q ? {
          q
        } : {}
      }, undefined, {
        shallow: true
      });
    }
  };

  return (0,external_react_.useMemo)(() => /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
    className: external_classnames_default()((Searchbar_module_default()).rootcustom, className),
    children: [/*#__PURE__*/jsx_runtime_.jsx("div", {
      className: (Searchbar_module_default()).iconContainer,
      children: /*#__PURE__*/jsx_runtime_.jsx("svg", {
        className: (Searchbar_module_default()).icon,
        fill: "currentColor",
        viewBox: "0 0 20 20",
        children: /*#__PURE__*/jsx_runtime_.jsx("path", {
          fillRule: "evenodd",
          clipRule: "evenodd",
          d: "M8 4a4 4 0 100 8 4 4 0 000-8zM2 8a6 6 0 1110.89 3.476l4.817 4.817a1 1 0 01-1.414 1.414l-4.816-4.816A6 6 0 012 8z"
        })
      })
    }), /*#__PURE__*/jsx_runtime_.jsx("label", {
      className: "hidden",
      htmlFor: id,
      children: "Search"
    }), /*#__PURE__*/jsx_runtime_.jsx("input", {
      id: id,
      className: "inputcustom",
      placeholder: "Search...",
      defaultValue: router.query.q,
      onKeyUp: handleKeyUp
    })]
  }), []);
};

/* harmony default export */ const Searchbar_Searchbar = (Searchbar);
// EXTERNAL MODULE: ./components/common/UserNav/UserNav.module.css
var UserNav_module = __webpack_require__(83);
var UserNav_module_default = /*#__PURE__*/__webpack_require__.n(UserNav_module);
// EXTERNAL MODULE: ./assets/sleekshop-new-svg/cart.svg
var cart = __webpack_require__(6258);
;// CONCATENATED MODULE: ./assets/sleekshop-new-svg/user.svg
var _path;

function _extends() { _extends = Object.assign || function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; }; return _extends.apply(this, arguments); }



var SvgUser = function SvgUser(props) {
  return /*#__PURE__*/external_react_.createElement("svg", _extends({
    width: 16,
    height: 18,
    fill: "none",
    xmlns: "http://www.w3.org/2000/svg"
  }, props), _path || (_path = /*#__PURE__*/external_react_.createElement("path", {
    d: "M8 .75c-.953 0-1.836.234-2.648.703a5.21 5.21 0 0 0-1.899 1.922A5.083 5.083 0 0 0 2.75 6c0 .89.203 1.719.61 2.484a5.33 5.33 0 0 0 1.71 1.875c-.89.391-1.687.93-2.39 1.618a7.353 7.353 0 0 0-1.594 2.367A7.373 7.373 0 0 0 .5 17.25H2c0-1.094.266-2.094.797-3a6.072 6.072 0 0 1 2.18-2.18A5.818 5.818 0 0 1 8 11.25c1.094 0 2.094.273 3 .82a5.838 5.838 0 0 1 2.18 2.18c.547.906.82 1.906.82 3h1.5a7.373 7.373 0 0 0-.586-2.906 7.178 7.178 0 0 0-1.617-2.367 7.684 7.684 0 0 0-2.367-1.618 5.125 5.125 0 0 0 1.687-1.875A5.065 5.065 0 0 0 13.25 6c0-.953-.234-1.828-.703-2.625a5.157 5.157 0 0 0-1.922-1.922A5.083 5.083 0 0 0 8 .75Zm0 1.5c.688 0 1.313.172 1.875.516a3.552 3.552 0 0 1 1.36 1.359c.343.563.515 1.188.515 1.875 0 .688-.172 1.32-.516 1.898a3.78 3.78 0 0 1-1.359 1.36A3.653 3.653 0 0 1 8 9.75a3.78 3.78 0 0 1-1.898-.492 4.04 4.04 0 0 1-1.36-1.36A3.78 3.78 0 0 1 4.25 6c0-.688.164-1.313.492-1.875a3.779 3.779 0 0 1 1.36-1.36A3.647 3.647 0 0 1 8 2.25Z",
    fill: "#50585E"
  })));
};

/* harmony default export */ const user = (SvgUser);
;// CONCATENATED MODULE: ./components/common/UserNav/UserNav.tsx










const countItem = (count, item) => count + item.quantity;

const UserNav = ({
  className
}) => {
  var _data$lineItems$reduc;

  const {
    data
  } = (0,use_cart/* default */.Z)();
  const {
    data: customer
  } = (0,use_customer/* default */.Z)();
  const {
    toggleSidebar,
    closeSidebarIfPresent,
    openModal
  } = (0,context/* useUI */.l8)();
  const itemsCount = (_data$lineItems$reduc = data === null || data === void 0 ? void 0 : data.lineItems.reduce(countItem, 0)) !== null && _data$lineItems$reduc !== void 0 ? _data$lineItems$reduc : 0;
  return /*#__PURE__*/jsx_runtime_.jsx("div", {
    className: "flex items-center justify-end flex-1 space-x-8",
    children: /*#__PURE__*/jsx_runtime_.jsx("nav", {
      className: `UserNav_root__343id`,
      children: /*#__PURE__*/(0,jsx_runtime_.jsxs)("ul", {
        className: `UserNav_list__izHGy`,
        children: [ true && /*#__PURE__*/(0,jsx_runtime_.jsxs)("li", {
          className: `UserNav_item__2sdMO`,
          onClick: toggleSidebar,
          children: [/*#__PURE__*/jsx_runtime_.jsx(cart/* default */.Z, {}), itemsCount > 0 && /*#__PURE__*/jsx_runtime_.jsx("span", {
            className: (UserNav_module_default()).bagCount,
            children: itemsCount
          })]
        }),  true && /*#__PURE__*/jsx_runtime_.jsx("li", {
          className: "UserNav_item__2sdMO",
          children: /*#__PURE__*/jsx_runtime_.jsx(next_link.default, {
            href: "/profile",
            children: /*#__PURE__*/jsx_runtime_.jsx(user, {})
          })
        })]
      })
    })
  });
};

/* harmony default export */ const UserNav_UserNav = (UserNav);
;// CONCATENATED MODULE: ./assets/images/flag-icon.png
/* harmony default export */ const flag_icon = ({"src":"/_next/static/image/assets/images/flag-icon.bd8d6dd95e5b68134334d9db415237f3.png","height":24,"width":40,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAFCAMAAABPT11nAAAAIVBMVEXXYnrgiJrVYXkpSX/efpLmjJ1nbZXCd5EuU4e1WHbdcIZDIqpfAAAACXBIWXMAAAsTAAALEwEAmpwYAAAAKklEQVQImRXKuQ0AMAwDsZP8Zv+FA5cESEQ8DOzGlCS6ezIzqTpL2L7BBwzXAHzGsP/DAAAAAElFTkSuQmCC"});
// EXTERNAL MODULE: ./node_modules/next/image.js
var next_image = __webpack_require__(5675);
;// CONCATENATED MODULE: ./assets/sleekshop-new-svg/rocket-icon.svg
var rocket_icon_path, _defs;

function rocket_icon_extends() { rocket_icon_extends = Object.assign || function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; }; return rocket_icon_extends.apply(this, arguments); }



var SvgRocketIcon = function SvgRocketIcon(props) {
  return /*#__PURE__*/external_react_.createElement("svg", rocket_icon_extends({
    width: 14,
    height: 15,
    fill: "none",
    xmlns: "http://www.w3.org/2000/svg",
    xmlnsXlink: "http://www.w3.org/1999/xlink"
  }, props), rocket_icon_path || (rocket_icon_path = /*#__PURE__*/external_react_.createElement("path", {
    d: "M0 14.98h14v-14H0v14Z",
    fill: "url(#rocket-icon_svg__a)"
  })), _defs || (_defs = /*#__PURE__*/external_react_.createElement("defs", null, /*#__PURE__*/external_react_.createElement("pattern", {
    id: "rocket-icon_svg__a",
    patternContentUnits: "objectBoundingBox",
    width: 1,
    height: 1
  }, /*#__PURE__*/external_react_.createElement("use", {
    xlinkHref: "#rocket-icon_svg__b",
    transform: "scale(.01563)"
  })), /*#__PURE__*/external_react_.createElement("image", {
    id: "rocket-icon_svg__b",
    width: 64,
    height: 64,
    xlinkHref: "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAEAAAABACAYAAACqaXHeAAAZDElEQVR4Ae2ZBXgc192v3zMzu7O8K5YsWcaaMWQHHYY6zMz03Vu4bVJOmzJzyszcJMXEYYcZ7Zhly5bFyzs7POeOV/b3uIyBD97n+Z2jRek9//85WuB/+R+Oxn9DrnzDu9u0iD4jEktORdMmx9O5nKJFpFkzxivFwprtW7Y/AhgA2lGnvp7/DnSng7Z4U2tPPJtdHE1kl2vx5EJVT/YokViTEtVjihqRetY1iY5si43Wblm7YegzQEVMPeBq/qvyjesPyX74s988YL8TznzdtH0OOVTPNDf5SoyaFVA1bUzbwQ9AKBpxPUoyHgXXYePTz7D6rgdXDRcrl2oFV/2v1+LLgpaWlubr8sSvvOa6N7cRT2MmNJymSQyOGIzlS1RqdQIpiYXimWQoH0sQTURwaj62D0o6d5xw/LM0kUzyX4Vr97Was03NN/bOeM15Xb3T2tATuIGgXKlhDm6hf/1GCs37Mly28dyAuB4hqSdIphKkMxE0oFCpUatb+JEIXjTSq4UDr3bevJ8T0eOJt85cfNA1vXPmT9YSGcp1m8p4HqNSIl+sMLkjvK60hdr2e9Fz++LH0sQTUdLpBNlQPhFTcQwb06zjSokjNHwRiWvhwKuZd6wQ505duP+7XtPduyC1qQ/zW9/BGBtHtLZSX7CEfFMzUgSs3biVVCbHnCZBa+UFxrL7I7LtNGcgl9XQFYlvAeFs+QFWIJFSooUDr0ZuOMTvTPdO++ABqn7FzFX3suGOVdzft5Ei0A4chs6yhbN58viTeGTBUppaW9A0jWQiRkdHhFJlC8VEnGx7Dy0pSUyVKAT4UlJzPGzXQwl8UwsHXm28b2XuxO6eyTcd+szzUwe/+CW+lUpx7+Qe8tOOo1SuMLZzB7PzRT5Zsjn8uSeoCIXNBx5IVo9M7Pdkgsld7ZRKW5ER6M72oCGwTLWx/6uWi+s4qNIrauHAq4V3HZnQk21tNy6aMu0dS770NX7x4P08fP6F5OYuoHPbVvz+bViVGslEhsctmxsKo9w6lODQ4u1sX7yEZGszmUSMXCaJZTvE9Qy50rN0tls40ZnYtk+halKzHFzHlJpnD2mBZ/Nq4PpD9I6Wzs5vLFyy74kzb3gPNz3zJLUPfJRWw6Tv2WcYDKs+PDREsVjANAyEXedh32eD47B8x2am7tgGC+aQiUXIZdJY1SKbtm1h0YrjKQz8mnp7nOHxJOOFCpbl4NvmuFsvrtfMepFXmhtPmLRkxuw5P5+z/JCZiQ98gJufe5bR628gGB6hf/NmBgd3yQ9TKZdwrDq+Y4Hv4vk+tY52aIrTHF7v7TrxY1FSepSOVA+zeqeBgNa24/nd6lt4cXwR4yUD26rj2+azuP5aTbo+ryRvPbL58HmLFt+y5Ihjczt+/nPqv/kNtx92BC2FIn3rX2R4cCdjY6MYtSquZSIdCxkEYSCGoGtKL3S1EG1rJZmMk9EjJDQNBfB8Fyklpm+RjbbQ99jtVKwuHLMO9fJdQEUj4BXjbUdlz93vkEO/MW/f5cktm7dh/+wn1Ds6sFo72LDmhbDqgxTyY9RrNTzbRLr2hLyUIH0OyDTxmqYsvh7DnjaN9liUuKKiABJJ4AfUrCo7BnZSqprM0kd4ccDCNj3AfRZAA5dXgnOnV89Ydvhp35o+b3F8tGax89lnWRLK/DZfYHB4hFpY+VKxgLFL3jIJBwLfb4hJSYOr29qI/u53DOx/APGrryGlKAgkvvTwfZ+6VWd4ZJQdO4YYGtjU6JA24wWGjM5xpHgKQEMKXm7u+vRFry1UjO/2zloQHypUGanUUSplsgG0KSpb+7eh1SoNeT+UCBwLKXdXvpGAC3LNnO35MDxE4XX7097WAo6DG7jhZGNadQrFEkODo4yNjTGaNxgey9MRM9GqW38E5AE0zSvycrJyv+mpZx+//3P7HXdacqhQY7RQpGi7pGoGVt9WDlY0JpXGWW/a4FgTCXyQhGkMXJZM8/lEkkgo1n/s0YhzzyLu2jhhbLuOYdSpVGvk8wXGw5RKZRzHxzUtTDugRan9gt1oLUqFl4vD583PHnTBFff0ivzMoeEiZUdQrtaoWDYj8RwzPUmvY/C9XJZvVHdwm20w5PsgBB1IjohGOEdVOVHRYHCE/iMOIf/BG+lOJbDMOpZlhPI1qtU6xXKFQqFEqVymEqZcKjM2Okrb5LZK3k+MsRutuaudl4ML7/v1gTt7uz657PD99hESnrztdnZu7yeSSKMJwQ5UVi09kDMfvoNsPM37p/Xypq19DNgOMQEzEHQFEkJRSZ2tRx1L/rMfp3vKZLx6KF6vUQ/nWs2gXAlTrlKpVKlWKlTClHctRNXg+R2llcB6dqONjQ7xUvPR/hcuNdKJr09dvkyrC9iwxaI+aRn17UOkzBqz50xh3aY+ts6az7dDwZXb19NaLWJXq2SAVkAFRgGru4f+yy8j+X+voTum4xvVCXmjFs4m1epE+1fDVPbIV6qUSxXy5dpv04IH2QstLWxeKj61dWOyHIl8KpVOX/Oo3sJBZ1/Jlj6bwcES48UKsnN/RtfeTd+dD9Lc1oUiwD9kBTdXlqL2byE3eQPNlkE6qhOfOpX04SuYdOAyuro7Sfouzi7x3fI1w8QIUzXqfyhfrjTOgHyh6Bfz+ev5I7TwSl4KvlXNL2nWY9+PxfQFDw2Pwbs/TKA007dlkEK5RLFqUDFdaFmKsv0hUnaNpo4uYtEIye5W9P0WoSfjJBIxMqkELbk0LXGdpALCtbEcqyFu1icq/58LUAvlq9U98o3Kl4olRsZrX4gnmzbwR2jhlfy9fKLaF00ZfpvmB+WoEHUgYDcFP1BsSOmquiweibyhPZY41gj86ECpyKrepZy07Cj6+nYyPDZO2ahTMx0s18NDIdK1nO2Dj5JNVUg3TyYW1UjrYeJRsqF0JpyTKsSlj/QCHNtsVH5i31uNNNq/ZlAN5at7yRdLZcbzpTHTdj/An0Hkembz93Iv47+apiWOqZt20XCcctX3LQsCpFRUIeIxRWnOBUG77bkMA+Oq4Ed2hPJl72S/lecwMDTeqLxhO9hegI9AKApqNE5UgcTA/Ry2YBJdk6eTiGk0ZVJkEjFSyRixiIKQAbZlYpoTbV83rTB2YwFqjdavNtq9VCw2XgOMjxcYHBpmaKx4AnA7fwbRPmMOfw+32WPvXij090dsF3x/Ip4HQdBI4Pu44VySAdsiEcY1jU1BwBdys1j+/z6EkutktFjGsFwcXxIAQo0QiYSJRtBjcTQhaR++l5OW9xBtmktEWExqbyYRi4L0cSwL0zSohzHru+Qd6paFsUu+VqNamdjvxUKJQpiR0TGGhse+B1zCX0CLaRp/i1XGztd50ez7tWoVHGdC3HUbsx+AL8AFbAF5VaGsKBgC7gtiqB1Tqfkq9bAaFdNpyEuhoKgaEUWgKCoRTUPXBOlUBpE7kZGRn7I4O8QLI1PozApkJIll7aq0GYrXMU0H0wrld19XqxlUqhWq5QqVcpVSOBdLJcKDb3u1br6Rv4IW3oG/xrOyeKkq4jfpto1wd8t7LtL3kYCvgAc4QEVAUQgMIRkI4LloE9l0G+OlKpYSxQkkCBVFFaiKQkRT0aMq8cZ+12lKaLQ0tVEOLiewPsrh0+uk0p2h6DD1qkcljGl5WLaLaU/IT1S/SmVCvrHni8UyY2MFp1wxztcUpcRfQQvvwF/iQX/80C4l8o11isIs2wDp7Y5PIGQY8AFPQp2GfCN+EPCkmkTGkniRBBXTJghFpVBRNQVNDaMpjcrHo5GGfEs6Tks2SVNSkEp2sqn+TmZH300mkmLT6GRqFYdKTcGyA2xnT+sbGBMH38QLn8YWqFAoFCmUqu8UQnmIv4EmhPLnDzx7ZFpbLHazI101IQJiwgbVh8BDIgkAX07EClMOUwQsAoalyuNqhlgig5dpRVU1BKAogogqiGpK46RPxqLkkqF8JhHKJ2hKRUlEBJhVqobKj3dexMqxD6Knj6BYmRpe52E5HvZ/Vr/WaP9qpUa50mj9xuv/sUL5M4qqfIq/Ay28I3/MPfXBVDoe+3lTOmgd9WGSb4MIwJWN+BICfyKuBCOAigc1KSHMZpHAisRJZSahNLehqBGU3ZXXIyqxXVWP6TSnYzTvkg+TTUaIaWBLiVGpUB/eSb4c8LmNF3NM+iZoOo1KvZ16rYptW1im2Tj5J/Z/bc/hx9hY8dcKvJm/E02R7A1POkNCS8Y+2TZN31diUDehVQbgKeD6SAeY2AV4LtgeGC5UfTDDBA5sUhOokRR0TiaWSaNGNRRFIxrRGid6JhGjKRNvVD2XjpOOq0SUie/zpqz6GUUJfZ0zsCoVqk6Ur49dRnfpN3RN3x9VT1AqljEtc/cBWKdcmXjjMzqWfyBfqJzLP4AWPoC98ZLK6R2LEteQc7EtyJRASe7ucyeYOAKcMC6Nn20HajaYDgQ2jCoKG7w0WjxLvKOTVDKBomloYRIxnUwy3pBuTofyqRgJXUH4DiOFPJN/+AVO+8nXGe3p5e4r34/p+lhhTKnzTHA4z/z+Nxy/8jDKholZrex+7W80qh/KP1g1jJOiMdXkH0ALH8AeHvPLndkF2S8qczxwfKRjk0lFQHHA8ZB2QOCC74FnTUjXwlQtMMMEERgUUYx6nEyulWxrK+lQWFU1Yo3Kx8mmwiR1UrEIEeni1mrsGNjC7O99jvMevQszneTDR59HwXLxbQfLndjzDgpm07785Cf3MH/+DCzLoVSuNl79jY/nH6pWzVNAlPkH0WQg2EO2O35j5mitAxwIAqg4qBkNAgluAI4kcECGCSxwXLBtMA3wdBBR2F4EqeokOztoaWkmGQrr0QipRIx0fJd4FF0TCKtCrV6mb/0zvOZn3+bCHRsJEinecfi5PNXUi1atNuQd18VxHBzbxYtmcHJzWL9+A7lsEtO0GBkeub1eMy4BCvwTaPg2AM/F3ZUdp6Supd0DWxD4PpqnIZIauC44E2eAcAATlARUDL5vdHBrW5zI0AZNe26bMr0w96j3ZMtorT1ddLQ1kUgkiOlRknqEmCZQAhOnVKVaHmHDI3fTevNPuCoKajLFdQuP5P72GcTLJep+gOt6YZwwPp7n4Toujpah4rdT6F8fTJ2/+HGvKC6Oxhjjn0Q0zz6Yh0bW6p0ro6tzF4hlGBICgXQsMEFEog1xXBsci8D2ERKeW8PDtz7EUYAFUDzyypO2bhvQmubtf/Pm/mHmHngEk2fOaRx8UVWg4hNYBkY5z/jYAAOrb0O58/d86OgjmGVUuNHO8KOZ+5NG4EmJ6/uheBCK+/i+j7drMRwL23YxDcP0x9afA/yGfxGtUCwS7VYuzZ7jLiMlQWcCx0M4Knh+GMCOgitRfBvPCtzv3in/D2DVTrw2sn208s3a2o0X7T9vhr/qkfuZsvAQZs56DboeQZEegWNTrxQpjg8zvG095VDeX/s87zwilD/rVL53zzN8Y0whXatRY+KFlC8lng9+YwE8bMfBsWzc8sijfmXwTcCj/BsQD6ayrfOvVx7JXeLPpApIIBBgOSBVsJUwgKWEAXSPm39gfBx42725M7PbK/rnnnjwvkuScUmuezYvPPEo8444m9MvvLzx786slKjmxxgZGWT0xacIHrgLSuMcG9V5/X9cwRpinPToDrx4EkUIAqEg97zICmSj8rUwiVoRr1r8Zr029DrA4t+E1rKfclXuQmWyHxeDSlypBL4sSy3oq21RVC0ZnRFrlmoQSDUqUBGKVlpL6cGH5McB3BPtzkfufOTcng4Tfe7B9JvtZLuGePGh36LrOsceczTlkR0MbNtG6bknSD3/GHEZkELl7GwKuepO3hWfzlg0Q9oyCJQIUlGQiIa87Xk4lsU+xR2cOvzit4Er+TcjRt6qt8UvEZppBtVMW9QEfP4MsZQvaI6pgMduPnWM0+VPif7sp+OHHjJkd6KoAt0qMvjo7fhKhCUHHkWzGsCj95MujhJBxQIuS4RVz6X4tJLluqaZNGm7xFVQNBQJSigubJOeWp7LC1s4rJ5f8wXJAYDJvxlxFf84h+yHps7g1NOv5ab4srmdZ92wP7c9kaArNkanWkBPT+WF+36N5RnMMKPMsiooaLhAB5KPtmbwtSiL0jMZ1jMkEMR9Scaq02qUmGSVWGEVON6r0gzWdQFLgfW8BIjL/lH5I9nv5PNavtN6bM982lpBSzE4HOOSt9cwRsv0TN+XpTN72Dma5+avfoH51RpJBDHAQnJdNs2hqTTvCZJ8XmtlimfSZNZoMat0ewYHBSYLhE+HgATwiOSXwJm8RGjnK/xd/GYqyrUH8+PeNx702uTSeSm8CHg+uAkmTQq45bMeH/tyC8hJeASMDWxmgWOTBSYJgRKVnHBWjkMPEez4quSxNQVWBEP0Bg7zcJkuJN0CWlRQ5UQCkI8EfIaXEPF+/j5O+Q9uXXRa2ymsOA28if2KVIEE4IBm4hqD/PDWSdzy822Yd/+etC3REXTENVa0SU4NApzPtKz99OdKafmg2ztLhQ4gt7vaugQViEqIAGUY/mLATMDgJUKr87e55By6px/NUUFvK4pIg7DDdIRRISiBdMCNEsktZcHkR/j272+jFYghyGiwbzecUPbYOKf7oXu2u6fIQfGDYwS9GhAXYQCtIT8RZXd8KCTA5CVES/DXcRazomdffhDpaUqJngPAlyD0MN0QlEGGQYVEG5ufLHPLW59iXgZkHRQPjto3xhmLfDbvYOdbZiy7jD7yh0Z/VWuPgudNVHuPtLbXzwBRIawrVQJeQrQrVcHevONAqZ10oDjSXccGoH/fJfLzqSX0yHQrqDpID0Q8TAZwgBjEE/S/MM6nTv0CStWhWZ2426ITdM64TGfjQ87O1fs4K0/k5k3XfTSRWLpYTE5qYHqgAWKvygsmEAIUkLzEaAp/yOsOpmPJEnnbA/1c//QmVp96HvN9XaAmBAQ+YIMERDGMDmqGwI9x643fRyk6ZCMgy3DQ63Kc+CGVvi/Xvv3LqncjVXXHt3/TsWzu1ORN+4zt3B/bQ9tLXJUg2J0JeTyI3OpLwUu4EOIL/Cmzj6b3mXFmvO4EbtEXkg2mx9HmLAClGUQO1Dmg9IIUEOvhsR/+lu9d8nnScYFjSU55fzcr3tHM5s/1/wC46IrPRLW8m33Tomz0w5cVBrR98lVcCepe4spe8ns6oizZenOgzAMsXiI0gcLeNJ8nO+99TvGvONj/ZnwFWTcJiq6AOgX8PIhR0A4F0QbRLGbRZPUHf0rUB9+XnP/VWex3eQelH63bcOOHKlfmeiO5jqbe1acG5UUX21vR3QBTBc0HJfhT+T1IIA1dBxFkXtIFOIiAvRmsiJYj0vR2LqLLb0+hTVoG9T6QBigtu+NAJAci4KEvf4ZN60fomqRx4ddmMWvlbMrP7Rz88kfGVy7owD79hqA1smbLnCmrTdxhsFRQBbC3+F7yYq8tkZfcsQVR5SVE/ALBH5M8VM478mrWRg6cg5iyAjn0ICKWg8R0UNpBd0GJUhpS+eiyL5BKeVzzi8W0zeuBquTz5/z+tcBtAKdf5za3Dymb1J97zc5O8IbAL4F0d3eA/MMFkBI8YIsUrwe+wEuMNuWP/AcOkNeumMYbFQuCygjqyFPgAplJIAPQDFDSgMG3rvgprT2Sq35yINleE8wHuO+9+a8smjshD+CYmHZEVpMJmhUdhAaKCtLbXW0BEnCAQEIUvDWSy0F+n5cBzUSyh0+2o3y+m7fqOtO8ABS7iL99G+rcg0AooArQbKCZ337oBTomSc76ycFEU4OM/WzD9jW3eZ947D6+xl50H6bYfkStKHqA0CVqDIiAdMAD6hIUQKdBdUSKczvh97xMiI1CsDf9p8ibjrqy5XVBLk5QHSSy8BBItoIzAkYNcu0MDExhy+r7WfG6bqAfHurjp+/mNOBW/gwnvl1fnbzFO8zv8zG3gzECwoTAhaiEBGDAugEprgXu52/wkr4UzqWoitndKIlWgicHkKWdSNNGjgzhbt+JpgWkM52hfC/k18CWMZ76Ard+/wl+w1/glITX7+tgqeBEIBoFzQYV0AQMSVZvD7gY5HZeZsTey/3FXto/soL7e89QZzslgYqHkgKlJwFBnPqqAjgSEYA6S3X7X/Af2PIo3/x9Pz8BAv4CH/u+tipxmzhW9rnIQXDCiBLYJu4aX3x2u+QdgM8rgDaAYA9nTZLLp3WI2X5PF6JUw99cQTQruKUAdYqFGlAbXcPDdw3zsUlP+gbwmEjCynn8RRa/EyUwlB4hFNDcMBAPMyzZ9lufq0HeieAVQzOEZA/dzUTkCQK1qwXhgGxXUKfGkXfv5N4beZ/h8jVgcMqSyJdS3XIQeIy/hfDSqi1aEQKREFhgP1zim2tq4p1AmVcY8VkU9jDn8ODNR5/Lpwb7GbBqjCWaaY1lYHwjnwU+zW6+/zD7JFQGgFH+Bud/hMndheTWyBqpbn3SefynD/pXAc/zKkF8JC4AqHTJ3GmT+c5YnZvW1nkEqE/uIj5UBMDkn2TF60X7zHzs7t9/w/vE2g3eDwGfVxHiBkUAsM982a4nOAb4If9GguPQs+vU44Bf8yrk/wOEQ+Jsyne4vgAAAABJRU5ErkJggg=="
  }))));
};

/* harmony default export */ const rocket_icon = (SvgRocketIcon);
;// CONCATENATED MODULE: ./components/common/Navbar/Navbar.tsx












const Navbar = ({
  links
}) => {
  const {
    0: isActive,
    1: setActive
  } = (0,external_react_.useState)(false);

  const handleToggle = () => {
    setActive(!isActive);
  };

  return /*#__PURE__*/(0,jsx_runtime_.jsxs)(Navbar_NavbarRoot, {
    children: [/*#__PURE__*/jsx_runtime_.jsx("div", {
      className: "topbarmsg",
      children: /*#__PURE__*/(0,jsx_runtime_.jsxs)(Container/* default */.Z, {
        children: [/*#__PURE__*/jsx_runtime_.jsx("div", {
          className: "topbarmsgleft",
          children: " 337 Roncesvalles Ave, Toronto"
        }), /*#__PURE__*/jsx_runtime_.jsx("div", {
          className: "topbarmsgright",
          children: /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
            className: "currency-right",
            children: [/*#__PURE__*/jsx_runtime_.jsx(next_image.default, {
              src: flag_icon,
              alt: "",
              title: ""
            }), "\xA0 USD"]
          })
        })]
      })
    }), /*#__PURE__*/(0,jsx_runtime_.jsxs)(Container/* default */.Z, {
      children: [/*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
        className: (Navbar_module_default()).nav,
        children: [/*#__PURE__*/jsx_runtime_.jsx("div", {
          className: "flex items-center flex-1",
          children: /*#__PURE__*/jsx_runtime_.jsx(next_link.default, {
            href: "/",
            children: /*#__PURE__*/jsx_runtime_.jsx("a", {
              className: (Navbar_module_default()).logocustom,
              "aria-label": "Logo",
              children: /*#__PURE__*/jsx_runtime_.jsx(Logo/* default */.Z, {})
            })
          })
        }),  true && /*#__PURE__*/jsx_runtime_.jsx("div", {
          className: "justify-center flex-1 hidden lg:flex",
          children: /*#__PURE__*/jsx_runtime_.jsx(Searchbar_Searchbar, {})
        }), /*#__PURE__*/jsx_runtime_.jsx("div", {
          className: "flex items-center justify-end flex-1 space-x-8",
          children: /*#__PURE__*/jsx_runtime_.jsx(UserNav_UserNav, {})
        })]
      }), /*#__PURE__*/jsx_runtime_.jsx("div", {
        className: "flex pb-4 lg:hidden",
        children: /*#__PURE__*/jsx_runtime_.jsx(Searchbar_Searchbar, {
          id: "mobile-search"
        })
      }), /*#__PURE__*/jsx_runtime_.jsx("a", {
        href: "javascript:void(0)",
        onClick: handleToggle,
        className: isActive ? 'mobileMenu-toggle is-open' : 'mobileMenu-toggle',
        "data-mobile-menu-toggle": "menu",
        title: "Menu",
        "aria-controls": "menu",
        "aria-expanded": "false",
        id: "show",
        children: /*#__PURE__*/jsx_runtime_.jsx("span", {
          className: "mobileMenu-toggleIcon",
          children: "\xA0"
        })
      }), /*#__PURE__*/jsx_runtime_.jsx("div", {
        className: (Navbar_module_default()).mainmenudiv + (isActive ? ' menu menu-block ' : ' menu'),
        children: /*#__PURE__*/(0,jsx_runtime_.jsxs)("nav", {
          className: (Navbar_module_default()).navMenu,
          children: [/*#__PURE__*/jsx_runtime_.jsx(next_link.default, {
            href: "/search",
            children: /*#__PURE__*/jsx_runtime_.jsx("a", {
              className: (Navbar_module_default()).link,
              children: "All"
            })
          }), links === null || links === void 0 ? void 0 : links.map(l => /*#__PURE__*/jsx_runtime_.jsx(next_link.default, {
            href: l.href,
            children: /*#__PURE__*/jsx_runtime_.jsx("a", {
              className: (Navbar_module_default()).link,
              children: l.label
            })
          }, l.href))]
        })
      })]
    }), /*#__PURE__*/jsx_runtime_.jsx("div", {
      className: "staticmsgbelowmenu",
      children: /*#__PURE__*/jsx_runtime_.jsx(Container/* default */.Z, {
        children: /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
          className: "covidAndRocket",
          children: [/*#__PURE__*/jsx_runtime_.jsx("span", {
            style: {
              color: 'white'
            },
            children: "COVID 19 UPDATE: WORLDWIDE FREESHIP"
          }), "\xA0", /*#__PURE__*/jsx_runtime_.jsx(rocket_icon, {})]
        })
      })
    })]
  });
};

/* harmony default export */ const Navbar_Navbar = (Navbar);
// EXTERNAL MODULE: ./lib/get-slug.ts
var get_slug = __webpack_require__(7619);
// EXTERNAL MODULE: ./components/common/Footer/Footer.module.css
var Footer_module = __webpack_require__(9707);
var Footer_module_default = /*#__PURE__*/__webpack_require__.n(Footer_module);
;// CONCATENATED MODULE: ./components/common/Footer/images/payment-methods-icon.png
/* harmony default export */ const payment_methods_icon = ({"src":"/_next/static/image/components/common/Footer/images/payment-methods-icon.4f567ae75b1c33c5ae541312f7c1a21b.png","height":35,"width":372,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAABCAMAAADU3h9xAAAAFVBMVEXp5Nvd7PX7spTO4O/U6ffZzNfi4+scNEqWAAAAB3RSTlPT8NXSzdjsbr+P9QAAAAlwSFlzAAALEwAACxMBAJqcGAAAABFJREFUCJljYGNmZWJgYGEEAAB/ABY+/cNhAAAAAElFTkSuQmCC"});
;// CONCATENATED MODULE: ./components/common/Footer/images/pinterest-icon.png
/* harmony default export */ const pinterest_icon = ({"src":"/_next/static/image/components/common/Footer/images/pinterest-icon.80f3f3c935f13c729cb48cf3b77ccd91.png","height":13,"width":10,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAYAAAAICAMAAADtGH4KAAAAKlBMVEVPV15QV11QV11QV11PWF1QWFxQWF1QWF1QV11QWF1PWFxQV11PV11PWF5bVlrlAAAADnRSTlMBrL1TdjuMk9maGCYU+kz/F9AAAAAJcEhZcwAACxMAAAsTAQCanBgAAAAvSURBVAiZFcbHEQAwCASxPYJx7L9dD3qJvWQLFIkK+cMNhTHEqenTQSMSsEvr8gEUkgChWBuK0wAAAABJRU5ErkJggg=="});
;// CONCATENATED MODULE: ./components/common/Footer/images/instagram-icon.png
/* harmony default export */ const instagram_icon = ({"src":"/_next/static/image/components/common/Footer/images/instagram-icon.2db739613e86f949de429d93e72afc42.png","height":12,"width":12,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAICAMAAADz0U65AAAAG1BMVEVQV11QV15QWF1QUVlQWF1QV11QVl1QV11QV117bRGhAAAACXRSTlOShD4DoGgcL2YT+jD2AAAACXBIWXMAAAsTAAALEwEAmpwYAAAAM0lEQVQImSXLuQ0AMAzDQEryk/0nTuGOwIGkkXihNfbWg9kqL8iVYF2UdbQDzdhDc3vnAx05AMmArXj4AAAAAElFTkSuQmCC"});
;// CONCATENATED MODULE: ./components/common/Footer/images/facebook-icon.png
/* harmony default export */ const facebook_icon = ({"src":"/_next/static/image/components/common/Footer/images/facebook-icon.1f7b98d7c2744323dbdca2cedcce7d32.png","height":14,"width":8,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAUAAAAICAMAAAAGL8UJAAAAKlBMVEVQV11MaXFQWF1PV1tPWF1QWF1QV11QWF1QWF1QVl5PV11QWF5QV15QV13qcPB3AAAADXRSTlNiAKMOUu2OGcUnPcHezhn/KAAAAAlwSFlzAAALEwAACxMBAJqcGAAAAC1JREFUCJktyMkNADAIA7AECvTK/utWSP34YdCnDBzKDUJO3FAAeWSrn+yv7wMVngDc2HSMLgAAAABJRU5ErkJggg=="});
;// CONCATENATED MODULE: ./components/common/Footer/Footer.tsx









 // console.log('dynamicScript', dynamicScript)
//




const links = [{
  name: 'WHO WE ARE',
  url: '/pages/about-us.html'
}, {
  name: 'CONTACT US',
  url: '/pages/contact-us.html'
}, {
  name: 'PARTNERSHIPS',
  url: '/pages/partnership.html'
}, {
  name: 'VIEW ALL BRANDS',
  url: '/brands'
}, {
  name: 'NEW ARRIVALS',
  url: '/search.php?search_query_adv=new%20arrivals&section=content'
}, {
  name: 'WEBSITE ACCESSIBILITY',
  url: '/pages/website-accessibility.html'
}];
const links2 = [{
  name: 'MY ACCOUNT',
  url: '/account.php'
}, {
  name: 'LIVE CHAT',
  url: '/pages/contact-us.html'
}, {
  name: 'CUSTOMER SERVICE',
  url: '/pages/customer-service.html'
}, {
  name: 'RETURN POLICY',
  url: '/pages/return-policy.html'
}, {
  name: 'SHIPPING POLICY',
  url: '/pages/shipping-policy.html'
}, {
  name: 'CURBSIDE PICK UP',
  url: '/pages/curbside-pickup.html'
}, {
  name: 'HOME',
  url: '/'
}];
const termlinks = [{
  name: 'TERMS OF USE',
  url: '/pages/policies-terms-of-use.html'
}, {
  name: 'PRIVACY POLICY',
  url: '/pages/policies-terms-of-use.html'
}];

const Footer = ({
  className,
  pages
}) => {
  const {
    sitePages
  } = usePages(pages);
  const rootClassName = external_classnames_default()((Footer_module_default()).root, className);
  const {
    data
  } = (0,use_customer/* default */.Z)();
  const router = (0,router_.useRouter)(); // const [currentPath, setcurrentPath] = useState(router.asPath)

  let site_id = process.env.site_id || 7870040; // const LoadTheseLinkExceptPDP = () => {
  //   if (!router.asPath.includes('/products/')) {
  //     return (
  //       <>
  //         <script src="//sandbox.unbxd.io/sleekhair_mybigcommerce_stage_search.js"></script>
  //         <script src="//libraries.unbxdapi.com/search-sdk/v2.0.4/vanillaSearch.min.js"></script>
  //       </>
  //     )
  //   }
  // }

  return /*#__PURE__*/(0,jsx_runtime_.jsxs)("footer", {
    className: "footer-main",
    children: [/*#__PURE__*/jsx_runtime_.jsx("div", {
      className: "footer-pt-1",
      children: /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
        className: "container",
        children: [/*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
          className: "footer-coloum",
          children: [/*#__PURE__*/jsx_runtime_.jsx("div", {
            className: "footer-links-title",
            children: "Help"
          }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
            className: "footer-links",
            children: [/*#__PURE__*/jsx_runtime_.jsx("span", {
              className: "",
              children: /*#__PURE__*/jsx_runtime_.jsx("a", {
                className: "",
                href: "/pages/shipping-policy.html",
                children: "Shipping & Returns"
              })
            }), /*#__PURE__*/jsx_runtime_.jsx("span", {
              className: "",
              children: /*#__PURE__*/jsx_runtime_.jsx("a", {
                className: "",
                href: "#",
                children: "Track Your Order"
              })
            }), /*#__PURE__*/jsx_runtime_.jsx("span", {
              className: "",
              children: /*#__PURE__*/jsx_runtime_.jsx("a", {
                className: "",
                href: "#",
                children: "Store Finder"
              })
            }), /*#__PURE__*/jsx_runtime_.jsx("span", {
              className: "",
              children: /*#__PURE__*/jsx_runtime_.jsx("a", {
                className: "",
                href: "#",
                children: "FAQs"
              })
            })]
          })]
        }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
          className: "footer-coloum",
          children: [/*#__PURE__*/jsx_runtime_.jsx("div", {
            className: "footer-links-title",
            children: "About"
          }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
            className: "footer-links",
            children: [/*#__PURE__*/jsx_runtime_.jsx("span", {
              className: "",
              children: /*#__PURE__*/jsx_runtime_.jsx("a", {
                className: "",
                href: "/pages/about-us.html",
                children: "About Us"
              })
            }), /*#__PURE__*/jsx_runtime_.jsx("span", {
              className: "",
              children: /*#__PURE__*/jsx_runtime_.jsx("a", {
                className: "",
                href: "/pages/contact-us.html",
                children: "Contact Us"
              })
            }), /*#__PURE__*/jsx_runtime_.jsx("span", {
              className: "",
              children: /*#__PURE__*/jsx_runtime_.jsx("a", {
                className: "",
                href: "/pages/career.html",
                children: "Careers"
              })
            }), /*#__PURE__*/jsx_runtime_.jsx("span", {
              className: "",
              children: /*#__PURE__*/jsx_runtime_.jsx("a", {
                className: "",
                href: "/pages/partnership.html",
                children: "Become an Affiliate"
              })
            })]
          })]
        }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
          className: "footer-coloum",
          children: [/*#__PURE__*/jsx_runtime_.jsx("div", {
            className: "footer-links-title",
            children: "CATEGORIES"
          }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
            className: "footer-links",
            children: [/*#__PURE__*/jsx_runtime_.jsx("span", {
              className: "",
              children: /*#__PURE__*/jsx_runtime_.jsx("a", {
                className: "",
                href: "#",
                children: "Shirts"
              })
            }), /*#__PURE__*/jsx_runtime_.jsx("span", {
              className: "",
              children: /*#__PURE__*/jsx_runtime_.jsx("a", {
                className: "",
                href: "#",
                children: "Jeans"
              })
            }), /*#__PURE__*/jsx_runtime_.jsx("span", {
              className: "",
              children: /*#__PURE__*/jsx_runtime_.jsx("a", {
                className: "",
                href: "#",
                children: "Footwear"
              })
            }), /*#__PURE__*/jsx_runtime_.jsx("span", {
              className: "",
              children: /*#__PURE__*/jsx_runtime_.jsx("a", {
                className: "",
                href: "#",
                children: "Accessories"
              })
            })]
          })]
        }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
          className: "footer-coloum",
          children: [/*#__PURE__*/jsx_runtime_.jsx("div", {
            className: "footer-links-title",
            children: "JOIN THE LIST AND RECEIVE 15% OFF YOUR FIRST ORDER"
          }), /*#__PURE__*/jsx_runtime_.jsx("div", {
            className: "newsletter-form",
            children: /*#__PURE__*/jsx_runtime_.jsx("div", {
              className: "klaviyo-form-W2TX3f"
            })
          }), /*#__PURE__*/jsx_runtime_.jsx("div", {
            className: "social-links",
            children: /*#__PURE__*/(0,jsx_runtime_.jsxs)("ul", {
              className: "social-links-ul",
              children: [/*#__PURE__*/jsx_runtime_.jsx("li", {
                className: "social-links-item",
                children: /*#__PURE__*/jsx_runtime_.jsx("a", {
                  className: "icon icon--facebook",
                  title: "Connect with Sleekshop on facebook",
                  href: "https://www.facebook.com/sleekshopcom/?business_id=887407754647488",
                  target: "_blank",
                  children: /*#__PURE__*/jsx_runtime_.jsx(next_image.default, {
                    src: facebook_icon,
                    alt: ""
                  })
                })
              }), /*#__PURE__*/jsx_runtime_.jsx("li", {
                className: "social-links-item",
                children: /*#__PURE__*/jsx_runtime_.jsx("a", {
                  className: "icon icon--instagram",
                  title: "Connect with Sleekshop on instagram",
                  href: "https://www.instagram.com/sleekshop_com/",
                  target: "_blank",
                  children: /*#__PURE__*/jsx_runtime_.jsx(next_image.default, {
                    src: instagram_icon,
                    alt: ""
                  })
                })
              }), /*#__PURE__*/jsx_runtime_.jsx("li", {
                className: "social-links-item",
                children: /*#__PURE__*/jsx_runtime_.jsx("a", {
                  className: "icon icon--pinterest",
                  title: "Connect with Sleekshop on pinterest",
                  href: "https://www.pinterest.com/sleekshop/",
                  target: "_blank",
                  children: /*#__PURE__*/jsx_runtime_.jsx(next_image.default, {
                    src: pinterest_icon,
                    alt: ""
                  })
                })
              })]
            })
          })]
        })]
      })
    }), /*#__PURE__*/jsx_runtime_.jsx("div", {
      className: "footer-pt-2",
      children: /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
        className: "container",
        children: [/*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
          className: "copy-rights",
          children: [/*#__PURE__*/(0,jsx_runtime_.jsxs)("span", {
            children: ["\xA9 2021 ", /*#__PURE__*/jsx_runtime_.jsx("a", {
              href: "#",
              children: "SleekShop"
            }), ", Inc. All rights reserved."]
          }), /*#__PURE__*/jsx_runtime_.jsx("span", {
            children: /*#__PURE__*/jsx_runtime_.jsx("a", {
              href: termlinks[1].url,
              children: "Privacy Policy"
            })
          }), /*#__PURE__*/jsx_runtime_.jsx("span", {
            children: /*#__PURE__*/jsx_runtime_.jsx("a", {
              href: termlinks[0].url,
              children: "Terms & Conditions"
            })
          })]
        }), /*#__PURE__*/jsx_runtime_.jsx("div", {
          className: "payment-methods",
          children: /*#__PURE__*/jsx_runtime_.jsx(next_image.default, {
            src: payment_methods_icon,
            alt: ""
          })
        })]
      })
    }), /*#__PURE__*/jsx_runtime_.jsx("script", {
      type: "text/javascript",
      dangerouslySetInnerHTML: {
        __html: `
              var sa_uni = sa_uni || [];
              sa_uni.push(['sa_pg', '5']);
              (function() {function sa_async_load()
              { var sa = document.createElement('script');
              sa.type = 'text/javascript';
              sa.async = true;
              sa.src = '//cdn.socialannex.com/partner/${site_id}/universal.js';
              var sax = document.getElementsByTagName('script')[0];
              sax.parentNode.insertBefore(sa, sax);
              }if (window.attachEvent)
              {window.attachEvent('onload', sa_async_load);
              }else {window.addEventListener('load', sa_async_load,false);
              }})();
          `
      }
    }), /*#__PURE__*/jsx_runtime_.jsx("script", {
      src: "https://static.klaviyo.com/onsite/js/klaviyo.js?company_id=MpJPGK"
    }), /*#__PURE__*/jsx_runtime_.jsx("script", {
      src: "https://a.klaviyo.com/media/js/onsite/onsite.js"
    }), /*#__PURE__*/jsx_runtime_.jsx("script", {
      type: "text/javascript",
      src: "https://cdnjs.cloudflare.com/ajax/libs/handlebars.js/3.0.3/handlebars.js"
    }), /*#__PURE__*/jsx_runtime_.jsx("script", {
      src: "https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"
    }), /*#__PURE__*/jsx_runtime_.jsx("script", {
      src: "//sandbox.unbxd.io/sleekhair_mybigcommerce_stage_autosuggest.js"
    }), console.log("router.asPath ", router.asPath), router.asPath.includes('/search') && /*#__PURE__*/(0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
      children: [/*#__PURE__*/jsx_runtime_.jsx("script", {
        src: "//sandbox.unbxd.io/sleekhair_mybigcommerce_stage_search.js"
      }), /*#__PURE__*/jsx_runtime_.jsx("script", {
        src: "//libraries.unbxdapi.com/search-sdk/v2.0.4/vanillaSearch.min.js"
      })]
    }), /*#__PURE__*/jsx_runtime_.jsx("script", {
      src: "https://unpkg.com/babel-standalone@6.15.0/babel.min.js"
    })]
  });
};

function usePages(pages) {
  const {
    locale
  } = (0,router_.useRouter)();
  const sitePages = [];

  if (pages) {
    pages.forEach(page => {
      const slug = page.url && (0,get_slug/* default */.Z)(page.url);
      if (!slug) return alert('page not found' + slug);
      if (locale && !slug.startsWith(`${locale}/`)) return;
      sitePages.push(page);
    });
  }

  return {
    sitePages: sitePages.sort(bySortOrder)
  };
} // Sort pages by the sort order assigned in the BC dashboard


function bySortOrder(a, b) {
  var _a$sort_order, _b$sort_order;

  return ((_a$sort_order = a.sort_order) !== null && _a$sort_order !== void 0 ? _a$sort_order : 0) - ((_b$sort_order = b.sort_order) !== null && _b$sort_order !== void 0 ? _b$sort_order : 0);
}

/* harmony default export */ const Footer_Footer = (Footer);
// EXTERNAL MODULE: ./components/ui/Button/Button.tsx
var Button = __webpack_require__(1180);
// EXTERNAL MODULE: ./components/icons/Cross.tsx
var Cross = __webpack_require__(4246);
;// CONCATENATED MODULE: ./components/icons/ChevronLeft.tsx
function ChevronLeft_ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) { symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); } keys.push.apply(keys, symbols); } return keys; }

function ChevronLeft_objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ChevronLeft_ownKeys(Object(source), true).forEach(function (key) { ChevronLeft_defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ChevronLeft_ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function ChevronLeft_defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }



const ChevronLeft = _ref => {
  let props = Object.assign({}, _ref);
  return /*#__PURE__*/jsx_runtime_.jsx("svg", ChevronLeft_objectSpread(ChevronLeft_objectSpread({
    viewBox: "0 0 24 24",
    width: "24",
    height: "24",
    stroke: "currentColor",
    strokeWidth: "1.5",
    strokeLinecap: "round",
    strokeLinejoin: "round",
    fill: "none",
    shapeRendering: "geometricPrecision"
  }, props), {}, {
    children: /*#__PURE__*/jsx_runtime_.jsx("path", {
      d: "M15 18l-6-6 6-6"
    })
  }));
};

/* harmony default export */ const icons_ChevronLeft = (ChevronLeft);
// EXTERNAL MODULE: ./components/common/SidebarLayout/SidebarLayout.module.css
var SidebarLayout_module = __webpack_require__(9826);
var SidebarLayout_module_default = /*#__PURE__*/__webpack_require__.n(SidebarLayout_module);
;// CONCATENATED MODULE: ./components/common/SidebarLayout/SidebarLayout.tsx








const SidebarLayout = ({
  children,
  className,
  handleClose,
  handleBack
}) => {
  return /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
    className: external_classnames_default()((SidebarLayout_module_default()).root, className),
    children: [/*#__PURE__*/(0,jsx_runtime_.jsxs)("header", {
      className: (SidebarLayout_module_default()).header,
      children: [handleClose && /*#__PURE__*/(0,jsx_runtime_.jsxs)("button", {
        onClick: handleClose,
        "aria-label": "Close",
        className: "hover:text-accent-5 transition ease-in-out duration-150 flex items-center focus:outline-none",
        children: [/*#__PURE__*/jsx_runtime_.jsx(Cross/* default */.Z, {
          className: "h-6 w-6 hover:text-accent-3"
        }), /*#__PURE__*/jsx_runtime_.jsx("span", {
          className: "ml-2 text-accent-7 text-sm ",
          children: "Close"
        })]
      }), handleBack && /*#__PURE__*/(0,jsx_runtime_.jsxs)("button", {
        onClick: handleBack,
        "aria-label": "Go back",
        className: "hover:text-accent-5 transition ease-in-out duration-150 flex items-center focus:outline-none",
        children: [/*#__PURE__*/jsx_runtime_.jsx(icons_ChevronLeft, {
          className: "h-6 w-6 hover:text-accent-3"
        }), /*#__PURE__*/jsx_runtime_.jsx("span", {
          className: "ml-2 text-accent-7 text-xs",
          children: "Back"
        })]
      }), /*#__PURE__*/jsx_runtime_.jsx("span", {
        className: (SidebarLayout_module_default()).nav,
        children: /*#__PURE__*/jsx_runtime_.jsx(UserNav_UserNav, {})
      })]
    }), /*#__PURE__*/jsx_runtime_.jsx("div", {
      className: (SidebarLayout_module_default()).container,
      children: children
    })]
  });
};

/* harmony default export */ const SidebarLayout_SidebarLayout = (SidebarLayout);
;// CONCATENATED MODULE: ./framework/commerce/customer/address/use-add-item.tsx
function use_add_item_ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) { symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); } keys.push.apply(keys, symbols); } return keys; }

function use_add_item_objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { use_add_item_ownKeys(Object(source), true).forEach(function (key) { use_add_item_defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { use_add_item_ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function use_add_item_defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }



const use_add_item_fetcher = default_fetcher/* mutationFetcher */.B5;

const use_add_item_fn = provider => {
  var _provider$customer, _provider$customer$ad;

  return (_provider$customer = provider.customer) === null || _provider$customer === void 0 ? void 0 : (_provider$customer$ad = _provider$customer.address) === null || _provider$customer$ad === void 0 ? void 0 : _provider$customer$ad.useAddItem;
};

const useAddItem = (...args) => {
  const hook = (0,use_hook/* useHook */.dV)(use_add_item_fn);
  return (0,use_hook/* useMutationHook */.wf)(use_add_item_objectSpread({
    fetcher: use_add_item_fetcher
  }, hook))(...args);
};

/* harmony default export */ const address_use_add_item = (useAddItem);
;// CONCATENATED MODULE: ./framework/bigcommerce/customer/address/use-add-item.tsx

/* harmony default export */ const customer_address_use_add_item = (address_use_add_item);
const use_add_item_handler = {
  fetchOptions: {
    query: ''
  },

  async fetcher({
    input,
    options,
    fetch
  }) {},

  useHook: ({
    fetch
  }) => () => async () => ({})
};
// EXTERNAL MODULE: ./components/checkout/ShippingView/ShippingView.module.css
var ShippingView_module = __webpack_require__(246);
var ShippingView_module_default = /*#__PURE__*/__webpack_require__.n(ShippingView_module);
;// CONCATENATED MODULE: ./components/checkout/ShippingView/ShippingView.tsx









const PaymentMethodView = () => {
  const {
    setSidebarView
  } = (0,context/* useUI */.l8)();
  const addAddress = customer_address_use_add_item();

  async function handleSubmit(event) {
    event.preventDefault();
    await addAddress({
      type: event.target.type.value,
      firstName: event.target.firstName.value,
      lastName: event.target.lastName.value,
      company: event.target.company.value,
      streetNumber: event.target.streetNumber.value,
      apartments: event.target.streetNumber.value,
      zipCode: event.target.zipCode.value,
      city: event.target.city.value,
      country: event.target.country.value
    });
    setSidebarView('CHECKOUT_VIEW');
  }

  return /*#__PURE__*/jsx_runtime_.jsx("form", {
    className: "h-full",
    onSubmit: handleSubmit,
    children: /*#__PURE__*/(0,jsx_runtime_.jsxs)(SidebarLayout_SidebarLayout, {
      handleBack: () => setSidebarView('CHECKOUT_VIEW'),
      children: [/*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
        className: "px-4 sm:px-6 flex-1",
        children: [/*#__PURE__*/jsx_runtime_.jsx("h2", {
          className: "pt-1 pb-8 text-2xl font-semibold tracking-wide cursor-pointer inline-block",
          children: "Shipping"
        }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
          children: [/*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
            className: "flex flex-row my-3 items-center",
            children: [/*#__PURE__*/jsx_runtime_.jsx("input", {
              name: "type",
              className: (ShippingView_module_default()).radio,
              type: "radio"
            }), /*#__PURE__*/jsx_runtime_.jsx("span", {
              className: "ml-3 text-sm",
              children: "Same as billing address"
            })]
          }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
            className: "flex flex-row my-3 items-center",
            children: [/*#__PURE__*/jsx_runtime_.jsx("input", {
              name: "type",
              className: (ShippingView_module_default()).radio,
              type: "radio"
            }), /*#__PURE__*/jsx_runtime_.jsx("span", {
              className: "ml-3 text-sm",
              children: "Use a different shipping address"
            })]
          }), /*#__PURE__*/jsx_runtime_.jsx("hr", {
            className: "border-accent-2 my-6"
          }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
            className: "grid gap-3 grid-flow-row grid-cols-12",
            children: [/*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
              className: external_classnames_default()((ShippingView_module_default()).fieldset, 'col-span-6'),
              children: [/*#__PURE__*/jsx_runtime_.jsx("label", {
                className: (ShippingView_module_default()).label,
                children: "First Name"
              }), /*#__PURE__*/jsx_runtime_.jsx("input", {
                name: "firstName",
                className: (ShippingView_module_default()).input
              })]
            }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
              className: external_classnames_default()((ShippingView_module_default()).fieldset, 'col-span-6'),
              children: [/*#__PURE__*/jsx_runtime_.jsx("label", {
                className: (ShippingView_module_default()).label,
                children: "Last Name"
              }), /*#__PURE__*/jsx_runtime_.jsx("input", {
                name: "lastName",
                className: (ShippingView_module_default()).input
              })]
            })]
          }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
            className: (ShippingView_module_default()).fieldset,
            children: [/*#__PURE__*/jsx_runtime_.jsx("label", {
              className: (ShippingView_module_default()).label,
              children: "Company (Optional)"
            }), /*#__PURE__*/jsx_runtime_.jsx("input", {
              name: "company",
              className: (ShippingView_module_default()).input
            })]
          }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
            className: (ShippingView_module_default()).fieldset,
            children: [/*#__PURE__*/jsx_runtime_.jsx("label", {
              className: (ShippingView_module_default()).label,
              children: "Street and House Number"
            }), /*#__PURE__*/jsx_runtime_.jsx("input", {
              name: "streetNumber",
              className: (ShippingView_module_default()).input
            })]
          }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
            className: (ShippingView_module_default()).fieldset,
            children: [/*#__PURE__*/jsx_runtime_.jsx("label", {
              className: (ShippingView_module_default()).label,
              children: "Apartment, Suite, Etc. (Optional)"
            }), /*#__PURE__*/jsx_runtime_.jsx("input", {
              name: "apartments",
              className: (ShippingView_module_default()).input
            })]
          }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
            className: "grid gap-3 grid-flow-row grid-cols-12",
            children: [/*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
              className: external_classnames_default()((ShippingView_module_default()).fieldset, 'col-span-6'),
              children: [/*#__PURE__*/jsx_runtime_.jsx("label", {
                className: (ShippingView_module_default()).label,
                children: "Postal Code"
              }), /*#__PURE__*/jsx_runtime_.jsx("input", {
                name: "zipCode",
                className: (ShippingView_module_default()).input
              })]
            }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
              className: external_classnames_default()((ShippingView_module_default()).fieldset, 'col-span-6'),
              children: [/*#__PURE__*/jsx_runtime_.jsx("label", {
                className: (ShippingView_module_default()).label,
                children: "City"
              }), /*#__PURE__*/jsx_runtime_.jsx("input", {
                name: "city",
                className: (ShippingView_module_default()).input
              })]
            })]
          }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
            className: (ShippingView_module_default()).fieldset,
            children: [/*#__PURE__*/jsx_runtime_.jsx("label", {
              className: (ShippingView_module_default()).label,
              children: "Country/Region"
            }), /*#__PURE__*/jsx_runtime_.jsx("select", {
              name: "country",
              className: (ShippingView_module_default()).select,
              children: /*#__PURE__*/jsx_runtime_.jsx("option", {
                children: "Hong Kong"
              })
            })]
          })]
        })]
      }), /*#__PURE__*/jsx_runtime_.jsx("div", {
        className: "sticky z-20 bottom-0 w-full right-0 left-0 py-12 bg-accent-0 border-t border-accent-2 px-6",
        children: /*#__PURE__*/jsx_runtime_.jsx(Button/* default */.Z, {
          type: "submit",
          width: "100%",
          variant: "ghost",
          children: "Continue"
        })
      })]
    })
  });
};

/* harmony default export */ const ShippingView = (PaymentMethodView);
// EXTERNAL MODULE: ./components/cart/CartSidebarView/CartSidebarView.module.css
var CartSidebarView_module = __webpack_require__(7585);
var CartSidebarView_module_default = /*#__PURE__*/__webpack_require__.n(CartSidebarView_module);
// EXTERNAL MODULE: ./components/cart/CartItem/CartItem.tsx + 3 modules
var CartItem = __webpack_require__(6921);
// EXTERNAL MODULE: ./components/ui/Text/Text.tsx
var Text = __webpack_require__(2361);
// EXTERNAL MODULE: ./components/icons/Bag.tsx
var Bag = __webpack_require__(3426);
// EXTERNAL MODULE: ./components/icons/Check.tsx + 1 modules
var Check = __webpack_require__(6245);
// EXTERNAL MODULE: ./framework/commerce/product/use-price.tsx
var use_price = __webpack_require__(5420);
;// CONCATENATED MODULE: ./components/cart/CartSidebarView/CartSidebarView.tsx














const CartSidebarView = () => {
  const {
    closeSidebar,
    setSidebarView
  } = (0,context/* useUI */.l8)();
  const {
    data,
    isLoading,
    isEmpty
  } = (0,use_cart/* default */.Z)();
  const {
    price: subTotal
  } = (0,use_price/* default */.ZP)(data && {
    amount: Number(data.subtotalPrice),
    currencyCode: data.currency.code
  });
  const {
    price: total
  } = (0,use_price/* default */.ZP)(data && {
    amount: Number(data.totalPrice),
    currencyCode: data.currency.code
  });

  const handleClose = () => closeSidebar();

  const goToCheckout = () => setSidebarView('CHECKOUT_VIEW');

  const error = null;
  const success = null;
  return /*#__PURE__*/jsx_runtime_.jsx(SidebarLayout_SidebarLayout, {
    className: external_classnames_default()({
      [(CartSidebarView_module_default()).empty]: error || success || isLoading || isEmpty
    }),
    handleClose: handleClose,
    children: isLoading || isEmpty ? /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
      className: "flex-1 px-4 flex flex-col justify-center items-center",
      children: [/*#__PURE__*/jsx_runtime_.jsx("span", {
        className: "border border-dashed border-primary rounded-full flex items-center justify-center w-16 h-16 p-12 bg-secondary text-secondary",
        children: /*#__PURE__*/jsx_runtime_.jsx(Bag/* default */.Z, {
          className: "absolute"
        })
      }), /*#__PURE__*/jsx_runtime_.jsx("h2", {
        className: "pt-6 text-2xl font-bold tracking-wide text-center",
        children: "Your cart is empty"
      }), /*#__PURE__*/jsx_runtime_.jsx("p", {
        className: "text-accent-3 px-10 text-center pt-2",
        children: "Biscuit oat cake wafer icing ice cream tiramisu pudding cupcake."
      })]
    }) : error ? /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
      className: "flex-1 px-4 flex flex-col justify-center items-center",
      children: [/*#__PURE__*/jsx_runtime_.jsx("span", {
        className: "border border-white rounded-full flex items-center justify-center w-16 h-16",
        children: /*#__PURE__*/jsx_runtime_.jsx(Cross/* default */.Z, {
          width: 24,
          height: 24
        })
      }), /*#__PURE__*/jsx_runtime_.jsx("h2", {
        className: "pt-6 text-xl font-light text-center",
        children: "We couldn\u2019t process the purchase. Please check your card information and try again."
      })]
    }) : success ? /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
      className: "flex-1 px-4 flex flex-col justify-center items-center",
      children: [/*#__PURE__*/jsx_runtime_.jsx("span", {
        className: "border border-white rounded-full flex items-center justify-center w-16 h-16",
        children: /*#__PURE__*/jsx_runtime_.jsx(Check/* default */.Z, {})
      }), /*#__PURE__*/jsx_runtime_.jsx("h2", {
        className: "pt-6 text-xl font-light text-center",
        children: "Thank you for your order."
      })]
    }) : /*#__PURE__*/(0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
      children: [/*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
        className: "px-4 sm:px-6 flex-1",
        children: [/*#__PURE__*/jsx_runtime_.jsx(next_link.default, {
          href: "/cart",
          children: /*#__PURE__*/jsx_runtime_.jsx("a", {
            children: /*#__PURE__*/jsx_runtime_.jsx(Text/* default */.Z, {
              variant: "sectionHeading",
              onClick: handleClose,
              children: "My Cart"
            })
          })
        }), /*#__PURE__*/jsx_runtime_.jsx("ul", {
          className: (CartSidebarView_module_default()).lineItemsList,
          children: data.lineItems.map(item => /*#__PURE__*/jsx_runtime_.jsx(CartItem/* default */.Z, {
            item: item,
            currencyCode: data.currency.code
          }, item.id))
        })]
      }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
        className: "flex-shrink-0 px-6 py-6 sm:px-6 sticky z-20 bottom-0 w-full right-0 left-0 bg-accent-0 border-t text-sm",
        children: [/*#__PURE__*/(0,jsx_runtime_.jsxs)("ul", {
          className: "pb-2",
          children: [/*#__PURE__*/(0,jsx_runtime_.jsxs)("li", {
            className: "flex justify-between py-1",
            children: [/*#__PURE__*/jsx_runtime_.jsx("span", {
              children: "Subtotal"
            }), /*#__PURE__*/jsx_runtime_.jsx("span", {
              children: subTotal
            })]
          }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("li", {
            className: "flex justify-between py-1",
            children: [/*#__PURE__*/jsx_runtime_.jsx("span", {
              children: "Taxes"
            }), /*#__PURE__*/jsx_runtime_.jsx("span", {
              children: "Calculated at checkout"
            })]
          }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("li", {
            className: "flex justify-between py-1",
            children: [/*#__PURE__*/jsx_runtime_.jsx("span", {
              children: "Shipping"
            }), /*#__PURE__*/jsx_runtime_.jsx("span", {
              className: "font-bold tracking-wide",
              children: "FREE"
            })]
          })]
        }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
          className: "flex justify-between border-t border-accent-2 py-3 font-bold mb-2",
          children: [/*#__PURE__*/jsx_runtime_.jsx("span", {
            children: "Total"
          }), /*#__PURE__*/jsx_runtime_.jsx("span", {
            children: total
          })]
        }), /*#__PURE__*/jsx_runtime_.jsx("div", {
          children: process.env.COMMERCE_CUSTOMCHECKOUT_ENABLED ? /*#__PURE__*/(0,jsx_runtime_.jsxs)(Button/* default */.Z, {
            Component: "a",
            width: "100%",
            onClick: goToCheckout,
            children: ["Proceed to Checkout (", total, ")"]
          }) : /*#__PURE__*/jsx_runtime_.jsx(Button/* default */.Z, {
            href: "/checkout",
            Component: "a",
            width: "100%",
            children: "Proceed to Checkout"
          })
        })]
      })]
    })
  });
};

/* harmony default export */ const CartSidebarView_CartSidebarView = (CartSidebarView);
// EXTERNAL MODULE: external "js-cookie"
var external_js_cookie_ = __webpack_require__(6155);
var external_js_cookie_default = /*#__PURE__*/__webpack_require__.n(external_js_cookie_);
;// CONCATENATED MODULE: ./lib/hooks/useAcceptCookies.ts


const COOKIE_NAME = 'accept_cookies';
const useAcceptCookies = () => {
  const {
    0: acceptedCookies,
    1: setAcceptedCookies
  } = (0,external_react_.useState)(true);
  (0,external_react_.useEffect)(() => {
    if (!external_js_cookie_default().get(COOKIE_NAME)) {
      setAcceptedCookies(false);
    }
  }, []);

  const acceptCookies = () => {
    setAcceptedCookies(true);
    external_js_cookie_default().set(COOKIE_NAME, 'accepted', {
      expires: 365
    });
  };

  return {
    acceptedCookies,
    onAcceptCookies: acceptCookies
  };
};
// EXTERNAL MODULE: ./components/ui/Modal/Modal.module.css
var Modal_module = __webpack_require__(3056);
var Modal_module_default = /*#__PURE__*/__webpack_require__.n(Modal_module);
// EXTERNAL MODULE: external "tabbable"
var external_tabbable_ = __webpack_require__(8047);
;// CONCATENATED MODULE: ./lib/focus-trap.tsx


function FocusTrap({
  children,
  focusFirst = false
}) {
  const root = external_react_default().useRef();
  const anchor = external_react_default().useRef(document.activeElement);

  const returnFocus = () => {
    // Returns focus to the last focused element prior to trap.
    if (anchor) {
      anchor.current.focus();
    }
  };

  const trapFocus = () => {
    // Focus the container element
    if (root.current) {
      root.current.focus();

      if (focusFirst) {
        selectFirstFocusableEl();
      }
    }
  };

  const selectFirstFocusableEl = () => {
    // Try to find focusable elements, if match then focus
    // Up to 6 seconds of load time threshold
    let match = false;
    let end = 60; // Try to find match at least n times

    let i = 0;
    const timer = setInterval(() => {
      if (!match !== i > end) {
        match = !!(0,external_tabbable_.tabbable)(root.current).length;

        if (match) {
          // Attempt to focus the first el
          (0,external_tabbable_.tabbable)(root.current)[0].focus();
        }

        i = i + 1;
      } else {
        // Clear interval after n attempts
        clearInterval(timer);
      }
    }, 100);
  };

  (0,external_react_.useEffect)(() => {
    setTimeout(trapFocus, 20);
    return () => {
      returnFocus();
    };
  }, [root, children]);
  return /*#__PURE__*/external_react_default().createElement('div', {
    ref: root,
    className: 'outline-none focus-trap',
    tabIndex: -1
  }, children);
}
// EXTERNAL MODULE: external "body-scroll-lock"
var external_body_scroll_lock_ = __webpack_require__(8023);
;// CONCATENATED MODULE: ./components/ui/Modal/Modal.tsx








const Modal = ({
  children,
  onClose
}) => {
  const ref = (0,external_react_.useRef)();
  const handleKey = (0,external_react_.useCallback)(e => {
    if (e.key === 'Escape') {
      return onClose();
    }
  }, [onClose]);
  (0,external_react_.useEffect)(() => {
    const modal = ref.current;

    if (modal) {
      (0,external_body_scroll_lock_.disableBodyScroll)(modal, {
        reserveScrollBarGap: true
      });
      window.addEventListener('keydown', handleKey);
    }

    return () => {
      if (modal) {
        (0,external_body_scroll_lock_.enableBodyScroll)(modal);
      }

      (0,external_body_scroll_lock_.clearAllBodyScrollLocks)();
      window.removeEventListener('keydown', handleKey);
    };
  }, [handleKey]);
  return /*#__PURE__*/jsx_runtime_.jsx("div", {
    className: (Modal_module_default()).root,
    children: /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
      className: (Modal_module_default()).modal,
      role: "dialog",
      ref: ref,
      children: [/*#__PURE__*/jsx_runtime_.jsx("button", {
        onClick: () => onClose(),
        "aria-label": "Close panel",
        className: (Modal_module_default()).close,
        children: /*#__PURE__*/jsx_runtime_.jsx(Cross/* default */.Z, {
          className: "h-6 w-6"
        })
      }), /*#__PURE__*/jsx_runtime_.jsx(FocusTrap, {
        focusFirst: true,
        children: children
      })]
    })
  });
};

/* harmony default export */ const Modal_Modal = (Modal);
// EXTERNAL MODULE: ./components/ui/Sidebar/Sidebar.module.css
var Sidebar_module = __webpack_require__(7856);
var Sidebar_module_default = /*#__PURE__*/__webpack_require__.n(Sidebar_module);
;// CONCATENATED MODULE: ./components/ui/Sidebar/Sidebar.tsx







const Sidebar = ({
  children,
  onClose
}) => {
  const sidebarRef = (0,external_react_.useRef)();
  const contentRef = (0,external_react_.useRef)();

  const onKeyDownSidebar = event => {
    if (event.code === 'Escape') {
      onClose();
    }
  };

  (0,external_react_.useEffect)(() => {
    if (sidebarRef.current) {
      sidebarRef.current.focus();
    }

    const contentElement = contentRef.current;

    if (contentElement) {
      (0,external_body_scroll_lock_.disableBodyScroll)(contentElement, {
        reserveScrollBarGap: true
      });
    }

    return () => {
      if (contentElement) (0,external_body_scroll_lock_.enableBodyScroll)(contentElement);
      (0,external_body_scroll_lock_.clearAllBodyScrollLocks)();
    };
  }, []);
  return /*#__PURE__*/jsx_runtime_.jsx("div", {
    className: external_classnames_default()((Sidebar_module_default()).root),
    ref: sidebarRef,
    onKeyDown: onKeyDownSidebar,
    tabIndex: 1,
    children: /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
      className: "absolute inset-0 overflow-hidden",
      children: [/*#__PURE__*/jsx_runtime_.jsx("div", {
        className: (Sidebar_module_default()).backdrop,
        onClick: onClose
      }), /*#__PURE__*/jsx_runtime_.jsx("section", {
        className: "absolute inset-y-0 right-0 max-w-full flex outline-none pl-10",
        children: /*#__PURE__*/jsx_runtime_.jsx("div", {
          className: "h-full w-full md:w-screen md:max-w-md",
          children: /*#__PURE__*/jsx_runtime_.jsx("div", {
            className: (Sidebar_module_default()).sidebar,
            ref: contentRef,
            children: children
          })
        })
      })]
    })
  });
};

/* harmony default export */ const Sidebar_Sidebar = (Sidebar);
// EXTERNAL MODULE: ./components/ui/LoadingDots/LoadingDots.tsx
var LoadingDots = __webpack_require__(3667);
// EXTERNAL MODULE: ./components/checkout/PaymentMethodView/PaymentMethodView.tsx
var PaymentMethodView_PaymentMethodView = __webpack_require__(2029);
;// CONCATENATED MODULE: ./framework/commerce/checkout/use-checkout.ts
function use_checkout_ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) { symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); } keys.push.apply(keys, symbols); } return keys; }

function use_checkout_objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { use_checkout_ownKeys(Object(source), true).forEach(function (key) { use_checkout_defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { use_checkout_ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function use_checkout_defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }




const use_checkout_fetcher = async ({
  options,
  input: {
    cartId
  },
  fetch
}) => {
  return cartId ? await fetch(options) : null;
};

const use_checkout_fn = provider => {
  var _provider$checkout;

  return (_provider$checkout = provider.checkout) === null || _provider$checkout === void 0 ? void 0 : _provider$checkout.useCheckout;
};

const useCheckout = input => {
  var _hook$fetcher;

  const hook = (0,use_hook/* useHook */.dV)(use_checkout_fn);
  const {
    cartCookie
  } = (0,commerce/* useCommerce */.aF)();
  const fetcherFn = (_hook$fetcher = hook.fetcher) !== null && _hook$fetcher !== void 0 ? _hook$fetcher : use_checkout_fetcher;

  const wrapper = context => {
    context.input.cartId = external_js_cookie_default().get(cartCookie);
    return fetcherFn(context);
  };

  return (0,use_hook/* useSWRHook */.Lz)(use_checkout_objectSpread(use_checkout_objectSpread({}, hook), {}, {
    fetcher: wrapper
  }))(input);
};

/* harmony default export */ const use_checkout = (useCheckout);
;// CONCATENATED MODULE: ./framework/bigcommerce/checkout/use-checkout.tsx

/* harmony default export */ const checkout_use_checkout = (use_checkout);
const use_checkout_handler = {
  fetchOptions: {
    query: ''
  },

  async fetcher({
    input,
    options,
    fetch
  }) {},

  useHook: ({
    useData
  }) => async input => ({})
};
// EXTERNAL MODULE: ./components/checkout/ShippingWidget/ShippingWidget.module.css
var ShippingWidget_module = __webpack_require__(6507);
var ShippingWidget_module_default = /*#__PURE__*/__webpack_require__.n(ShippingWidget_module);
// EXTERNAL MODULE: ./components/icons/MapPin.tsx
var MapPin = __webpack_require__(7323);
// EXTERNAL MODULE: ./components/icons/ChevronRight.tsx
var ChevronRight = __webpack_require__(2760);
;// CONCATENATED MODULE: ./components/checkout/ShippingWidget/ShippingWidget.tsx





const ShippingWidget = ({
  onClick,
  isValid
}) => {
  /* Shipping Address
  Only available with checkout set to true -
  This means that the provider does offer checkout functionality. */
  return /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
    onClick: onClick,
    className: (ShippingWidget_module_default()).root,
    children: [/*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
      className: "flex flex-1 items-center",
      children: [/*#__PURE__*/jsx_runtime_.jsx(MapPin/* default */.Z, {
        className: "w-5 flex"
      }), /*#__PURE__*/jsx_runtime_.jsx("span", {
        className: "ml-5 text-sm text-center font-medium",
        children: "Add Shipping Address"
      })]
    }), /*#__PURE__*/jsx_runtime_.jsx("div", {
      children: isValid ? /*#__PURE__*/jsx_runtime_.jsx(Check/* default */.Z, {}) : /*#__PURE__*/jsx_runtime_.jsx(ChevronRight/* default */.Z, {})
    })]
  });
};

/* harmony default export */ const ShippingWidget_ShippingWidget = (ShippingWidget);
// EXTERNAL MODULE: ./components/checkout/PaymentWidget/PaymentWidget.tsx
var PaymentWidget = __webpack_require__(732);
// EXTERNAL MODULE: ./components/checkout/CheckoutSidebarView/CheckoutSidebarView.module.css
var CheckoutSidebarView_module = __webpack_require__(4758);
var CheckoutSidebarView_module_default = /*#__PURE__*/__webpack_require__.n(CheckoutSidebarView_module);
;// CONCATENATED MODULE: ./components/checkout/CheckoutSidebarView/CheckoutSidebarView.tsx














const CheckoutSidebarView = () => {
  const {
    setSidebarView,
    closeSidebar
  } = (0,context/* useUI */.l8)();
  const {
    data: cartData
  } = (0,use_cart/* default */.Z)();
  const {
    data: checkoutData,
    submit: onCheckout
  } = checkout_use_checkout();

  async function handleSubmit(event) {
    event.preventDefault();
    await onCheckout();
    closeSidebar();
  }

  const {
    price: subTotal
  } = (0,use_price/* default */.ZP)(cartData && {
    amount: Number(cartData.subtotalPrice),
    currencyCode: cartData.currency.code
  });
  const {
    price: total
  } = (0,use_price/* default */.ZP)(cartData && {
    amount: Number(cartData.totalPrice),
    currencyCode: cartData.currency.code
  });
  return /*#__PURE__*/(0,jsx_runtime_.jsxs)(SidebarLayout_SidebarLayout, {
    className: (CheckoutSidebarView_module_default()).root,
    handleBack: () => setSidebarView('CART_VIEW'),
    children: [/*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
      className: "px-4 sm:px-6 flex-1",
      children: [/*#__PURE__*/jsx_runtime_.jsx(next_link.default, {
        href: "/cart",
        children: /*#__PURE__*/jsx_runtime_.jsx("a", {
          children: /*#__PURE__*/jsx_runtime_.jsx(Text/* default */.Z, {
            variant: "sectionHeading",
            children: "Checkout"
          })
        })
      }), /*#__PURE__*/jsx_runtime_.jsx(PaymentWidget/* default */.Z, {
        isValid: checkoutData === null || checkoutData === void 0 ? void 0 : checkoutData.hasPayment,
        onClick: () => setSidebarView('PAYMENT_VIEW')
      }), /*#__PURE__*/jsx_runtime_.jsx(ShippingWidget_ShippingWidget, {
        isValid: checkoutData === null || checkoutData === void 0 ? void 0 : checkoutData.hasShipping,
        onClick: () => setSidebarView('SHIPPING_VIEW')
      }), /*#__PURE__*/jsx_runtime_.jsx("ul", {
        className: (CheckoutSidebarView_module_default()).lineItemsList,
        children: cartData.lineItems.map(item => /*#__PURE__*/jsx_runtime_.jsx(CartItem/* default */.Z, {
          item: item,
          currencyCode: cartData.currency.code,
          variant: "display"
        }, item.id))
      })]
    }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("form", {
      onSubmit: handleSubmit,
      className: "flex-shrink-0 px-6 py-6 sm:px-6 sticky z-20 bottom-0 w-full right-0 left-0 bg-accent-0 border-t text-sm",
      children: [/*#__PURE__*/(0,jsx_runtime_.jsxs)("ul", {
        className: "pb-2",
        children: [/*#__PURE__*/(0,jsx_runtime_.jsxs)("li", {
          className: "flex justify-between py-1",
          children: [/*#__PURE__*/jsx_runtime_.jsx("span", {
            children: "Subtotal"
          }), /*#__PURE__*/jsx_runtime_.jsx("span", {
            children: subTotal
          })]
        }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("li", {
          className: "flex justify-between py-1",
          children: [/*#__PURE__*/jsx_runtime_.jsx("span", {
            children: "Taxes"
          }), /*#__PURE__*/jsx_runtime_.jsx("span", {
            children: "Calculated at checkout"
          })]
        }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("li", {
          className: "flex justify-between py-1",
          children: [/*#__PURE__*/jsx_runtime_.jsx("span", {
            children: "Shipping"
          }), /*#__PURE__*/jsx_runtime_.jsx("span", {
            className: "font-bold tracking-wide",
            children: "FREE"
          })]
        })]
      }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
        className: "flex justify-between border-t border-accent-2 py-3 font-bold mb-2",
        children: [/*#__PURE__*/jsx_runtime_.jsx("span", {
          children: "Total"
        }), /*#__PURE__*/jsx_runtime_.jsx("span", {
          children: total
        })]
      }), /*#__PURE__*/jsx_runtime_.jsx("div", {
        children: /*#__PURE__*/jsx_runtime_.jsx(Button/* default */.Z, {
          type: "submit",
          width: "100%",
          disabled: !(checkoutData !== null && checkoutData !== void 0 && checkoutData.hasPayment) || !(checkoutData !== null && checkoutData !== void 0 && checkoutData.hasShipping),
          children: "Confirm Purchase"
        })
      })]
    })]
  });
};

/* harmony default export */ const CheckoutSidebarView_CheckoutSidebarView = (CheckoutSidebarView);
// EXTERNAL MODULE: external "next/script"
var script_ = __webpack_require__(8689);
var script_default = /*#__PURE__*/__webpack_require__.n(script_);
// EXTERNAL MODULE: ./components/ui/Input/Input.tsx
var Input = __webpack_require__(7694);
// EXTERNAL MODULE: external "email-validator"
var external_email_validator_ = __webpack_require__(506);
;// CONCATENATED MODULE: ./components/auth/LoginView.tsx








const LoginView = () => {
  // Form State
  const {
    0: email,
    1: setEmail
  } = (0,external_react_.useState)('');
  const {
    0: password,
    1: setPassword
  } = (0,external_react_.useState)('');
  const {
    0: loading,
    1: setLoading
  } = (0,external_react_.useState)(false);
  const {
    0: message,
    1: setMessage
  } = (0,external_react_.useState)('');
  const {
    0: dirty,
    1: setDirty
  } = (0,external_react_.useState)(false);
  const {
    0: disabled,
    1: setDisabled
  } = (0,external_react_.useState)(false);
  const {
    setModalView,
    closeModal
  } = (0,context/* useUI */.l8)();
  const login = auth_use_login();

  const handleLogin = async e => {
    e.preventDefault();

    if (!dirty && !disabled) {
      setDirty(true);
      handleValidation();
    }

    try {
      setLoading(true);
      setMessage('');
      await login({
        email,
        password
      });
      setLoading(false);
      closeModal();
    } catch ({
      errors
    }) {
      setMessage(errors[0].message);
      setLoading(false);
      setDisabled(false);
    }
  };

  const handleValidation = (0,external_react_.useCallback)(() => {
    // Test for Alphanumeric password
    const validPassword = /^(?=.*[a-zA-Z])(?=.*[0-9])/.test(password); // Unable to send form unless fields are valid.

    if (dirty) {
      setDisabled(!(0,external_email_validator_.validate)(email) || password.length < 7 || !validPassword);
    }
  }, [email, password, dirty]);
  (0,external_react_.useEffect)(() => {
    handleValidation();
  }, [handleValidation]);
  return /*#__PURE__*/(0,jsx_runtime_.jsxs)("form", {
    onSubmit: handleLogin,
    className: "w-80 flex flex-col justify-between p-3",
    children: [/*#__PURE__*/jsx_runtime_.jsx("div", {
      className: "flex justify-center pb-12 ",
      children: /*#__PURE__*/jsx_runtime_.jsx(Logo/* default */.Z, {
        width: "64px",
        height: "64px"
      })
    }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
      className: "flex flex-col space-y-3",
      children: [message && /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
        className: "text-red border border-red p-3",
        children: [message, ". Did you ", ` `, /*#__PURE__*/jsx_runtime_.jsx("a", {
          className: "text-accent-9 inline font-bold hover:underline cursor-pointer",
          onClick: () => setModalView('FORGOT_VIEW'),
          children: "forgot your password?"
        })]
      }), /*#__PURE__*/jsx_runtime_.jsx(Input/* default */.Z, {
        type: "email",
        placeholder: "Email",
        onChange: setEmail
      }), /*#__PURE__*/jsx_runtime_.jsx(Input/* default */.Z, {
        type: "password",
        placeholder: "Password",
        onChange: setPassword
      }), /*#__PURE__*/jsx_runtime_.jsx(Button/* default */.Z, {
        variant: "slim",
        type: "submit",
        loading: loading,
        disabled: disabled,
        children: "Log In"
      }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
        className: "pt-1 text-center text-sm",
        children: [/*#__PURE__*/jsx_runtime_.jsx("span", {
          className: "text-accent-7",
          children: "Don't have an account?"
        }), ` `, /*#__PURE__*/jsx_runtime_.jsx("a", {
          className: "text-accent-9 font-bold hover:underline cursor-pointer",
          onClick: () => setModalView('SIGNUP_VIEW'),
          children: "Sign Up"
        })]
      })]
    })]
  });
};

/* harmony default export */ const auth_LoginView = (LoginView);
// EXTERNAL MODULE: ./components/common/Layout/Layout.module.css
var Layout_module = __webpack_require__(367);
var Layout_module_default = /*#__PURE__*/__webpack_require__.n(Layout_module);
;// CONCATENATED MODULE: ./components/common/Layout/Layout.tsx
const _excluded = ["categories"];

function _objectWithoutProperties(source, excluded) { if (source == null) return {}; var target = _objectWithoutPropertiesLoose(source, excluded); var key, i; if (Object.getOwnPropertySymbols) { var sourceSymbolKeys = Object.getOwnPropertySymbols(source); for (i = 0; i < sourceSymbolKeys.length; i++) { key = sourceSymbolKeys[i]; if (excluded.indexOf(key) >= 0) continue; if (!Object.prototype.propertyIsEnumerable.call(source, key)) continue; target[key] = source[key]; } } return target; }

function _objectWithoutPropertiesLoose(source, excluded) { if (source == null) return {}; var target = {}; var sourceKeys = Object.keys(source); var key, i; for (i = 0; i < sourceKeys.length; i++) { key = sourceKeys[i]; if (excluded.indexOf(key) >= 0) continue; target[key] = source[key]; } return target; }




















const Loading = () => /*#__PURE__*/jsx_runtime_.jsx("div", {
  className: "w-80 h-80 flex items-center text-center justify-center p-3",
  children: /*#__PURE__*/jsx_runtime_.jsx(LoadingDots/* default */.Z, {})
});

const dynamicProps = {
  loading: Loading
};
const SignUpView = (0,dynamic.default)(() => __webpack_require__.e(/* import() */ 255).then(__webpack_require__.bind(__webpack_require__, 2255)), dynamicProps);
const ForgotPassword = (0,dynamic.default)(() => __webpack_require__.e(/* import() */ 547).then(__webpack_require__.bind(__webpack_require__, 4547)), dynamicProps);
const FeatureBar = (0,dynamic.default)(() => __webpack_require__.e(/* import() */ 169).then(__webpack_require__.bind(__webpack_require__, 7169)), dynamicProps);

const ModalView = ({
  modalView,
  closeModal
}) => {
  return /*#__PURE__*/(0,jsx_runtime_.jsxs)(Modal_Modal, {
    onClose: closeModal,
    children: [modalView === 'LOGIN_VIEW' && /*#__PURE__*/jsx_runtime_.jsx(auth_LoginView, {}), modalView === 'SIGNUP_VIEW' && /*#__PURE__*/jsx_runtime_.jsx(SignUpView, {}), modalView === 'FORGOT_VIEW' && /*#__PURE__*/jsx_runtime_.jsx(ForgotPassword, {})]
  });
};

const ModalUI = () => {
  const {
    displayModal,
    closeModal,
    modalView
  } = (0,context/* useUI */.l8)();
  return displayModal ? /*#__PURE__*/jsx_runtime_.jsx(ModalView, {
    modalView: modalView,
    closeModal: closeModal
  }) : null;
};

const SidebarView = ({
  sidebarView,
  closeSidebar
}) => {
  return /*#__PURE__*/(0,jsx_runtime_.jsxs)(Sidebar_Sidebar, {
    onClose: closeSidebar,
    children: [sidebarView === 'CART_VIEW' && /*#__PURE__*/jsx_runtime_.jsx(CartSidebarView_CartSidebarView, {}), sidebarView === 'CHECKOUT_VIEW' && /*#__PURE__*/jsx_runtime_.jsx(CheckoutSidebarView_CheckoutSidebarView, {}), sidebarView === 'PAYMENT_VIEW' && /*#__PURE__*/jsx_runtime_.jsx(PaymentMethodView_PaymentMethodView/* default */.Z, {}), sidebarView === 'SHIPPING_VIEW' && /*#__PURE__*/jsx_runtime_.jsx(ShippingView, {})]
  });
};

const SidebarUI = () => {
  const {
    displaySidebar,
    closeSidebar,
    sidebarView
  } = (0,context/* useUI */.l8)();
  return displaySidebar ? /*#__PURE__*/jsx_runtime_.jsx(SidebarView, {
    sidebarView: sidebarView,
    closeSidebar: closeSidebar
  }) : null;
};

const Layout = _ref => {
  let {
    children,
    pageProps: {
      categories = []
    }
  } = _ref,
      pageProps = _objectWithoutProperties(_ref.pageProps, _excluded);

  const {
    acceptedCookies,
    onAcceptCookies
  } = useAcceptCookies();
  const {
    locale = 'en-US'
  } = (0,router_.useRouter)();
  const navBarlinks = categories.map(c => ({
    label: c.name,
    href: `/search/${c.slug}`
  }));
  return /*#__PURE__*/(0,jsx_runtime_.jsxs)(CommerceProvider, {
    locale: locale,
    children: [/*#__PURE__*/jsx_runtime_.jsx((script_default()), {
      src: "https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js",
      strategy: "beforeInteractive"
    }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
      className: external_classnames_default()((Layout_module_default()).root),
      children: [/*#__PURE__*/jsx_runtime_.jsx(Navbar_Navbar, {
        links: navBarlinks
      }), /*#__PURE__*/jsx_runtime_.jsx("main", {
        className: "fit MainNewTag",
        children: children
      }), /*#__PURE__*/jsx_runtime_.jsx(Footer_Footer, {
        pages: pageProps.pages
      }), /*#__PURE__*/jsx_runtime_.jsx(ModalUI, {}), /*#__PURE__*/jsx_runtime_.jsx(SidebarUI, {}), /*#__PURE__*/jsx_runtime_.jsx(FeatureBar, {
        title: "This site uses cookies to improve your experience. By clicking, you agree to our Privacy Policy.",
        hide: acceptedCookies,
        action: /*#__PURE__*/jsx_runtime_.jsx(Button/* default */.Z, {
          className: "mx-5",
          onClick: () => onAcceptCookies(),
          children: "Accept cookies"
        })
      })]
    })]
  });
};

/* harmony default export */ const Layout_Layout = (Layout);

/***/ }),

/***/ 3426:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _assets_sleekshop_new_svg_cart_svg__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6258);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5282);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);



const Bag = _ref => {
  let props = Object.assign({}, _ref);
  return (
    /*#__PURE__*/
    // <svg
    //   width="20"
    //   height="22"
    //   viewBox="0 0 20 22"
    //   fill="none"
    //   stroke="currentColor"
    //   {...props}
    // >
    //   <path
    //     d="M4 1L1 5V19C1 19.5304 1.21071 20.0391 1.58579 20.4142C1.96086 20.7893 2.46957 21 3 21H17C17.5304 21 18.0391 20.7893 18.4142 20.4142C18.7893 20.0391 19 19.5304 19 19V5L16 1H4Z"
    //     strokeWidth="1.5"
    //     strokeLinecap="round"
    //     strokeLinejoin="round"
    //   />
    //   <path
    //     d="M1 5H19"
    //     strokeWidth="1.5"
    //     strokeLinecap="round"
    //     strokeLinejoin="round"
    //   />
    //   <path
    //     d="M14 9C14 10.0609 13.5786 11.0783 12.8284 11.8284C12.0783 12.5786 11.0609 13 10 13C8.93913 13 7.92172 12.5786 7.17157 11.8284C6.42143 11.0783 6 10.0609 6 9"
    //     strokeWidth="1.5"
    //     strokeLinecap="round"
    //     strokeLinejoin="round"
    //   />
    // </svg>
    react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_assets_sleekshop_new_svg_cart_svg__WEBPACK_IMPORTED_MODULE_1__/* .default */ .Z, {})
  );
};

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Bag);

/***/ }),

/***/ 6245:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "Z": () => (/* binding */ icons_Check)
});

// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(9297);
;// CONCATENATED MODULE: ./assets/sleekshop-new-svg/checkbox.svg
var _path, _path2;

function _extends() { _extends = Object.assign || function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; }; return _extends.apply(this, arguments); }



var SvgCheckbox = function SvgCheckbox(props) {
  return /*#__PURE__*/external_react_.createElement("svg", _extends({
    width: 16,
    height: 16,
    fill: "none",
    xmlns: "http://www.w3.org/2000/svg"
  }, props), _path || (_path = /*#__PURE__*/external_react_.createElement("path", {
    d: "M0 2a2 2 0 0 1 2-2h12a2 2 0 0 1 2 2v12a2 2 0 0 1-2 2H2a2 2 0 0 1-2-2V2Z",
    fill: "#fff"
  })), _path2 || (_path2 = /*#__PURE__*/external_react_.createElement("path", {
    d: "M2 1h12v-2H2v2Zm13 1v12h2V2h-2Zm-1 13H2v2h12v-2ZM1 14V2h-2v12h2Zm1 1a1 1 0 0 1-1-1h-2a3 3 0 0 0 3 3v-2Zm13-1a1 1 0 0 1-1 1v2a3 3 0 0 0 3-3h-2ZM14 1a1 1 0 0 1 1 1h2a3 3 0 0 0-3-3v2ZM2-1a3 3 0 0 0-3 3h2a1 1 0 0 1 1-1v-2Z",
    fill: "#50585E"
  })));
};

/* harmony default export */ const sleekshop_new_svg_checkbox = (SvgCheckbox);
// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(5282);
;// CONCATENATED MODULE: ./components/icons/Check.tsx



const Check = _ref => {
  let props = Object.assign({}, _ref);
  return (
    /*#__PURE__*/
    // <svg
    //   width="24"
    //   height="24"
    //   viewBox="0 0 24 24"
    //   fill="none"
    //   stroke="currentColor"
    //   {...props}
    // >
    //   <path
    //     d="M20 6L9 17L4 12"
    //     strokeWidth="2"
    //     strokeLinecap="round"
    //     strokeLinejoin="round"
    //   />
    // </svg>
    jsx_runtime_.jsx(sleekshop_new_svg_checkbox, {})
  );
};

/* harmony default export */ const icons_Check = (Check);

/***/ }),

/***/ 2760:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5282);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) { symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); } keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }



const ChevronUp = _ref => {
  let props = Object.assign({}, _ref);
  return /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("svg", _objectSpread(_objectSpread({
    viewBox: "0 0 24 24",
    width: "24",
    height: "24",
    stroke: "currentColor",
    strokeWidth: "1.5",
    strokeLinecap: "round",
    strokeLinejoin: "round",
    fill: "none",
    shapeRendering: "geometricPrecision"
  }, props), {}, {
    children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
      d: "M9 18l6-6-6-6"
    })
  }));
};

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (ChevronUp);

/***/ }),

/***/ 4021:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5282);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) { symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); } keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }




const CreditCard = _ref => {
  let props = Object.assign({}, _ref);
  return /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("svg", _objectSpread(_objectSpread({
    viewBox: "0 0 24 24",
    width: "24",
    height: "24",
    stroke: "currentColor",
    strokeWidth: "1.5",
    strokeLinecap: "round",
    strokeLinejoin: "round",
    fill: "none",
    shapeRendering: "geometricPrecision"
  }, props), {}, {
    children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("rect", {
      x: "1",
      y: "4",
      width: "22",
      height: "16",
      rx: "2",
      ry: "2"
    }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
      d: "M1 10h22"
    })]
  }));
};

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (CreditCard);

/***/ }),

/***/ 4246:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5282);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) { symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); } keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }




const Cross = _ref => {
  let props = Object.assign({}, _ref);
  return /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("svg", _objectSpread(_objectSpread({
    viewBox: "0 0 24 24",
    width: "24",
    height: "24",
    stroke: "currentColor",
    strokeWidth: "1.5",
    strokeLinecap: "round",
    strokeLinejoin: "round",
    fill: "none",
    shapeRendering: "geometricPrecision"
  }, props), {}, {
    children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
      d: "M18 6L6 18"
    }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
      d: "M6 6l12 12"
    })]
  }));
};

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Cross);

/***/ }),

/***/ 7323:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _assets_sleekshop_new_svg_addresses_icon_svg__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(3372);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5282);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);



const MapPin = _ref => {
  let props = Object.assign({}, _ref);
  return (
    /*#__PURE__*/
    // <svg
    //   viewBox="0 0 24 24"
    //   width="24"
    //   height="24"
    //   stroke="currentColor"
    //   strokeWidth="1.5"
    //   strokeLinecap="round"
    //   strokeLinejoin="round"
    //   fill="none"
    //   shapeRendering="geometricPrecision"
    // >
    //   <path d="M21 10c0 7-9 13-9 13s-9-6-9-13a9 9 0 0118 0z" />
    //   <circle cx="12" cy="10" r="3" />
    // </svg>
    react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_assets_sleekshop_new_svg_addresses_icon_svg__WEBPACK_IMPORTED_MODULE_1__/* .default */ .Z, {})
  );
};

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (MapPin);

/***/ }),

/***/ 1180:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(4058);
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(classnames__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(9297);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react_merge_refs__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(123);
/* harmony import */ var react_merge_refs__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react_merge_refs__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _Button_module_css__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(8583);
/* harmony import */ var _Button_module_css__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(_Button_module_css__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _components_ui__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(3667);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(5282);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__);
const _excluded = ["className", "variant", "children", "active", "width", "loading", "disabled", "style", "Component"];

function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) { symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); } keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

function _objectWithoutProperties(source, excluded) { if (source == null) return {}; var target = _objectWithoutPropertiesLoose(source, excluded); var key, i; if (Object.getOwnPropertySymbols) { var sourceSymbolKeys = Object.getOwnPropertySymbols(source); for (i = 0; i < sourceSymbolKeys.length; i++) { key = sourceSymbolKeys[i]; if (excluded.indexOf(key) >= 0) continue; if (!Object.prototype.propertyIsEnumerable.call(source, key)) continue; target[key] = source[key]; } } return target; }

function _objectWithoutPropertiesLoose(source, excluded) { if (source == null) return {}; var target = {}; var sourceKeys = Object.keys(source); var key, i; for (i = 0; i < sourceKeys.length; i++) { key = sourceKeys[i]; if (excluded.indexOf(key) >= 0) continue; target[key] = source[key]; } return target; }








const Button = /*#__PURE__*/(0,react__WEBPACK_IMPORTED_MODULE_1__.forwardRef)((props, buttonRef) => {
  const {
    className,
    variant = 'flat',
    children,
    active,
    width,
    loading = false,
    disabled = false,
    style = {},
    Component = 'button'
  } = props,
        rest = _objectWithoutProperties(props, _excluded);

  const ref = (0,react__WEBPACK_IMPORTED_MODULE_1__.useRef)(null);
  const rootClassName = classnames__WEBPACK_IMPORTED_MODULE_0___default()((_Button_module_css__WEBPACK_IMPORTED_MODULE_4___default().root), {
    [(_Button_module_css__WEBPACK_IMPORTED_MODULE_4___default().ghost)]: variant === 'ghost',
    [(_Button_module_css__WEBPACK_IMPORTED_MODULE_4___default().slim)]: variant === 'slim',
    [(_Button_module_css__WEBPACK_IMPORTED_MODULE_4___default().naked)]: variant === 'naked',
    [(_Button_module_css__WEBPACK_IMPORTED_MODULE_4___default().loading)]: loading,
    [(_Button_module_css__WEBPACK_IMPORTED_MODULE_4___default().disabled)]: disabled
  }, className);
  return /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsxs)(Component, _objectSpread(_objectSpread({
    "aria-pressed": active,
    "data-variant": variant,
    ref: react_merge_refs__WEBPACK_IMPORTED_MODULE_2___default()([ref, buttonRef]),
    className: rootClassName,
    disabled: disabled,
    style: _objectSpread({
      width
    }, style)
  }, rest), {}, {
    children: [children, loading && /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsx("i", {
      className: "pl-2 m-0 flex",
      children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsx(_components_ui__WEBPACK_IMPORTED_MODULE_5__/* .default */ .Z, {})
    })]
  }));
});
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Button);

/***/ }),

/***/ 9698:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(4058);
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(classnames__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(9297);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(5282);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__);




const Container = ({
  children,
  className,
  el = 'div',
  clean
}) => {
  const rootClassName = classnames__WEBPACK_IMPORTED_MODULE_0___default()(className, {
    'mx-auto max-w-8xl px-6': !clean
  });
  let Component = el;
  return /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsx(Component, {
    className: rootClassName,
    children: children
  });
};

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Container);

/***/ }),

/***/ 7694:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(4058);
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(classnames__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _Input_module_css__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(8446);
/* harmony import */ var _Input_module_css__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_Input_module_css__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(9297);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(5282);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__);
const _excluded = ["className", "children", "onChange"];

function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) { symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); } keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

function _objectWithoutProperties(source, excluded) { if (source == null) return {}; var target = _objectWithoutPropertiesLoose(source, excluded); var key, i; if (Object.getOwnPropertySymbols) { var sourceSymbolKeys = Object.getOwnPropertySymbols(source); for (i = 0; i < sourceSymbolKeys.length; i++) { key = sourceSymbolKeys[i]; if (excluded.indexOf(key) >= 0) continue; if (!Object.prototype.propertyIsEnumerable.call(source, key)) continue; target[key] = source[key]; } } return target; }

function _objectWithoutPropertiesLoose(source, excluded) { if (source == null) return {}; var target = {}; var sourceKeys = Object.keys(source); var key, i; for (i = 0; i < sourceKeys.length; i++) { key = sourceKeys[i]; if (excluded.indexOf(key) >= 0) continue; target[key] = source[key]; } return target; }






const Input = props => {
  const {
    className,
    children,
    onChange
  } = props,
        rest = _objectWithoutProperties(props, _excluded);

  const rootClassName = classnames__WEBPACK_IMPORTED_MODULE_0___default()((_Input_module_css__WEBPACK_IMPORTED_MODULE_3___default().root), {}, className);

  const handleOnChange = e => {
    if (onChange) {
      onChange(e.target.value);
    }

    return null;
  };

  return /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsx("label", {
    children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsx("input", _objectSpread({
      className: rootClassName,
      onChange: handleOnChange,
      autoComplete: "off",
      autoCorrect: "off",
      autoCapitalize: "off",
      spellCheck: "false"
    }, rest))
  });
};

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Input);

/***/ }),

/***/ 3667:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _LoadingDots_module_css__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6884);
/* harmony import */ var _LoadingDots_module_css__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_LoadingDots_module_css__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5282);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);




const LoadingDots = () => {
  return /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
    className: (_LoadingDots_module_css__WEBPACK_IMPORTED_MODULE_1___default().root),
    children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
      className: (_LoadingDots_module_css__WEBPACK_IMPORTED_MODULE_1___default().dot)
    }, `dot_1`), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
      className: (_LoadingDots_module_css__WEBPACK_IMPORTED_MODULE_1___default().dot)
    }, `dot_2`), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
      className: (_LoadingDots_module_css__WEBPACK_IMPORTED_MODULE_1___default().dot)
    }, `dot_3`)]
  });
};

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (LoadingDots);

/***/ }),

/***/ 3668:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5675);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(5282);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__);
const _excluded = ["className"];

function _objectWithoutProperties(source, excluded) { if (source == null) return {}; var target = _objectWithoutPropertiesLoose(source, excluded); var key, i; if (Object.getOwnPropertySymbols) { var sourceSymbolKeys = Object.getOwnPropertySymbols(source); for (i = 0; i < sourceSymbolKeys.length; i++) { key = sourceSymbolKeys[i]; if (excluded.indexOf(key) >= 0) continue; if (!Object.prototype.propertyIsEnumerable.call(source, key)) continue; target[key] = source[key]; } } return target; }

function _objectWithoutPropertiesLoose(source, excluded) { if (source == null) return {}; var target = {}; var sourceKeys = Object.keys(source); var key, i; for (i = 0; i < sourceKeys.length; i++) { key = sourceKeys[i]; if (excluded.indexOf(key) >= 0) continue; target[key] = source[key]; } return target; }




const Logo = _ref => {
  let {
    className = ''
  } = _ref,
      props = _objectWithoutProperties(_ref, _excluded);

  return /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__.jsx(next_image__WEBPACK_IMPORTED_MODULE_0__.default, {
    src: "https://cdn11.bigcommerce.com/s-hmhnh4h9/images/stencil/original/sleekshop_logo_250x34px_1565895760__32121.original.png",
    width: "250",
    height: "34",
    alt: "Sleekshop Logo"
  });
};

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Logo);

/***/ }),

/***/ 2361:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(9297);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(4058);
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(classnames__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _Text_module_css__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(6526);
/* harmony import */ var _Text_module_css__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_Text_module_css__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(5282);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__);
function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) { symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); } keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }






const Text = ({
  style,
  className = '',
  variant = 'body',
  children,
  html,
  onClick
}) => {
  const componentsMap = {
    body: 'div',
    heading: 'h1',
    pageHeading: 'h1',
    sectionHeading: 'h2'
  };
  const Component = componentsMap[variant];
  const htmlContentProps = html ? {
    dangerouslySetInnerHTML: {
      __html: html
    }
  } : {};
  return /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsx(Component, _objectSpread(_objectSpread({
    className: classnames__WEBPACK_IMPORTED_MODULE_1___default()((_Text_module_css__WEBPACK_IMPORTED_MODULE_3___default().root), {
      [(_Text_module_css__WEBPACK_IMPORTED_MODULE_3___default().body)]: variant === 'body',
      [(_Text_module_css__WEBPACK_IMPORTED_MODULE_3___default().heading)]: variant === 'heading',
      [(_Text_module_css__WEBPACK_IMPORTED_MODULE_3___default().pageHeading)]: variant === 'pageHeading',
      [(_Text_module_css__WEBPACK_IMPORTED_MODULE_3___default().sectionHeading)]: variant === 'sectionHeading'
    }, className),
    onClick: onClick,
    style: style
  }, htmlContentProps), {}, {
    children: children
  }));
};

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Text);

/***/ }),

/***/ 4626:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "Z": () => (/* binding */ auth_use_logout),
  "y": () => (/* binding */ handler)
});

// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(9297);
// EXTERNAL MODULE: ./framework/commerce/utils/use-hook.ts + 2 modules
var use_hook = __webpack_require__(250);
// EXTERNAL MODULE: ./framework/commerce/utils/default-fetcher.ts
var default_fetcher = __webpack_require__(3449);
;// CONCATENATED MODULE: ./framework/commerce/auth/use-logout.tsx
function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) { symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); } keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }



const fetcher = default_fetcher/* mutationFetcher */.B5;

const fn = provider => {
  var _provider$auth;

  return (_provider$auth = provider.auth) === null || _provider$auth === void 0 ? void 0 : _provider$auth.useLogout;
};

const useLogout = (...args) => {
  const hook = (0,use_hook/* useHook */.dV)(fn);
  return (0,use_hook/* useMutationHook */.wf)(_objectSpread({
    fetcher
  }, hook))(...args);
};

/* harmony default export */ const use_logout = (useLogout);
// EXTERNAL MODULE: ./framework/bigcommerce/customer/use-customer.tsx + 1 modules
var use_customer = __webpack_require__(7951);
;// CONCATENATED MODULE: ./framework/bigcommerce/auth/use-logout.tsx



/* harmony default export */ const auth_use_logout = (use_logout);
const handler = {
  fetchOptions: {
    url: '/api/logout',
    method: 'GET'
  },
  useHook: ({
    fetch
  }) => () => {
    const {
      mutate
    } = (0,use_customer/* default */.Z)();
    return (0,external_react_.useCallback)(async function logout() {
      const data = await fetch();
      await mutate(null, false);
      return data;
    }, [fetch, mutate]);
  }
};

/***/ }),

/***/ 5301:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "Z": () => (/* binding */ auth_use_signup),
  "y": () => (/* binding */ handler)
});

// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(9297);
// EXTERNAL MODULE: ./framework/commerce/utils/errors.ts
var errors = __webpack_require__(6370);
// EXTERNAL MODULE: ./framework/commerce/utils/use-hook.ts + 2 modules
var use_hook = __webpack_require__(250);
// EXTERNAL MODULE: ./framework/commerce/utils/default-fetcher.ts
var default_fetcher = __webpack_require__(3449);
;// CONCATENATED MODULE: ./framework/commerce/auth/use-signup.tsx
function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) { symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); } keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }



const fetcher = default_fetcher/* mutationFetcher */.B5;

const fn = provider => {
  var _provider$auth;

  return (_provider$auth = provider.auth) === null || _provider$auth === void 0 ? void 0 : _provider$auth.useSignup;
};

const useSignup = (...args) => {
  const hook = (0,use_hook/* useHook */.dV)(fn);
  return (0,use_hook/* useMutationHook */.wf)(_objectSpread({
    fetcher
  }, hook))(...args);
};

/* harmony default export */ const use_signup = (useSignup);
// EXTERNAL MODULE: ./framework/bigcommerce/customer/use-customer.tsx + 1 modules
var use_customer = __webpack_require__(7951);
;// CONCATENATED MODULE: ./framework/bigcommerce/auth/use-signup.tsx
function use_signup_ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) { symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); } keys.push.apply(keys, symbols); } return keys; }

function use_signup_objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { use_signup_ownKeys(Object(source), true).forEach(function (key) { use_signup_defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { use_signup_ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function use_signup_defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }





/* harmony default export */ const auth_use_signup = (use_signup);
const handler = {
  fetchOptions: {
    url: '/api/signup',
    method: 'POST'
  },

  async fetcher({
    input: {
      firstName,
      lastName,
      email,
      password
    },
    options,
    fetch
  }) {
    if (!(firstName && lastName && email && password)) {
      throw new errors/* CommerceError */.yG({
        message: 'A first name, last name, email and password are required to signup'
      });
    }

    return fetch(use_signup_objectSpread(use_signup_objectSpread({}, options), {}, {
      body: {
        firstName,
        lastName,
        email,
        password
      }
    }));
  },

  useHook: ({
    fetch
  }) => () => {
    const {
      revalidate
    } = (0,use_customer/* default */.Z)();
    return (0,external_react_.useCallback)(async function signup(input) {
      const data = await fetch({
        input
      });
      await revalidate();
      return data;
    }, [fetch, revalidate]);
  }
};

/***/ }),

/***/ 3889:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "Z": () => (/* binding */ cart_use_add_item),
  "y": () => (/* binding */ handler)
});

// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(9297);
// EXTERNAL MODULE: ./framework/commerce/utils/errors.ts
var errors = __webpack_require__(6370);
// EXTERNAL MODULE: ./framework/commerce/utils/use-hook.ts + 2 modules
var use_hook = __webpack_require__(250);
// EXTERNAL MODULE: ./framework/commerce/utils/default-fetcher.ts
var default_fetcher = __webpack_require__(3449);
;// CONCATENATED MODULE: ./framework/commerce/cart/use-add-item.tsx
function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) { symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); } keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }



const fetcher = default_fetcher/* mutationFetcher */.B5;

const fn = provider => {
  var _provider$cart;

  return (_provider$cart = provider.cart) === null || _provider$cart === void 0 ? void 0 : _provider$cart.useAddItem;
};

const useAddItem = (...args) => {
  const hook = (0,use_hook/* useHook */.dV)(fn);
  return (0,use_hook/* useMutationHook */.wf)(_objectSpread({
    fetcher
  }, hook))(...args);
};

/* harmony default export */ const use_add_item = (useAddItem);
// EXTERNAL MODULE: ./framework/bigcommerce/cart/use-cart.tsx + 1 modules
var use_cart = __webpack_require__(3958);
;// CONCATENATED MODULE: ./framework/bigcommerce/cart/use-add-item.tsx
function use_add_item_ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) { symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); } keys.push.apply(keys, symbols); } return keys; }

function use_add_item_objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { use_add_item_ownKeys(Object(source), true).forEach(function (key) { use_add_item_defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { use_add_item_ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function use_add_item_defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }





/* harmony default export */ const cart_use_add_item = (use_add_item);
const handler = {
  fetchOptions: {
    url: '/api/cart',
    method: 'POST'
  },

  async fetcher({
    input: item,
    options,
    fetch
  }) {
    if (item.quantity && (!Number.isInteger(item.quantity) || item.quantity < 1)) {
      throw new errors/* CommerceError */.yG({
        message: 'The item quantity has to be a valid integer greater than 0'
      });
    }

    const data = await fetch(use_add_item_objectSpread(use_add_item_objectSpread({}, options), {}, {
      body: {
        item
      }
    }));
    return data;
  },

  useHook: ({
    fetch
  }) => () => {
    const {
      mutate
    } = (0,use_cart/* default */.Z)();
    return (0,external_react_.useCallback)(async function addItem(input) {
      const data = await fetch({
        input
      });
      await mutate(data, false);
      return data;
    }, [fetch, mutate]);
  }
};

/***/ }),

/***/ 3958:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "Z": () => (/* binding */ cart_use_cart),
  "y": () => (/* binding */ handler)
});

// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(9297);
// EXTERNAL MODULE: external "js-cookie"
var external_js_cookie_ = __webpack_require__(6155);
var external_js_cookie_default = /*#__PURE__*/__webpack_require__.n(external_js_cookie_);
// EXTERNAL MODULE: ./framework/commerce/utils/use-hook.ts + 2 modules
var use_hook = __webpack_require__(250);
// EXTERNAL MODULE: ./framework/commerce/index.tsx
var commerce = __webpack_require__(5112);
;// CONCATENATED MODULE: ./framework/commerce/cart/use-cart.tsx
function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) { symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); } keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }




const fetcher = async ({
  options,
  input: {
    cartId
  },
  fetch
}) => {
  return cartId ? await fetch(options) : null;
};

const fn = provider => {
  var _provider$cart;

  return (_provider$cart = provider.cart) === null || _provider$cart === void 0 ? void 0 : _provider$cart.useCart;
};

const useCart = input => {
  var _hook$fetcher;

  const hook = (0,use_hook/* useHook */.dV)(fn);
  const {
    cartCookie
  } = (0,commerce/* useCommerce */.aF)();
  const fetcherFn = (_hook$fetcher = hook.fetcher) !== null && _hook$fetcher !== void 0 ? _hook$fetcher : fetcher;

  const wrapper = context => {
    context.input.cartId = external_js_cookie_default().get(cartCookie);
    return fetcherFn(context);
  };

  return (0,use_hook/* useSWRHook */.Lz)(_objectSpread(_objectSpread({}, hook), {}, {
    fetcher: wrapper
  }))(input);
};

/* harmony default export */ const use_cart = (useCart);
;// CONCATENATED MODULE: ./framework/bigcommerce/cart/use-cart.tsx
function use_cart_ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) { symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); } keys.push.apply(keys, symbols); } return keys; }

function use_cart_objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { use_cart_ownKeys(Object(source), true).forEach(function (key) { use_cart_defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { use_cart_ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function use_cart_defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }



/* harmony default export */ const cart_use_cart = (use_cart);
const handler = {
  fetchOptions: {
    url: '/api/cart',
    method: 'GET'
  },
  useHook: ({
    useData
  }) => input => {
    const response = useData({
      swrOptions: use_cart_objectSpread({
        revalidateOnFocus: false
      }, input === null || input === void 0 ? void 0 : input.swrOptions)
    });
    return (0,external_react_.useMemo)(() => Object.create(response, {
      isEmpty: {
        get() {
          var _response$data$lineIt, _response$data;

          return ((_response$data$lineIt = (_response$data = response.data) === null || _response$data === void 0 ? void 0 : _response$data.lineItems.length) !== null && _response$data$lineIt !== void 0 ? _response$data$lineIt : 0) <= 0;
        },

        enumerable: true
      }
    }), [response]);
  }
};

/***/ }),

/***/ 6769:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "Z": () => (/* binding */ cart_use_remove_item),
  "y": () => (/* binding */ handler)
});

// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(9297);
// EXTERNAL MODULE: ./framework/commerce/utils/errors.ts
var errors = __webpack_require__(6370);
// EXTERNAL MODULE: ./framework/commerce/utils/use-hook.ts + 2 modules
var use_hook = __webpack_require__(250);
// EXTERNAL MODULE: ./framework/commerce/utils/default-fetcher.ts
var default_fetcher = __webpack_require__(3449);
;// CONCATENATED MODULE: ./framework/commerce/cart/use-remove-item.tsx
function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) { symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); } keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }



const fetcher = default_fetcher/* mutationFetcher */.B5;

const fn = provider => {
  var _provider$cart;

  return (_provider$cart = provider.cart) === null || _provider$cart === void 0 ? void 0 : _provider$cart.useRemoveItem;
};

const useRemoveItem = input => {
  const hook = (0,use_hook/* useHook */.dV)(fn);
  return (0,use_hook/* useMutationHook */.wf)(_objectSpread({
    fetcher
  }, hook))(input);
};

/* harmony default export */ const use_remove_item = (useRemoveItem);
// EXTERNAL MODULE: ./framework/bigcommerce/cart/use-cart.tsx + 1 modules
var use_cart = __webpack_require__(3958);
;// CONCATENATED MODULE: ./framework/bigcommerce/cart/use-remove-item.tsx
function use_remove_item_ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) { symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); } keys.push.apply(keys, symbols); } return keys; }

function use_remove_item_objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { use_remove_item_ownKeys(Object(source), true).forEach(function (key) { use_remove_item_defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { use_remove_item_ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function use_remove_item_defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }





/* harmony default export */ const cart_use_remove_item = (use_remove_item);
const handler = {
  fetchOptions: {
    url: '/api/cart',
    method: 'DELETE'
  },

  async fetcher({
    input: {
      itemId
    },
    options,
    fetch
  }) {
    return await fetch(use_remove_item_objectSpread(use_remove_item_objectSpread({}, options), {}, {
      body: {
        itemId
      }
    }));
  },

  useHook: ({
    fetch
  }) => (ctx = {}) => {
    const {
      item
    } = ctx;
    const {
      mutate
    } = (0,use_cart/* default */.Z)();

    const removeItem = async input => {
      var _input$id;

      const itemId = (_input$id = input === null || input === void 0 ? void 0 : input.id) !== null && _input$id !== void 0 ? _input$id : item === null || item === void 0 ? void 0 : item.id;

      if (!itemId) {
        throw new errors/* ValidationError */.p8({
          message: 'Invalid input used for this operation'
        });
      }

      const data = await fetch({
        input: {
          itemId
        }
      });
      await mutate(data, false);
      return data;
    };

    return (0,external_react_.useCallback)(removeItem, [fetch, mutate]);
  }
};

/***/ }),

/***/ 2655:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "Z": () => (/* binding */ cart_use_update_item),
  "y": () => (/* binding */ handler)
});

// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(9297);
// EXTERNAL MODULE: external "lodash.debounce"
var external_lodash_debounce_ = __webpack_require__(5371);
var external_lodash_debounce_default = /*#__PURE__*/__webpack_require__.n(external_lodash_debounce_);
// EXTERNAL MODULE: ./framework/commerce/utils/errors.ts
var errors = __webpack_require__(6370);
// EXTERNAL MODULE: ./framework/commerce/utils/use-hook.ts + 2 modules
var use_hook = __webpack_require__(250);
// EXTERNAL MODULE: ./framework/commerce/utils/default-fetcher.ts
var default_fetcher = __webpack_require__(3449);
;// CONCATENATED MODULE: ./framework/commerce/cart/use-update-item.tsx
function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) { symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); } keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }



const fetcher = default_fetcher/* mutationFetcher */.B5;

const fn = provider => {
  var _provider$cart;

  return (_provider$cart = provider.cart) === null || _provider$cart === void 0 ? void 0 : _provider$cart.useUpdateItem;
};

const useUpdateItem = input => {
  const hook = (0,use_hook/* useHook */.dV)(fn);
  return (0,use_hook/* useMutationHook */.wf)(_objectSpread({
    fetcher
  }, hook))(input);
};

/* harmony default export */ const use_update_item = (useUpdateItem);
// EXTERNAL MODULE: ./framework/bigcommerce/cart/use-remove-item.tsx + 1 modules
var use_remove_item = __webpack_require__(6769);
// EXTERNAL MODULE: ./framework/bigcommerce/cart/use-cart.tsx + 1 modules
var use_cart = __webpack_require__(3958);
;// CONCATENATED MODULE: ./framework/bigcommerce/cart/use-update-item.tsx
function use_update_item_ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) { symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); } keys.push.apply(keys, symbols); } return keys; }

function use_update_item_objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { use_update_item_ownKeys(Object(source), true).forEach(function (key) { use_update_item_defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { use_update_item_ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function use_update_item_defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }







/* harmony default export */ const cart_use_update_item = (use_update_item);
const handler = {
  fetchOptions: {
    url: '/api/cart',
    method: 'PUT'
  },

  async fetcher({
    input: {
      itemId,
      item
    },
    options,
    fetch
  }) {
    if (Number.isInteger(item.quantity)) {
      // Also allow the update hook to remove an item if the quantity is lower than 1
      if (item.quantity < 1) {
        return use_remove_item/* handler.fetcher */.y.fetcher({
          options: use_remove_item/* handler.fetchOptions */.y.fetchOptions,
          input: {
            itemId
          },
          fetch
        });
      }
    } else if (item.quantity) {
      throw new errors/* ValidationError */.p8({
        message: 'The item quantity has to be a valid integer'
      });
    }

    return await fetch(use_update_item_objectSpread(use_update_item_objectSpread({}, options), {}, {
      body: {
        itemId,
        item
      }
    }));
  },

  useHook: ({
    fetch
  }) => (ctx = {}) => {
    var _ctx$wait;

    const {
      item
    } = ctx;
    const {
      mutate
    } = (0,use_cart/* default */.Z)();
    return (0,external_react_.useCallback)(external_lodash_debounce_default()(async input => {
      var _input$id, _input$productId, _input$productId2;

      const itemId = (_input$id = input.id) !== null && _input$id !== void 0 ? _input$id : item === null || item === void 0 ? void 0 : item.id;
      const productId = (_input$productId = input.productId) !== null && _input$productId !== void 0 ? _input$productId : item === null || item === void 0 ? void 0 : item.productId;
      const variantId = (_input$productId2 = input.productId) !== null && _input$productId2 !== void 0 ? _input$productId2 : item === null || item === void 0 ? void 0 : item.variantId;

      if (!itemId || !productId || !variantId) {
        throw new errors/* ValidationError */.p8({
          message: 'Invalid input used for this operation'
        });
      }

      const data = await fetch({
        input: {
          itemId,
          item: {
            productId,
            variantId,
            quantity: input.quantity
          }
        }
      });
      await mutate(data, false);
      return data;
    }, (_ctx$wait = ctx.wait) !== null && _ctx$wait !== void 0 ? _ctx$wait : 500), [fetch, mutate]);
  }
};

/***/ }),

/***/ 7951:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "Z": () => (/* binding */ customer_use_customer),
  "y": () => (/* binding */ handler)
});

// EXTERNAL MODULE: ./framework/commerce/utils/use-hook.ts + 2 modules
var use_hook = __webpack_require__(250);
// EXTERNAL MODULE: ./framework/commerce/utils/default-fetcher.ts
var default_fetcher = __webpack_require__(3449);
;// CONCATENATED MODULE: ./framework/commerce/customer/use-customer.tsx
function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) { symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); } keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }



const fetcher = default_fetcher/* SWRFetcher */.DO;

const fn = provider => {
  var _provider$customer;

  return (_provider$customer = provider.customer) === null || _provider$customer === void 0 ? void 0 : _provider$customer.useCustomer;
};

const useCustomer = input => {
  const hook = (0,use_hook/* useHook */.dV)(fn);
  return (0,use_hook/* useSWRHook */.Lz)(_objectSpread({
    fetcher
  }, hook))(input);
};

/* harmony default export */ const use_customer = (useCustomer);
;// CONCATENATED MODULE: ./framework/bigcommerce/customer/use-customer.tsx
function use_customer_ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) { symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); } keys.push.apply(keys, symbols); } return keys; }

function use_customer_objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { use_customer_ownKeys(Object(source), true).forEach(function (key) { use_customer_defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { use_customer_ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function use_customer_defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }


/* harmony default export */ const customer_use_customer = (use_customer);
const handler = {
  fetchOptions: {
    url: '/api/customer',
    method: 'GET'
  },

  async fetcher({
    options,
    fetch
  }) {
    var _data$customer;

    const data = await fetch(options);
    return (_data$customer = data === null || data === void 0 ? void 0 : data.customer) !== null && _data$customer !== void 0 ? _data$customer : null;
  },

  useHook: ({
    useData
  }) => input => {
    return useData({
      swrOptions: use_customer_objectSpread({
        revalidateOnFocus: false
      }, input === null || input === void 0 ? void 0 : input.swrOptions)
    });
  }
};

/***/ }),

/***/ 6371:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "Z": () => (/* binding */ product_use_search),
  "y": () => (/* binding */ handler)
});

// EXTERNAL MODULE: ./framework/commerce/utils/use-hook.ts + 2 modules
var use_hook = __webpack_require__(250);
// EXTERNAL MODULE: ./framework/commerce/utils/default-fetcher.ts
var default_fetcher = __webpack_require__(3449);
;// CONCATENATED MODULE: ./framework/commerce/product/use-search.tsx
function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) { symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); } keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }



const fetcher = default_fetcher/* SWRFetcher */.DO;

const fn = provider => {
  var _provider$products;

  return (_provider$products = provider.products) === null || _provider$products === void 0 ? void 0 : _provider$products.useSearch;
};

const useSearch = input => {
  const hook = (0,use_hook/* useHook */.dV)(fn);
  return (0,use_hook/* useSWRHook */.Lz)(_objectSpread({
    fetcher
  }, hook))(input);
};

/* harmony default export */ const use_search = (useSearch);
;// CONCATENATED MODULE: ./framework/bigcommerce/product/use-search.tsx
function use_search_ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) { symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); } keys.push.apply(keys, symbols); } return keys; }

function use_search_objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { use_search_ownKeys(Object(source), true).forEach(function (key) { use_search_defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { use_search_ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function use_search_defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }


/* harmony default export */ const product_use_search = (use_search);
const handler = {
  fetchOptions: {
    url: '/api/catalog/products',
    method: 'GET'
  },

  fetcher({
    input: {
      search,
      categoryId,
      brandId,
      sort
    },
    options,
    fetch
  }) {
    // Use a dummy base as we only care about the relative path
    const url = new URL(options.url, 'http://a');
    if (search) url.searchParams.set('search', search);
    if (Number.isInteger(Number(categoryId))) url.searchParams.set('categoryId', String(categoryId));
    if (Number.isInteger(brandId)) url.searchParams.set('brandId', String(brandId));
    if (sort) url.searchParams.set('sort', sort);
    return fetch({
      url: url.pathname + url.search,
      method: options.method
    });
  },

  useHook: ({
    useData
  }) => (input = {}) => {
    return useData({
      input: [['search', input.search], ['categoryId', input.categoryId], ['brandId', input.brandId], ['sort', input.sort]],
      swrOptions: use_search_objectSpread({
        revalidateOnFocus: false
      }, input.swrOptions)
    });
  }
};

/***/ }),

/***/ 1237:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "Z": () => (/* binding */ wishlist_use_add_item),
  "y": () => (/* binding */ handler)
});

// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(9297);
// EXTERNAL MODULE: ./framework/commerce/utils/errors.ts
var errors = __webpack_require__(6370);
// EXTERNAL MODULE: ./framework/commerce/utils/use-hook.ts + 2 modules
var use_hook = __webpack_require__(250);
// EXTERNAL MODULE: ./framework/commerce/utils/default-fetcher.ts
var default_fetcher = __webpack_require__(3449);
;// CONCATENATED MODULE: ./framework/commerce/wishlist/use-add-item.tsx
function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) { symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); } keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }



const fetcher = default_fetcher/* mutationFetcher */.B5;

const fn = provider => {
  var _provider$wishlist;

  return (_provider$wishlist = provider.wishlist) === null || _provider$wishlist === void 0 ? void 0 : _provider$wishlist.useAddItem;
};

const useAddItem = (...args) => {
  const hook = (0,use_hook/* useHook */.dV)(fn);
  return (0,use_hook/* useMutationHook */.wf)(_objectSpread({
    fetcher
  }, hook))(...args);
};

/* harmony default export */ const use_add_item = (useAddItem);
// EXTERNAL MODULE: ./framework/bigcommerce/customer/use-customer.tsx + 1 modules
var use_customer = __webpack_require__(7951);
// EXTERNAL MODULE: ./framework/bigcommerce/wishlist/use-wishlist.tsx + 1 modules
var use_wishlist = __webpack_require__(2056);
;// CONCATENATED MODULE: ./framework/bigcommerce/wishlist/use-add-item.tsx





/* harmony default export */ const wishlist_use_add_item = (use_add_item);
const handler = {
  fetchOptions: {
    url: '/api/wishlist',
    method: 'POST'
  },
  useHook: ({
    fetch
  }) => () => {
    const {
      data: customer
    } = (0,use_customer/* default */.Z)();
    const {
      revalidate
    } = (0,use_wishlist/* default */.Z)();
    return (0,external_react_.useCallback)(async function addItem(item) {
      if (!customer) {
        // A signed customer is required in order to have a wishlist
        throw new errors/* CommerceError */.yG({
          message: 'Signed customer not found'
        });
      } // TODO: add validations before doing the fetch


      const data = await fetch({
        input: {
          item
        }
      });
      await revalidate();
      return data;
    }, [fetch, revalidate, customer]);
  }
};

/***/ }),

/***/ 5295:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "Z": () => (/* binding */ wishlist_use_remove_item),
  "y": () => (/* binding */ handler)
});

// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(9297);
// EXTERNAL MODULE: ./framework/commerce/utils/errors.ts
var errors = __webpack_require__(6370);
// EXTERNAL MODULE: ./framework/commerce/utils/use-hook.ts + 2 modules
var use_hook = __webpack_require__(250);
// EXTERNAL MODULE: ./framework/commerce/utils/default-fetcher.ts
var default_fetcher = __webpack_require__(3449);
;// CONCATENATED MODULE: ./framework/commerce/wishlist/use-remove-item.tsx
function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) { symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); } keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }



const fetcher = default_fetcher/* mutationFetcher */.B5;

const fn = provider => {
  var _provider$wishlist;

  return (_provider$wishlist = provider.wishlist) === null || _provider$wishlist === void 0 ? void 0 : _provider$wishlist.useRemoveItem;
};

const useRemoveItem = (...args) => {
  const hook = (0,use_hook/* useHook */.dV)(fn);
  return (0,use_hook/* useMutationHook */.wf)(_objectSpread({
    fetcher
  }, hook))(...args);
};

/* harmony default export */ const use_remove_item = (useRemoveItem);
// EXTERNAL MODULE: ./framework/bigcommerce/customer/use-customer.tsx + 1 modules
var use_customer = __webpack_require__(7951);
// EXTERNAL MODULE: ./framework/bigcommerce/wishlist/use-wishlist.tsx + 1 modules
var use_wishlist = __webpack_require__(2056);
;// CONCATENATED MODULE: ./framework/bigcommerce/wishlist/use-remove-item.tsx





/* harmony default export */ const wishlist_use_remove_item = (use_remove_item);
const handler = {
  fetchOptions: {
    url: '/api/wishlist',
    method: 'DELETE'
  },
  useHook: ({
    fetch
  }) => ({
    wishlist
  } = {}) => {
    const {
      data: customer
    } = (0,use_customer/* default */.Z)();
    const {
      revalidate
    } = (0,use_wishlist/* default */.Z)(wishlist);
    return (0,external_react_.useCallback)(async function removeItem(input) {
      if (!customer) {
        // A signed customer is required in order to have a wishlist
        throw new errors/* CommerceError */.yG({
          message: 'Signed customer not found'
        });
      }

      const data = await fetch({
        input: {
          itemId: String(input.id)
        }
      });
      await revalidate();
      return data;
    }, [fetch, revalidate, customer]);
  }
};

/***/ }),

/***/ 2056:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "Z": () => (/* binding */ wishlist_use_wishlist),
  "y": () => (/* binding */ handler)
});

// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(9297);
// EXTERNAL MODULE: ./framework/commerce/utils/use-hook.ts + 2 modules
var use_hook = __webpack_require__(250);
// EXTERNAL MODULE: ./framework/commerce/utils/default-fetcher.ts
var default_fetcher = __webpack_require__(3449);
;// CONCATENATED MODULE: ./framework/commerce/wishlist/use-wishlist.tsx
function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) { symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); } keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }



const fetcher = default_fetcher/* SWRFetcher */.DO;

const fn = provider => {
  var _provider$wishlist;

  return (_provider$wishlist = provider.wishlist) === null || _provider$wishlist === void 0 ? void 0 : _provider$wishlist.useWishlist;
};

const useWishlist = (...args) => {
  const hook = (0,use_hook/* useHook */.dV)(fn);
  return (0,use_hook/* useSWRHook */.Lz)(_objectSpread({
    fetcher
  }, hook))(...args);
};

/* harmony default export */ const use_wishlist = (useWishlist);
// EXTERNAL MODULE: ./framework/bigcommerce/customer/use-customer.tsx + 1 modules
var use_customer = __webpack_require__(7951);
;// CONCATENATED MODULE: ./framework/bigcommerce/wishlist/use-wishlist.tsx
function use_wishlist_ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) { symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); } keys.push.apply(keys, symbols); } return keys; }

function use_wishlist_objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { use_wishlist_ownKeys(Object(source), true).forEach(function (key) { use_wishlist_defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { use_wishlist_ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function use_wishlist_defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }




/* harmony default export */ const wishlist_use_wishlist = (use_wishlist);
const handler = {
  fetchOptions: {
    url: '/api/wishlist',
    method: 'GET'
  },

  async fetcher({
    input: {
      customerId,
      includeProducts
    },
    options,
    fetch
  }) {
    // console.log("inside wishlist page use-wishlist.tsx fetcher");
    if (!customerId) return null; // Use a dummy base as we only care about the relative path

    const url = new URL(options.url, 'http://a');
    if (includeProducts) url.searchParams.set('products', '1');
    return fetch({
      url: url.pathname + url.search,
      method: options.method
    });
  },

  useHook: ({
    useData
  }) => input => {
    // console.log("inside wishlist page use-wishlist.tsx hooks");
    const {
      data: customer
    } = (0,use_customer/* default */.Z)();
    const response = useData({
      input: [['customerId', customer === null || customer === void 0 ? void 0 : customer.entityId], ['includeProducts', input === null || input === void 0 ? void 0 : input.includeProducts]],
      swrOptions: use_wishlist_objectSpread({
        revalidateOnFocus: false
      }, input === null || input === void 0 ? void 0 : input.swrOptions)
    });
    return (0,external_react_.useMemo)(() => Object.create(response, {
      isEmpty: {
        get() {
          var _response$data, _response$data$items;

          // console.log("inside wishlist page use-wishlist.tsx usememo");
          return (((_response$data = response.data) === null || _response$data === void 0 ? void 0 : (_response$data$items = _response$data.items) === null || _response$data$items === void 0 ? void 0 : _response$data$items.length) || 0) <= 0;
        },

        enumerable: true
      }
    }), [response]);
  }
};

/***/ }),

/***/ 5112:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "DX": () => (/* binding */ getCommerceProvider),
/* harmony export */   "aF": () => (/* binding */ useCommerce)
/* harmony export */ });
/* unused harmony export CoreCommerceProvider */
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(9297);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(5282);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__);
const _excluded = ["children"];

function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) { symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); } keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

function _objectWithoutProperties(source, excluded) { if (source == null) return {}; var target = _objectWithoutPropertiesLoose(source, excluded); var key, i; if (Object.getOwnPropertySymbols) { var sourceSymbolKeys = Object.getOwnPropertySymbols(source); for (i = 0; i < sourceSymbolKeys.length; i++) { key = sourceSymbolKeys[i]; if (excluded.indexOf(key) >= 0) continue; if (!Object.prototype.propertyIsEnumerable.call(source, key)) continue; target[key] = source[key]; } } return target; }

function _objectWithoutPropertiesLoose(source, excluded) { if (source == null) return {}; var target = {}; var sourceKeys = Object.keys(source); var key, i; for (i = 0; i < sourceKeys.length; i++) { key = sourceKeys[i]; if (excluded.indexOf(key) >= 0) continue; target[key] = source[key]; } return target; }



const Commerce = /*#__PURE__*/(0,react__WEBPACK_IMPORTED_MODULE_0__.createContext)({});
function CoreCommerceProvider({
  provider,
  children
}) {
  const providerRef = (0,react__WEBPACK_IMPORTED_MODULE_0__.useRef)(provider); // TODO: Remove the fetcherRef

  const fetcherRef = (0,react__WEBPACK_IMPORTED_MODULE_0__.useRef)(provider.fetcher); // If the parent re-renders this provider will re-render every
  // consumer unless we memoize the config

  const {
    locale,
    cartCookie
  } = providerRef.current;
  const cfg = (0,react__WEBPACK_IMPORTED_MODULE_0__.useMemo)(() => ({
    providerRef,
    fetcherRef,
    locale,
    cartCookie
  }), [locale, cartCookie]);
  return /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__.jsx(Commerce.Provider, {
    value: cfg,
    children: children
  });
}
function getCommerceProvider(provider) {
  return function CommerceProvider(_ref) {
    let {
      children
    } = _ref,
        props = _objectWithoutProperties(_ref, _excluded);

    return /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__.jsx(CoreCommerceProvider, {
      provider: _objectSpread(_objectSpread({}, provider), props),
      children: children
    });
  };
}
function useCommerce() {
  return (0,react__WEBPACK_IMPORTED_MODULE_0__.useContext)(Commerce);
}

/***/ }),

/***/ 5420:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ZP": () => (/* binding */ usePrice)
/* harmony export */ });
/* unused harmony exports formatPrice, formatVariantPrice */
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(9297);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var ___WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(5112);


function formatPrice({
  amount,
  currencyCode,
  locale
}) {
  const formatCurrency = new Intl.NumberFormat(locale, {
    style: 'currency',
    currency: currencyCode
  });
  return formatCurrency.format(amount);
}
function formatVariantPrice({
  amount,
  baseAmount,
  currencyCode,
  locale
}) {
  const hasDiscount = baseAmount > amount;
  const formatDiscount = new Intl.NumberFormat(locale, {
    style: 'percent'
  });
  const discount = hasDiscount ? formatDiscount.format((baseAmount - amount) / baseAmount) : null;
  const price = formatPrice({
    amount,
    currencyCode,
    locale
  });
  const basePrice = hasDiscount ? formatPrice({
    amount: baseAmount,
    currencyCode,
    locale
  }) : null;
  return {
    price,
    basePrice,
    discount
  };
}
function usePrice(data) {
  const {
    amount,
    baseAmount,
    currencyCode
  } = data !== null && data !== void 0 ? data : {};
  const {
    locale
  } = (0,___WEBPACK_IMPORTED_MODULE_1__/* .useCommerce */ .aF)();
  const value = (0,react__WEBPACK_IMPORTED_MODULE_0__.useMemo)(() => {
    if (typeof amount !== 'number' || !currencyCode) return '';
    return baseAmount ? formatVariantPrice({
      amount,
      baseAmount,
      currencyCode,
      locale
    }) : formatPrice({
      amount,
      currencyCode,
      locale
    });
  }, [amount, baseAmount, currencyCode]);
  return typeof value === 'string' ? {
    price: value
  } : value;
}

/***/ }),

/***/ 3449:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "DO": () => (/* binding */ SWRFetcher),
/* harmony export */   "B5": () => (/* binding */ mutationFetcher)
/* harmony export */ });
function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) { symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); } keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

const SWRFetcher = ({
  options,
  fetch
}) => fetch(options);
const mutationFetcher = ({
  input,
  options,
  fetch
}) => fetch(_objectSpread(_objectSpread({}, options), {}, {
  body: input
}));
/* unused harmony default export */ var __WEBPACK_DEFAULT_EXPORT__ = ((/* unused pure expression or super */ null && (SWRFetcher)));

/***/ }),

/***/ 250:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "dV": () => (/* binding */ useHook),
  "wf": () => (/* binding */ useMutationHook),
  "Lz": () => (/* binding */ useSWRHook)
});

// UNUSED EXPORTS: useFetcher

// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(9297);
// EXTERNAL MODULE: ./framework/commerce/index.tsx
var commerce = __webpack_require__(5112);
// EXTERNAL MODULE: external "swr"
var external_swr_ = __webpack_require__(7749);
var external_swr_default = /*#__PURE__*/__webpack_require__.n(external_swr_);
;// CONCATENATED MODULE: ./framework/commerce/utils/define-property.ts
// Taken from https://fettblog.eu/typescript-assertion-signatures/
function defineProperty(obj, prop, val) {
  Object.defineProperty(obj, prop, val);
}
// EXTERNAL MODULE: ./framework/commerce/utils/errors.ts
var errors = __webpack_require__(6370);
;// CONCATENATED MODULE: ./framework/commerce/utils/use-data.tsx




const useData = (options, input, fetcherFn, swrOptions) => {
  const hookInput = Array.isArray(input) ? input : Object.entries(input);

  const fetcher = async (url, query, method, ...args) => {
    try {
      return await options.fetcher({
        options: {
          url,
          query,
          method
        },
        // Transform the input array into an object
        input: args.reduce((obj, val, i) => {
          obj[hookInput[i][0]] = val;
          return obj;
        }, {}),
        fetch: fetcherFn
      });
    } catch (error) {
      // SWR will not log errors, but any error that's not an instance
      // of CommerceError is not welcomed by this hook
      if (!(error instanceof errors/* CommerceError */.yG)) {
        console.error(error);
      }

      throw error;
    }
  };

  const response = external_swr_default()(() => {
    const opts = options.fetchOptions;
    return opts ? [opts.url, opts.query, opts.method, ...hookInput.map(e => e[1])] : null;
  }, fetcher, swrOptions);

  if (!('isLoading' in response)) {
    defineProperty(response, 'isLoading', {
      get() {
        return response.data === undefined;
      },

      enumerable: true
    });
  }

  return response;
};

/* harmony default export */ const use_data = (useData);
;// CONCATENATED MODULE: ./framework/commerce/utils/use-hook.ts



function useFetcher() {
  var _providerRef$current$;

  const {
    providerRef,
    fetcherRef
  } = (0,commerce/* useCommerce */.aF)();
  return (_providerRef$current$ = providerRef.current.fetcher) !== null && _providerRef$current$ !== void 0 ? _providerRef$current$ : fetcherRef.current;
}
function useHook(fn) {
  const {
    providerRef
  } = (0,commerce/* useCommerce */.aF)();
  const provider = providerRef.current;
  return fn(provider);
}
function useSWRHook(hook) {
  const fetcher = useFetcher();
  return hook.useHook({
    useData(ctx) {
      var _ctx$input;

      const response = use_data(hook, (_ctx$input = ctx === null || ctx === void 0 ? void 0 : ctx.input) !== null && _ctx$input !== void 0 ? _ctx$input : [], fetcher, ctx === null || ctx === void 0 ? void 0 : ctx.swrOptions);
      return response;
    }

  });
}
function useMutationHook(hook) {
  const fetcher = useFetcher();
  return hook.useHook({
    fetch: (0,external_react_.useCallback)(({
      input
    } = {}) => {
      return hook.fetcher({
        input,
        options: hook.fetchOptions,
        fetch: fetcher
      });
    }, [fetcher, hook.fetchOptions])
  });
}

/***/ }),

/***/ 7619:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
// Remove trailing and leading slash, usually included in nodes
// returned by the BigCommerce API
const getSlug = path => path.replace(/^\/|\/$/g, '');

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (getSlug);

/***/ }),

/***/ 1321:
/***/ ((module) => {

// Exports
module.exports = {
	"root": "CartItem_root__c20Bc",
	"quantity": "CartItem_quantity__3Fqwn",
	"productImage": "CartItem_productImage__DGtit",
	"productName": "CartItem_productName__x9t-a"
};


/***/ }),

/***/ 7585:
/***/ ((module) => {

// Exports
module.exports = {
	"root": "CartSidebarView_root__1FB8C",
	"empty": "CartSidebarView_empty__3CEEB",
	"lineItemsList": "CartSidebarView_lineItemsList__CqSTF"
};


/***/ }),

/***/ 4758:
/***/ ((module) => {

// Exports
module.exports = {
	"root": "CheckoutSidebarView_root__mWfoJ",
	"lineItemsList": "CheckoutSidebarView_lineItemsList__3hTBY"
};


/***/ }),

/***/ 1466:
/***/ ((module) => {

// Exports
module.exports = {
	"fieldset": "PaymentMethodView_fieldset__1XYFj",
	"label": "PaymentMethodView_label__2DzVJ",
	"input": "PaymentMethodView_input__170YE",
	"select": "PaymentMethodView_select__1l_OK"
};


/***/ }),

/***/ 7035:
/***/ ((module) => {

// Exports
module.exports = {
	"root": "PaymentWidget_root__2nSxp"
};


/***/ }),

/***/ 246:
/***/ ((module) => {

// Exports
module.exports = {
	"fieldset": "ShippingView_fieldset__3FxRw",
	"label": "ShippingView_label__1UsU5",
	"input": "ShippingView_input__1DcNk",
	"select": "ShippingView_select__3_CAg",
	"radio": "ShippingView_radio__26pc1"
};


/***/ }),

/***/ 6507:
/***/ ((module) => {

// Exports
module.exports = {
	"root": "ShippingWidget_root__1W1oD"
};


/***/ }),

/***/ 9707:
/***/ ((module) => {

// Exports
module.exports = {
	"root": "Footer_root__3bxSy",
	"link": "Footer_link__fkLYy"
};


/***/ }),

/***/ 367:
/***/ ((module) => {

// Exports
module.exports = {
	"root": "Layout_root__3wCB1"
};


/***/ }),

/***/ 6398:
/***/ ((module) => {

// Exports
module.exports = {
	"root": "Navbar_root__2kbI9",
	"nav": "Navbar_nav__2tz61",
	"navMenu": "Navbar_navMenu__2ZaDY",
	"link": "Navbar_link__3Blki",
	"logo": "Navbar_logo__26S5Y",
	"logocustom": "Navbar_logocustom__3e0xJ",
	"mainmenudiv": "Navbar_mainmenudiv__CB_eL",
	"rootcustom": "Navbar_rootcustom__1yst-"
};


/***/ }),

/***/ 2333:
/***/ ((module) => {

// Exports
module.exports = {
	"root": "Searchbar_root__iwmvb",
	"rootcustom": "Searchbar_rootcustom__1dui-",
	"input": "Searchbar_input__2JN1M",
	"input1": "Searchbar_input1__1Kr2q",
	"inputcustom": "Searchbar_inputcustom__1gCLk",
	"iconContainer": "Searchbar_iconContainer__266wB",
	"icon": "Searchbar_icon__2Ux5V",
	"searchdiv": "Searchbar_searchdiv___egmN"
};


/***/ }),

/***/ 9826:
/***/ ((module) => {

// Exports
module.exports = {
	"root": "SidebarLayout_root__1-vsK",
	"header": "SidebarLayout_header__3u5pF",
	"container": "SidebarLayout_container__2gaoF"
};


/***/ }),

/***/ 83:
/***/ ((module) => {

// Exports
module.exports = {
	"root": "UserNav_root__343id",
	"list": "UserNav_list__izHGy",
	"item": "UserNav_item__2sdMO",
	"bagCount": "UserNav_bagCount__160W0",
	"avatarButton": "UserNav_avatarButton__1O6kn"
};


/***/ }),

/***/ 8583:
/***/ ((module) => {

// Exports
module.exports = {
	"root": "Button_root__24MxS",
	"loading": "Button_loading__3wWH3",
	"slim": "Button_slim__2caxo",
	"ghost": "Button_ghost__32qxu",
	"naked": "Button_naked__LxZKs",
	"disabled": "Button_disabled__1a8b5",
	"progress": "Button_progress__49J77"
};


/***/ }),

/***/ 8446:
/***/ ((module) => {

// Exports
module.exports = {
	"root": "Input_root__2vmVG"
};


/***/ }),

/***/ 6884:
/***/ ((module) => {

// Exports
module.exports = {
	"root": "LoadingDots_root__jXGQk",
	"dot": "LoadingDots_dot__2IH0E",
	"blink": "LoadingDots_blink__2xsJ2"
};


/***/ }),

/***/ 3056:
/***/ ((module) => {

// Exports
module.exports = {
	"root": "Modal_root__PFjop",
	"modal": "Modal_modal__3I0HK",
	"close": "Modal_close__KdiQG"
};


/***/ }),

/***/ 7089:
/***/ ((module) => {

// Exports
module.exports = {
	"actions": "Quantity_actions__wWpcD",
	"input": "Quantity_input__3q7WP"
};


/***/ }),

/***/ 7856:
/***/ ((module) => {

// Exports
module.exports = {
	"root": "Sidebar_root__gdPr3",
	"sidebar": "Sidebar_sidebar__2rkFM",
	"backdrop": "Sidebar_backdrop__1RVI2"
};


/***/ }),

/***/ 6526:
/***/ ((module) => {

// Exports
module.exports = {
	"body": "Text_body__V9VBQ",
	"heading": "Text_heading__1L02_",
	"pageHeading": "Text_pageHeading__3pj3m",
	"sectionHeading": "Text_sectionHeading__2H2XC"
};


/***/ })

};
;