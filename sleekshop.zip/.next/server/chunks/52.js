exports.id = 52;
exports.ids = [52];
exports.modules = {

/***/ 7052:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "Z": () => (/* binding */ ProductSlider_ProductSlider)
});

// EXTERNAL MODULE: external "keen-slider/react"
var react_ = __webpack_require__(1471);
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(9297);
var external_react_default = /*#__PURE__*/__webpack_require__.n(external_react_);
// EXTERNAL MODULE: external "classnames"
var external_classnames_ = __webpack_require__(4058);
var external_classnames_default = /*#__PURE__*/__webpack_require__.n(external_classnames_);
// EXTERNAL MODULE: ./components/product/ProductSlider/ProductSlider.module.css
var ProductSlider_module = __webpack_require__(6041);
var ProductSlider_module_default = /*#__PURE__*/__webpack_require__.n(ProductSlider_module);
// EXTERNAL MODULE: ./components/product/ProductSliderControl/ProductSliderControl.module.css
var ProductSliderControl_module = __webpack_require__(9197);
var ProductSliderControl_module_default = /*#__PURE__*/__webpack_require__.n(ProductSliderControl_module);
;// CONCATENATED MODULE: ./assets/sleekshop-new-svg/arrow-left.svg
var _path;

function _extends() { _extends = Object.assign || function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; }; return _extends.apply(this, arguments); }



var SvgArrowLeft = function SvgArrowLeft(props) {
  return /*#__PURE__*/external_react_.createElement("svg", _extends({
    width: 14,
    height: 24,
    fill: "none",
    xmlns: "http://www.w3.org/2000/svg"
  }, props), _path || (_path = /*#__PURE__*/external_react_.createElement("path", {
    d: "M12.031.281 13.47 1.72 3.188 12l10.28 10.281-1.437 1.438-11-11L.344 12l.687-.719 11-11Z",
    fill: "#50585E"
  })));
};

/* harmony default export */ const arrow_left = (SvgArrowLeft);
// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(5282);
;// CONCATENATED MODULE: ./components/icons/ArrowLeft.tsx



const ArrowLeft = _ref => {
  let props = Object.assign({}, _ref);
  return (
    /*#__PURE__*/
    // <Image
    //   src="https://cdn6.bigcommerce.com/s-hmhnh4h9/product_images/uploaded_images/arrow-l.png"
    //   width="27"
    //   height="47"
    // ></Image>
    jsx_runtime_.jsx(arrow_left, {})
  );
};

/* harmony default export */ const icons_ArrowLeft = (ArrowLeft);
// EXTERNAL MODULE: ./components/icons/ArrowRight.tsx + 1 modules
var ArrowRight = __webpack_require__(1742);
;// CONCATENATED MODULE: ./components/product/ProductSliderControl/ProductSliderControl.tsx






const ProductSliderControl = /*#__PURE__*/external_react_default().memo(({
  onPrev,
  onNext
}) => /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
  className: external_classnames_default()((ProductSliderControl_module_default()).control, 'buttonBG'),
  children: [/*#__PURE__*/jsx_runtime_.jsx("button", {
    className: external_classnames_default()((ProductSliderControl_module_default()).leftControl),
    onClick: onPrev,
    "aria-label": "Previous Product Image",
    children: /*#__PURE__*/jsx_runtime_.jsx(icons_ArrowLeft, {})
  }), /*#__PURE__*/jsx_runtime_.jsx("button", {
    className: external_classnames_default()((ProductSliderControl_module_default()).rightControl),
    onClick: onNext,
    "aria-label": "Next Product Image",
    children: /*#__PURE__*/jsx_runtime_.jsx(ArrowRight/* default */.Z, {})
  })]
}));
/* harmony default export */ const ProductSliderControl_ProductSliderControl = (ProductSliderControl);
;// CONCATENATED MODULE: ./components/product/ProductSlider/ProductSlider.tsx
function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) { symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); } keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }









const ProductSlider = ({
  viewCount = 1,
  children,
  className = ''
}) => {
  const {
    0: currentSlide,
    1: setCurrentSlide
  } = (0,external_react_.useState)(0);
  const {
    0: isMounted,
    1: setIsMounted
  } = (0,external_react_.useState)(false);
  const sliderContainerRef = (0,external_react_.useRef)(null);
  const thumbsContainerRef = (0,external_react_.useRef)(null);
  const [ref, slider] = (0,react_.useKeenSlider)({
    loop: true,
    slidesPerView: viewCount,
    mounted: () => setIsMounted(true),

    slideChanged(s) {
      const slideNumber = s.details().relativeSlide;
      setCurrentSlide(slideNumber);

      if (thumbsContainerRef.current) {
        const $el = document.getElementById(`thumb-${s.details().relativeSlide}`);

        if (slideNumber >= 1) {
          thumbsContainerRef.current.scrollLeft = $el.offsetLeft;
        } else {
          thumbsContainerRef.current.scrollLeft = 0;
        }
      }
    }

  }); // Stop the history navigation gesture on touch devices

  (0,external_react_.useEffect)(() => {
    const preventNavigation = event => {
      // Center point of the touch area
      const touchXPosition = event.touches[0].pageX; // Size of the touch area

      const touchXRadius = event.touches[0].radiusX || 0; // We set a threshold (10px) on both sizes of the screen,
      // if the touch area overlaps with the screen edges
      // it's likely to trigger the navigation. We prevent the
      // touchstart event in that case.

      if (touchXPosition - touchXRadius < 10 || touchXPosition + touchXRadius > window.innerWidth - 10) event.preventDefault();
    };

    const slider = sliderContainerRef.current;
    slider.addEventListener('touchstart', preventNavigation);
    return () => {
      if (slider) {
        slider.removeEventListener('touchstart', preventNavigation);
      }
    };
  }, []);
  const onPrev = external_react_default().useCallback(() => slider.prev(), [slider]);
  const onNext = external_react_default().useCallback(() => slider.next(), [slider]);
  return /*#__PURE__*/jsx_runtime_.jsx("div", {
    className: external_classnames_default()((ProductSlider_module_default()).root, className),
    ref: sliderContainerRef,
    children: /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
      ref: ref,
      className: external_classnames_default()((ProductSlider_module_default()).slider, {
        [(ProductSlider_module_default()).show]: isMounted
      }, 'keen-slider'),
      children: [slider && /*#__PURE__*/jsx_runtime_.jsx(ProductSliderControl_ProductSliderControl, {
        onPrev: onPrev,
        onNext: onNext
      }), external_react_.Children.map(children, child => {
        // Add the keen-slider__slide className to children
        if ( /*#__PURE__*/(0,external_react_.isValidElement)(child)) {
          return _objectSpread(_objectSpread({}, child), {}, {
            props: _objectSpread(_objectSpread({}, child.props), {}, {
              className: `${child.props.className ? `${child.props.className} ` : ''}keen-slider__slide`
            })
          });
        }

        return child;
      })]
    })
  });
};

/* harmony default export */ const ProductSlider_ProductSlider = (ProductSlider);

/***/ }),

/***/ 9197:
/***/ ((module) => {

// Exports
module.exports = {
	"control": "ProductSliderControl_control__tbCmw",
	"leftControl": "ProductSliderControl_leftControl__3sv86",
	"rightControl": "ProductSliderControl_rightControl__3T281"
};


/***/ }),

/***/ 6041:
/***/ ((module) => {

// Exports
module.exports = {
	"root": "ProductSlider_root__2cu05",
	"slider": "ProductSlider_slider__1hxLB",
	"show": "ProductSlider_show__2QLSC",
	"thumb": "ProductSlider_thumb__2ZyNn",
	"selected": "ProductSlider_selected__29OBB",
	"album": "ProductSlider_album__1MjxO"
};


/***/ })

};
;