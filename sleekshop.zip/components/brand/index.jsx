import React from 'react'

const index = () => {
    return (
        <div>
           Welcome to brands Dynamic page , the Brand realted pages can be injected here 
        </div>
    )
}

export default index
