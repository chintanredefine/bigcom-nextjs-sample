export { default } from './PaymentMethodView'
