export { default } from './ProductSlider'
