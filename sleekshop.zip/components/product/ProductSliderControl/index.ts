export { default } from './ProductSliderControl'
