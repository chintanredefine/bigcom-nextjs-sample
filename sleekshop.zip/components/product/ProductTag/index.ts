export { default } from './ProductTag'
