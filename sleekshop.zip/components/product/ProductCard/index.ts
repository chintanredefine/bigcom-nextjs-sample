export { default } from './ProductCard'
