export { default } from './ProductView'
